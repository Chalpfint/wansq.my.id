<?php
declare(strict_types=1);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/helpers.php';
require __DIR__ . '/includes/auth.php';
require __DIR__ . '/includes/models.php';
require __DIR__ . '/includes/i18n.php';
require __DIR__ . '/includes/caps.php';
require __DIR__ . '/includes/processors.php';
session_boot();
no_store();
$user = current_user();
if (!$user) { header('Location: ' . base_url('/index.php')); exit; }
session_touch();
if (!schema_ready()) {
    http_response_code(503); header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><title>WanSQ · Upgrade database</title><body style="font:16px/1.6 system-ui;max-width:640px;margin:12vh auto;padding:0 20px">'
       . '<h2>Skema database belum lengkap</h2><p>WanSQ v' . e(WANSQ_VERSION) . ' membutuhkan skema database 4.1.4. Buka <b>Navicat Premium Lite</b> → pilih database → <b>Query → New Query</b> → jalankan <code>sql/wansq_upgrade_v4.1.4.sql</code>, lalu muat ulang halaman ini.</p>'
       . '<p style="color:#666">(Backup dulu: klik kanan database → Dump SQL File.)</p></body>';
    exit;
}
$LANG = i18n_lang($user); $GLOBALS['WAN_LANG'] = $LANG;
function I(string $k): string { return 'data-i18n="' . e($k) . '"'; }
function P(string $k): string { return 'data-i18n-ph="' . e($k) . '" placeholder="' . trh($k) . '"'; }
function A(string $k): string { return 'data-i18n-aria="' . e($k) . '" aria-label="' . trh($k) . '"'; }
function TT(string $k): string { return 'data-i18n-title="' . e($k) . '" title="' . trh($k) . '"'; }
$boot = [
  'csrf' => csrf_token(), 'base' => base_url(''), 'version' => WANSQ_VERSION,
  'lang' => $LANG, 'reply_lang' => (string)($user['reply_lang'] ?? 'auto'),
  'i18n' => ['id' => i18n_dict('id'), 'en' => i18n_dict('en')],
  'caps' => caps_build(),
  'user' => ['id' => (int)$user['id'], 'name' => $user['full_name'], 'username' => $user['username'],
             'email' => $user['email'], 'avatar' => user_avatar_url($user),
             'google_avatar' => $user['avatar_google'], 'theme' => $user['theme'], 'has_password' => (bool)$user['password_hash']],
  'engines' => array_map(fn($e) => ['label' => $e['label'], 'desc' => $e['desc']], wansq_engines()),
];
$logo = function (string $cls = '') { $b = base_url('/assets/img/');
  return '<img class="logo-light" src="' . e($b . 'wan-blue.png') . '" data-fb="' . e($b . 'wan-blue.svg') . '" alt="">'
       . '<img class="logo-dark" src="' . e($b . 'wan-dark.png') . '" data-fb="' . e($b . 'wan-dark.svg') . '" alt="">'; };
$avd = e(base_url('/assets/img/avatar-default.svg'));
?><!DOCTYPE html>
<html lang="<?= e($LANG) ?>" data-theme-pref="<?= e($user['theme']) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>WanSQ - AI Assistant</title>
<link rel="icon" type="image/png" href="<?= e(base_url('/assets/img/favicon.png')) ?>">
<link rel="alternate icon" type="image/svg+xml" href="<?= e(base_url('/assets/img/wan-blue.svg')) ?>">
<link rel="stylesheet" href="<?= e(base_url('/assets/css/style.css')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>">
<script src="<?= e(base_url('/assets/js/themeboot.js')) ?>"></script>
</head>
<body class="app-body">
<a class="skip-link" href="#input" <?= I('a11y.skip') ?>><?= trh('a11y.skip') ?></a>
<div class="ws">
  <aside class="sidebar" id="sidebar" <?= A('sb.aria') ?>>
    <div class="sb-head">
      <span class="brand"><?= $logo() ?><span class="brand-name">WanSQ</span></span>
      <button class="sb-collapse-btn" id="btnSideCollapse" <?= A('sb.collapse') ?> <?= TT('sb.collapse') ?>>
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/><path d="M14 10l-2 2 2 2"/></svg>
      </button>
      <button class="icon-btn sb-close" id="btnSideClose" <?= A('sb.close') ?>>✕</button>
    </div>
    <button class="new-chat" id="btnNewChat"><span class="plus">+</span> <span <?= I('sb.new') ?>><?= trh('sb.new') ?></span></button>
    <div class="sb-search">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
      <input id="chatSearch" type="search" <?= P('sb.search') ?> autocomplete="off" <?= A('sb.search.aria') ?>>
      <kbd class="kbd" aria-hidden="true">Ctrl K</kbd>
    </div>

    <section class="sb-projects" aria-labelledby="projHead">
      <div class="sb-sec-head">
        <button class="sec-toggle" id="projToggle" aria-expanded="true"><span id="projHead" <?= I('proj.title') ?>><?= trh('proj.title') ?></span> <span class="chev" aria-hidden="true">▾</span></button>
        <button class="icon-btn sm" id="btnNewProject" <?= A('proj.new') ?> <?= TT('proj.new') ?>>+</button>
      </div>
      <div class="proj-list" id="projList"></div>
    </section>

    <div class="proj-filter" id="projFilter" hidden></div>
    <div class="sb-tabs" role="tablist" <?= A('sb.filter') ?>>
      <button class="sb-tab active" role="tab" aria-selected="true" data-filter="active" <?= I('sb.main') ?>><?= trh('sb.main') ?></button>
      <button class="sb-tab" role="tab" aria-selected="false" data-filter="archived" <?= I('sb.archive') ?>><?= trh('sb.archive') ?></button>
    </div>
    <nav class="conv-list" id="convList" <?= A('sb.list') ?>></nav>
    <button class="more-btn" id="btnMore" hidden <?= I('sb.more') ?>><?= trh('sb.more') ?></button>
    <div class="sb-foot">
      <button class="acct" id="acctBtn" aria-haspopup="menu" aria-expanded="false">
        <img id="acctAvatar" src="<?= e(user_avatar_url($user)) ?>" data-fb="<?= $avd ?>" alt="">
        <span class="acct-txt"><span id="acctName"><?= e($user['full_name'] ?: $user['username']) ?></span><span id="acctEmail"><?= e($user['email']) ?></span></span>
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </button>
      <div class="acct-menu" id="acctMenu" role="menu" hidden>
        <button class="mi" role="menuitem" data-act="settings"><span class="mi-ic">⚙</span> <span <?= I('menu.settings') ?>><?= trh('menu.settings') ?></span></button>
        <button class="mi" role="menuitem" data-act="memory"><span class="mi-ic">🧠</span> <span <?= I('menu.memory') ?>><?= trh('menu.memory') ?></span></button>
        <button class="mi" role="menuitem" data-act="language"><span class="mi-ic">🌐</span> <span <?= I('menu.language') ?>><?= trh('menu.language') ?></span></button>
        <button class="mi" role="menuitem" data-act="palette"><span class="mi-ic">⌘</span> <span <?= I('menu.palette') ?>><?= trh('menu.palette') ?></span></button>
        <button class="mi" role="menuitem" data-act="feedback"><span class="mi-ic">💬</span> <span <?= I('menu.feedback') ?>><?= trh('menu.feedback') ?></span></button>
        <div class="mi-sep" role="separator"></div>
        <button class="mi danger" role="menuitem" data-act="logout"><span class="mi-ic">⎋</span> <span <?= I('menu.logout') ?>><?= trh('menu.logout') ?></span></button>
      </div>
    </div>
  </aside>

  <main class="main" id="mainZone">
    <div class="banner" id="aiBanner" role="alert" hidden>
      <span id="aiBannerTxt"></span>
      <button class="icon-btn" data-close-banner="1" <?= A('common.close') ?>>✕</button>
    </div>
    <header class="topbar">
      <button class="icon-btn side-open" id="btnSideOpen" <?= A('sb.open') ?>>☰</button>
      <div class="title-wrap">
        <button class="proj-crumb" id="projCrumb" hidden></button>
        <h1 class="conv-title" id="convTitle" <?= I('conv.new') ?>><?= trh('conv.new') ?></h1>
      </div>
      <div class="top-actions">
        <button class="icon-btn" id="btnConvActions" aria-haspopup="menu" aria-expanded="false" title="Conversation actions" aria-label="Conversation actions" hidden>⋯</button>
        <div class="pop-wrap">
          <button class="engine-btn" id="engineBtn" aria-haspopup="menu" aria-expanded="false" <?= TT('engine.title') ?>>
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/></svg>
            <span id="engineLabel">Auto</span>
          </button>
          <div class="engine-menu" id="engineMenu" role="menu" hidden></div>
        </div>
        <button class="icon-btn" id="btnPins" aria-haspopup="dialog" aria-expanded="false" aria-pressed="false" hidden>📌<span class="badge" id="pinCount" hidden>0</span></button>
        <div class="pins-pop" id="pinsPop" role="dialog" hidden></div>
        <button class="icon-btn" id="btnShare" hidden>🔗</button>
        <button class="icon-btn" id="btnWorkspace" hidden aria-haspopup="dialog" aria-expanded="false">▦</button>
        <button class="icon-btn" id="btnExport" hidden>⇩</button>
      </div>
    </header>

    <div class="chat-scroll" id="chatScroll">
      <div class="chat-inner" id="messages" role="log" aria-live="off"></div>
    </div>
    <button class="scroll-down" id="btnScroll" hidden <?= A('conv.scrolldown') ?>>↓</button>
    <div class="drop-overlay" id="dropOverlay" hidden aria-hidden="true"><div><b <?= I('drop.title') ?>><?= trh('drop.title') ?></b><span id="dropHint" <?= I('drop.hint') ?>><?= trh('drop.hint') ?></span></div></div>

    <div class="status-line" id="statusLine" role="status" aria-live="polite" hidden></div>

    <footer class="composer-zone">
      <div class="attach-strip" id="attachRow" hidden></div>
      <div class="composer" id="composer">
        <button class="c-btn" id="btnAttach" <?= A('cmp.attach') ?> <?= TT('cmp.attach') ?>>
          <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
        </button>
        <textarea id="input" rows="1" <?= P('cmp.placeholder') ?> <?= A('cmp.aria') ?>></textarea>
        <button class="c-btn" id="btnMic" <?= A('cmp.mic') ?> <?= TT('cmp.mic') ?> hidden>
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="3" width="6" height="10" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/></svg>
        </button>

        <button class="c-send" id="btnSend" <?= A('cmp.send') ?> <?= TT('cmp.send') ?>>
          <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
        </button>
        <button class="c-send stop" id="btnStop" <?= A('cmp.stop') ?> <?= TT('cmp.stop') ?> hidden>
          <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>
        </button>
      </div>
      <p class="foot-note" <?= I('cmp.disclaimer') ?>><?= trh('cmp.disclaimer') ?></p>
    </footer>
  </main>
</div>

<input type="file" id="filePick" multiple accept="image/*,<?= proc_accept_attr() ?>" hidden>
<input type="file" id="avatarPick" accept="image/*" hidden>
<input type="file" id="projFilePick" multiple accept="image/*,<?= proc_accept_attr() ?>" hidden>

<div class="modal" id="camModal" hidden role="dialog" aria-modal="true" <?= A('cam.title') ?>>
  <div class="modal-card">
    <div class="modal-head"><h3 <?= I('cam.title') ?>><?= trh('cam.title') ?></h3><button class="icon-btn" data-close="camModal" <?= A('common.close') ?>>✕</button></div>
    <video id="camVideo" autoplay playsinline muted></video>
    <div class="modal-actions"><button class="btn-primary" id="camShot" <?= I('cam.shot') ?>><?= trh('cam.shot') ?></button><button class="btn-ghost" data-close="camModal" <?= I('common.cancel') ?>><?= trh('common.cancel') ?></button></div>
  </div>
</div>

<div class="modal" id="lbModal" hidden role="dialog" aria-modal="true" <?= A('lb.title') ?>>
  <div class="modal-card lightbox">
    <div class="modal-head"><h3 id="lbTitle" <?= I('lb.title') ?>><?= trh('lb.title') ?></h3><button class="icon-btn" data-close="lbModal" <?= A('common.close') ?>>✕</button></div>
    <img id="lbImg" src="" alt="">
  </div>
</div>

<div class="modal" id="docModal" hidden role="dialog" aria-modal="true" <?= A('doc.title') ?>>
  <div class="modal-card doc-card">
    <div class="modal-head"><h3 id="docTitle">…</h3><button class="icon-btn" data-close="docModal" <?= A('common.close') ?>>✕</button></div>
    <div class="doc-meta" id="docMeta"></div>
    <pre class="doc-preview" id="docPreview"></pre>
  </div>
</div>

<div class="modal" id="cmdModal" hidden role="dialog" aria-modal="true" <?= A('cmd.title') ?>>
  <div class="modal-card cmd-card">
    <input id="cmdInput" type="search" autocomplete="off" <?= P('cmd.placeholder') ?> <?= A('cmd.title') ?>>
    <div class="cmd-list" id="cmdList" role="listbox"></div>
    <div class="cmd-foot"><span>↑↓ <span <?= I('cmd.nav') ?>><?= trh('cmd.nav') ?></span></span><span>↵ <span <?= I('cmd.open') ?>><?= trh('cmd.open') ?></span></span><span>Esc <span <?= I('cmd.close') ?>><?= trh('cmd.close') ?></span></span></div>
  </div>
</div>

<div class="modal" id="projModal" hidden role="dialog" aria-modal="true" <?= A('proj.dialog') ?>>
  <div class="modal-card proj-card">
    <div class="modal-head"><h3 id="projModalTitle" <?= I('proj.new') ?>><?= trh('proj.new') ?></h3><button class="icon-btn" data-close="projModal" <?= A('common.close') ?>>✕</button></div>
    <div class="proj-tabs" role="tablist" id="projTabs">
      <button class="ptab active" data-ptab="general" role="tab" <?= I('proj.tab.general') ?>><?= trh('proj.tab.general') ?></button>
      <button class="ptab" data-ptab="memory" role="tab" <?= I('proj.tab.memory') ?>><?= trh('proj.tab.memory') ?></button>
      <button class="ptab" data-ptab="files" role="tab" <?= I('proj.tab.files') ?>><?= trh('proj.tab.files') ?></button>
    </div>
    <div class="ppane active" data-ppane="general">
      <div class="row2"><label class="ico-in"><span <?= I('proj.icon') ?>><?= trh('proj.icon') ?></span><input id="projIcon" maxlength="4" value="📁"></label>
      <label class="grow"><span <?= I('proj.name') ?>><?= trh('proj.name') ?></span><input id="projName" maxlength="80" <?= P('proj.name.ph') ?>></label></div>
      <label><span <?= I('proj.instr') ?>><?= trh('proj.instr') ?></span><textarea id="projInstr" rows="5" maxlength="4000" <?= P('proj.instr.ph') ?>></textarea></label>
      <p class="pop-hint" <?= I('proj.instr.hint') ?>><?= trh('proj.instr.hint') ?></p>
    </div>
    <div class="ppane" data-ppane="memory">
      <p class="pane-hint" <?= I('proj.mem.hint') ?>><?= trh('proj.mem.hint') ?></p>
      <div class="add-row"><input id="projMemInput" maxlength="500" <?= P('proj.mem.ph') ?>><button class="btn-primary" id="projMemAdd" <?= I('common.add') ?>><?= trh('common.add') ?></button></div>
      <ul class="mem-list" id="projMemList"></ul>
    </div>
    <div class="ppane" data-ppane="files">
      <p class="pane-hint" <?= I('proj.files.hint') ?>><?= trh('proj.files.hint') ?></p>
      <div class="add-row"><button class="btn-ghost" id="projFileBtn" <?= I('proj.files.add') ?>><?= trh('proj.files.add') ?></button><span class="save-status" id="projFileStatus" role="status"></span></div>
      <ul class="mem-list" id="projFileList"></ul>
    </div>
    <div class="modal-actions between">
      <button class="btn-ghost danger-txt" id="projDelete" hidden <?= I('proj.delete') ?>><?= trh('proj.delete') ?></button>
      <span class="grow"></span><span class="save-status" id="projStatus" role="status"></span>
      <button class="btn-ghost" data-close="projModal" <?= I('common.close') ?>><?= trh('common.close') ?></button>
      <button class="btn-primary" id="projSave" <?= I('common.save') ?>><?= trh('common.save') ?></button>
    </div>
  </div>
</div>

<div class="modal" id="moveModal" hidden role="dialog" aria-modal="true" <?= A('move.title') ?>>
  <div class="modal-card small-card">
    <div class="modal-head"><h3 <?= I('move.title') ?>><?= trh('move.title') ?></h3><button class="icon-btn" data-close="moveModal" <?= A('common.close') ?>>✕</button></div>
    <div class="pick-list" id="moveList"></div>
  </div>
</div>

<div class="modal" id="shareModal" hidden role="dialog" aria-modal="true" <?= A('share.title') ?>>
  <div class="modal-card small-card">
    <div class="modal-head"><h3 <?= I('share.title') ?>><?= trh('share.title') ?></h3><button class="icon-btn" data-close="shareModal" <?= A('common.close') ?>>✕</button></div>
    <div id="shareBody"></div>
  </div>
</div>

<div class="modal" id="workspaceModal" hidden role="dialog" aria-modal="true" aria-labelledby="workspaceTitle">
  <div class="modal-card workspace-card">
    <div class="modal-head">
      <div><h3 id="workspaceTitle">Workspace</h3><p class="workspace-sub">Artifacts, activity, and reusable work.</p></div>
      <button class="icon-btn" data-close="workspaceModal" aria-label="Close">✕</button>
    </div>
    <div class="workspace-tabs" role="tablist">
      <button class="wtab active" data-wtab="artifacts" role="tab">Artifacts</button>
      <button class="wtab" data-wtab="jobs" role="tab">Activity</button>
    </div>
    <section class="w-pane active" data-wpane="artifacts">
      <div class="workspace-toolbar"><span id="artifactCount"></span><button class="btn-ghost" id="artifactRefresh">↻ Refresh</button></div>
      <div id="artifactList" class="artifact-list"></div>
      <div id="artifactEditor" class="artifact-editor" hidden>
        <div class="artifact-editor-head"><input id="artifactTitle" maxlength="160"><select id="artifactType"><option value="document">Document</option><option value="markdown">Markdown</option><option value="code">Code</option><option value="html">HTML</option><option value="table">Table</option><option value="study_guide">Study guide</option><option value="report">Report</option></select></div>
        <textarea id="artifactContent" spellcheck="false"></textarea>
        <div class="artifact-tools"><label class="artifact-ver"><span>Versi</span><select id="artifactVersions" aria-label="Riwayat versi"></select></label><button class="btn-ghost" id="artifactRestore" type="button">↺ Pulihkan versi</button><button class="btn-ghost" id="artifactCopy" type="button">⧉ Salin</button><button class="btn-ghost" id="artifactDownload" type="button">⇩ Unduh</button><button class="btn-ghost danger" id="artifactDelete" type="button">🗑 Hapus</button></div>
        <div class="modal-actions between"><span class="save-status" id="artifactStatus"></span><span><button class="btn-ghost" id="artifactBack">Back</button><button class="btn-primary" id="artifactSave">Save version</button></span></div>
      </div>
    </section>
    <section class="w-pane" data-wpane="jobs">
      <div class="workspace-toolbar"><span>Long-running and background work</span><span><button class="btn-ghost" id="jobClear">Bersihkan selesai</button> <button class="btn-ghost" id="jobRefresh">↻ Refresh</button></span></div>
      <div id="jobList" class="job-list"></div>
    </section>
  </div>
</div>

<div class="modal" id="setModal" hidden role="dialog" aria-modal="true" <?= A('menu.settings') ?>>
  <div class="modal-card settings">
    <header class="set-head">
      <div class="set-headtxt"><h2 <?= I('menu.settings') ?>><?= trh('menu.settings') ?></h2><span class="set-crumb" id="setCrumb">Profile</span></div>
      <button class="icon-btn set-close" data-close="setModal" <?= A('common.close') ?>>✕</button>
    </header>
    <div class="set-body">
      <nav class="set-nav" <?= A('menu.settings') ?>>
        <button class="set-link active" data-tab="profile" <?= I('set.profile') ?>><?= trh('set.profile') ?></button>
        <button class="set-link" data-tab="theme" <?= I('set.theme') ?>><?= trh('set.theme') ?></button>
        <button class="set-link" data-tab="language" <?= I('set.language') ?>><?= trh('set.language') ?></button>
        <button class="set-link" data-tab="memory" <?= I('set.memory') ?>><?= trh('set.memory') ?></button>
        <button class="set-link" data-tab="data" <?= I('set.data') ?>><?= trh('set.data') ?></button>
        <button class="set-link" data-tab="about" <?= I('set.about') ?>><?= trh('set.about') ?></button>
      </nav>
      <div class="set-panes">
        <section class="set-pane active" data-pane="profile">
          <div class="crop-zone" id="cropZone" hidden>
            <div class="crop-stage"><canvas id="cropCanvas" width="320" height="320"></canvas><div class="crop-mask"></div></div>
            <div class="crop-controls">
              <button class="icon-btn" id="cropZoomOut" aria-label="−">−</button>
              <input type="range" id="cropZoom" min="1" max="4" step="0.01" value="1" <?= A('crop.zoom') ?>>
              <button class="icon-btn" id="cropZoomIn" aria-label="+">+</button>
              <button class="btn-ghost" id="cropRotate" <?= TT('crop.rotate') ?>>⟳</button>
            </div>
            <p class="pop-hint" <?= I('crop.hint') ?>><?= trh('crop.hint') ?></p>
            <div class="row-end"><button class="btn-primary" id="cropSave" <?= I('crop.save') ?>><?= trh('crop.save') ?></button><button class="btn-ghost" id="cropCancel" <?= I('common.cancel') ?>><?= trh('common.cancel') ?></button></div>
          </div>
          <div class="avatar-zone" id="avatarZone">
            <img id="setAvatar" src="<?= e(user_avatar_url($user)) ?>" data-fb="<?= $avd ?>" alt="">
            <div class="av-btns">
              <button class="btn-ghost" id="btnAvGallery" <?= I('prof.gallery') ?>><?= trh('prof.gallery') ?></button>
              <button class="btn-ghost" id="btnAvCamera" <?= I('prof.camera') ?>><?= trh('prof.camera') ?></button>
              <button class="btn-ghost" id="btnAvReset" <?= I('prof.reset') ?>><?= trh('prof.reset') ?></button>
            </div>
          </div>
          <label><span <?= I('prof.name') ?>><?= trh('prof.name') ?></span><input id="setName" value="<?= e($user['full_name']) ?>" maxlength="120"></label>
          <label><span <?= I('prof.username') ?>><?= trh('prof.username') ?></span><input id="setUsername" value="<?= e($user['username']) ?>" maxlength="30"></label>
          <label><span>Email</span><input value="<?= e($user['email']) ?>" disabled></label>
          <div class="row-end"><button class="btn-primary" id="btnSaveProfile" <?= I('prof.save') ?>><?= trh('prof.save') ?></button><span class="save-status" id="profileStatus" role="status"></span></div>
          <hr>
          <h3 <?= I($user['password_hash'] ? 'pw.change' : 'pw.create') ?>><?= trh($user['password_hash'] ? 'pw.change' : 'pw.create') ?></h3>
          <?php if ($user['password_hash']): ?><label><span <?= I('pw.old') ?>><?= trh('pw.old') ?></span><input type="password" id="pwOld"></label><?php endif; ?>
          <label><span <?= I('pw.new') ?>><?= trh('pw.new') ?></span><input type="password" id="pwNew"></label>
          <label><span <?= I('pw.confirm') ?>><?= trh('pw.confirm') ?></span><input type="password" id="pwNew2"></label>
          <div class="row-end"><button class="btn-primary" id="btnSavePw" <?= I('pw.save') ?>><?= trh('pw.save') ?></button><span class="save-status" id="pwStatus" role="status"></span></div>
        </section>

        <section class="set-pane" data-pane="theme">
          <p class="pane-hint" <?= I('theme.hint') ?>><?= trh('theme.hint') ?></p>
          <div class="theme-cards">
            <button class="theme-card" data-theme="light"><span class="tc-dot light"></span>Light</button>
            <button class="theme-card" data-theme="dark"><span class="tc-dot dark"></span>Dark</button>
            <button class="theme-card" data-theme="system"><span class="tc-dot sys"></span>System</button>
          </div>
        </section>

        <section class="set-pane" data-pane="language">
          <h3 <?= I('lang.ui') ?>><?= trh('lang.ui') ?></h3>
          <p class="pane-hint" <?= I('lang.ui.hint') ?>><?= trh('lang.ui.hint') ?></p>
          <div class="theme-cards" id="uiLangCards">
            <button class="theme-card" data-ui-lang="id">🇮🇩 Bahasa Indonesia</button>
            <button class="theme-card" data-ui-lang="en">🇬🇧 English</button>
          </div>
          <h3 <?= I('lang.reply') ?>><?= trh('lang.reply') ?></h3>
          <p class="pane-hint" <?= I('lang.reply.hint') ?>><?= trh('lang.reply.hint') ?></p>
          <div class="theme-cards" id="replyLangCards">
            <button class="theme-card" data-reply-lang="auto" <?= I('lang.auto') ?>><?= trh('lang.auto') ?></button>
            <button class="theme-card" data-reply-lang="id">Bahasa Indonesia</button>
            <button class="theme-card" data-reply-lang="en">English</button>
          </div>
          <span class="save-status" id="langStatus" role="status"></span>
        </section>

        <section class="set-pane" data-pane="memory">
          <p class="pane-hint" <?= I('mem.hint') ?>><?= trh('mem.hint') ?></p>
          <ul class="mem-list" id="memList"></ul>
          <div class="row-end"><button class="btn-ghost danger-txt" id="btnMemClear" <?= I('mem.clear') ?>><?= trh('mem.clear') ?></button></div>
          <h3 <?= I('ci.title') ?>><?= trh('ci.title') ?></h3>
          <p class="pane-hint" <?= I('ci.hint') ?>><?= trh('ci.hint') ?></p>
          <textarea id="ciText" class="ci-text" rows="5" maxlength="1500" spellcheck="true" data-i18n-ph="ci.ph"><?= e((string)($user['custom_instructions'] ?? '')) ?></textarea>
          <div class="row-end"><span class="save-status" id="ciStatus" role="status"></span><button class="btn-primary" id="btnCiSave" <?= I('ci.save') ?>><?= trh('ci.save') ?></button></div>
        </section>

        <section class="set-pane" data-pane="data">
          <h3 <?= I('trash.title') ?>><?= trh('trash.title') ?></h3>
          <p class="pane-hint" id="trashHint"></p>
          <ul class="mem-list" id="trashList"></ul>
        </section>

        <section class="set-pane" data-pane="about">
          <div class="about-logo"><?= $logo() ?></div>
          <p <?= I('about.text') ?>><?= trh('about.text') ?></p>
          <p class="ver">WanSQ v<?= e(WANSQ_VERSION) ?> · <span <?= I('about.tech') ?>><?= trh('about.tech') ?></span></p>
        </section>
      </div>
    </div>
  </div>
</div>

<pre class="dev-panel" id="devPanel" hidden aria-label="Diagnostik developer"></pre>
<div class="toast" id="toast" role="status" aria-live="polite" hidden></div>

<script id="wan-boot" type="application/json"><?= json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
<script src="<?= e(base_url('/assets/js/mathcfg.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/vendor/mathjax/tex-mml-chtml.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/js/md.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/js/app.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/js/ext.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/js/cropper.js')) ?>"></script>
<script src="<?= e(base_url('/assets/js/workspace.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/js/boot.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>

</body>
</html>
