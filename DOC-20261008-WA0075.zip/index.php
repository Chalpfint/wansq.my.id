<?php
declare(strict_types=1);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/helpers.php';
require __DIR__ . '/includes/auth.php';
session_boot();
no_store();

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pw_login'])) {
    csrf_check();
    $em = trim($_POST['email'] ?? ''); $pw = (string)($_POST['password'] ?? '');
    $st = db()->prepare('SELECT * FROM users WHERE email = ?');
    $st->execute([$em]); $u = $st->fetch();
    if ($u && $u['password_hash'] && password_verify($pw, $u['password_hash'])) {
        login_user((int)$u['id']);
        header('Location: ' . base_url('/app.php')); exit;
    }
    $err = 'Email/password tidak cocok, atau akun ini hanya login via Google.';
}
if (current_user()) { header('Location: ' . base_url('/app.php')); exit; }
?><!DOCTYPE html>
<html lang="id" data-theme-pref="system">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WanSQ - AI Assistant</title>
<link rel="icon" type="image/png" href="<?= e(base_url('/assets/img/favicon.png')) ?>">
<link rel="alternate icon" type="image/svg+xml" href="<?= e(base_url('/assets/img/wan-blue.svg')) ?>">
<link rel="stylesheet" href="<?= e(base_url('/assets/css/style.css')) ?>">
<script src="<?= e(base_url('/assets/js/themeboot.js')) ?>"></script>
</head>
<body class="login-body">
<main class="login-card" aria-label="Masuk ke WanSQ">
  <div class="lc-brand">
    <img class="logo-light" src="<?= e(base_url('/assets/img/wan-blue.png')) ?>" data-fb="<?= e(base_url('/assets/img/wan-blue.svg')) ?>" alt="Logo WanSQ">
    <img class="logo-dark" src="<?= e(base_url('/assets/img/wan-dark.png')) ?>" data-fb="<?= e(base_url('/assets/img/wan-dark.svg')) ?>" alt="Logo WanSQ">
  </div>
  <h1 class="lc-name">WanSQ</h1>
  <p class="lc-motto">Wànxiàng Qiānwèn · Shēnsī Qiúzhēn</p>
  <p class="lc-greet"><?= e(time_greet()) ?>, selamat datang!.<br>Jelajahi pengetahuan, ajukan pertanyaan bermakna, dan berpikirlah mendalam bersama AI multimodal Anda.</p>

  <a class="btn-google" id="btnGoogle" href="<?= e(base_url('/auth/google_login.php')) ?>">
    <svg class="g-ic" width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.3 6.1 29.4 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.3 6.1 29.4 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.3 0-9.7-3.4-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C36.9 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.9z"/></svg>
    <span class="g-tx">Masuk dengan Google</span>
    <span class="g-spin" aria-hidden="true"></span>
  </a>

  <div class="lc-div"><span>atau</span></div>

  <details class="pw-box">
    <summary>Login dengan email &amp; password</summary>
    <form method="post" autocomplete="on">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="pw_login" value="1">
      <label>Email<input type="email" name="email" placeholder="email@anda.com" required></label>
      <label>Password<input type="password" name="password" placeholder="Password" required></label>
      <button class="btn-primary lc-submit" type="submit">Masuk</button>
    </form>
  </details>

  <?php if ($err): ?><p class="lc-err" role="alert"><?= e($err) ?></p><?php endif; ?>
  <p class="lc-foot">Independent AI project · multimodal reasoning · deep thinking</p>
</main>
<script src="<?= e(base_url('/assets/js/login.js')) ?>"></script>
</body>
</html>