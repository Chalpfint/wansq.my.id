Runtime directory. Keep production files and logs outside the release overwrite. Do not expose this directory over HTTP.
