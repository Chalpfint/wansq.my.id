<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/oauth.php';
session_boot();

$state = (string)($_GET['state'] ?? '');
$sessionState = $_SESSION['oauth_state'] ?? '';
if ($state === '' || $sessionState === '' || !hash_equals($sessionState, $state)) {
    http_response_code(403);
    exit('State OAuth tidak valid. Refresh halaman lalu coba login lagi.');
}
unset($_SESSION['oauth_state']);

if (isset($_GET['error'])) {
    http_response_code(403);
    exit('Google menolak login: ' . e($_GET['error'] . ' - ' . ($_GET['error_description'] ?? '')));
}
if (empty($_GET['code'])) { header('Location: ' . base_url('/index.php')); exit; }

try {
    $info = google_exchange((string)$_GET['code']);
} catch (RuntimeException $ex) {
    http_response_code(502);
    exit('<div style="font:14px/1.6 system-ui;padding:24px">' .
        '<h3>Login Google gagal</h3><p>' . e($ex->getMessage()) . '</p>' .
        '<p><b>Tindakan:</b> pastikan URI di atas terdaftar persis di Google Cloud Console → ' .
        'Credentials → OAuth Client → <i>Authorized redirect URIs</i> ' .
        '(termasuk varian http/https yang Anda pakai saat ini), dan Client Secret di ' .
        '<code>includes/config.php</code> adalah secret aktif hasil rotasi.</p>' .
        '<p><a href="' . e(base_url('/index.php')) . '">← Kembali ke login</a></p></div>');
}

$pdo = db();
$st = $pdo->prepare('SELECT * FROM users WHERE google_sub = ? OR email = ?');
$st->execute([$info['sub'], $info['email'] ?? '']);
$u = $st->fetch();

if ($u) {
    $pdo->prepare('UPDATE users SET google_sub=?, email=?, email_verified=?, full_name=?, avatar_google=? WHERE id=?')
        ->execute([$info['sub'], $info['email'], (int)($info['email_verified'] ?? 0),
                  $info['name'] ?? $u['full_name'], $info['picture'] ?? '', $u['id']]);
    $uid = (int)$u['id'];
} else {
    $base = preg_replace('/[^a-zA-Z0-9_.]/', '', explode('@', $info['email'] ?? 'user')[0]) ?: 'user';
    $uname = $base; $i = 1;
    $chk = $pdo->prepare('SELECT 1 FROM users WHERE username = ?');
    do { $chk->execute([$uname]); $exists = (bool)$chk->fetch(); if ($exists) $uname = $base . (++$i); } while ($exists);
    $pdo->prepare('INSERT INTO users (google_sub,email,email_verified,full_name,username,avatar_google) VALUES (?,?,?,?,?,?)')
        ->execute([$info['sub'], $info['email'], (int)($info['email_verified'] ?? 0),
                  $info['name'] ?? 'Pengguna WanSQ', $uname, $info['picture'] ?? '']);
    $uid = (int)$pdo->lastInsertId();
}
login_user($uid);
header('Location: ' . base_url('/app.php'));
exit;