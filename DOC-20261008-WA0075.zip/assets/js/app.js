/* ================= WanSQ Workspace v3.0 — core (state, chat, stream) ================= */
const W = JSON.parse(document.getElementById('wan-boot').textContent);
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const API = p => W.base + p;
const HDR = { 'X-CSRF-Token': W.csrf };
const CAPS = W.caps || {};
const MAX_ATT = CAPS.max_attach || 5, MAX_IMG = CAPS.max_images || 3;
const S = { convId: null, conv: null, chats: [], total: 0, offset: 0, filter: 'active', q: '', results: null, engine: 'auto',
            sending: false, abort: null, att: [], navGen: 0, streamGen: 0, web: false, imageMode: false, lastPayload: null, startRx: false,
            first: false, wd1: null, wd2: null, lastDone: null, listening: false, health: null, cropping: false,
            project: null, projects: [], pins: 0, diag: { math_blocks_detected: 0, math_typeset_calls: 0, math_typeset_ms: 0 } };
const closeStack = [];

/* ---------- i18n ---------- */
function T(k, v) {
  const d = (W.i18n && W.i18n[W.lang]) || {}, f = (W.i18n && W.i18n.id) || {};
  let s = d[k] !== undefined ? d[k] : (f[k] !== undefined ? f[k] : k);
  if (typeof s !== 'string') return s;
  if (v) for (const x in v) s = s.split('{' + x + '}').join(v[x]);
  return s;
}
function applyI18n(root = document) {
  $$('[data-i18n]', root).forEach(el => { el.textContent = T(el.dataset.i18n); });
  $$('[data-i18n-ph]', root).forEach(el => { el.placeholder = T(el.dataset.i18nPh); });
  $$('[data-i18n-title]', root).forEach(el => { el.title = T(el.dataset.i18nTitle); });
  $$('[data-i18n-aria]', root).forEach(el => { el.setAttribute('aria-label', T(el.dataset.i18nAria)); });
  if (root === document) document.documentElement.lang = W.lang;
}
const dateLocale = () => (W.lang === 'en' ? 'en-US' : 'id-ID');

/* ---------- util ---------- */
function on(sel, ev, fn, opts) { const el = (typeof sel === 'string') ? $(sel) : sel; if (el) el.addEventListener(ev, fn, opts); return el; }
function onAll(sel, ev, fn) { $$(sel).forEach(el => el.addEventListener(ev, fn)); }
let __errShown = false;
window.addEventListener('error', e => { if (__errShown) return; __errShown = true; toast('Script error: ' + (e.message || '?') + ' (' + (e.lineno || '?') + ')'); });
async function parseJson(r) {
  const txt = await r.text(); let j;
  try { j = JSON.parse(txt); } catch (e) { j = { ok: false, error: 'Respons server tidak valid (HTTP ' + r.status + ')' }; }
  if (j && j.code === 'schema') showBanner(j.error);
  return j;
}
const jpost = (u, d = {}) => fetch(u, { method: 'POST', headers: { ...HDR, 'Content-Type': 'application/json' }, body: JSON.stringify(d) }).then(parseJson);
const jget = u => fetch(u, { headers: HDR }).then(async r => { const j = await parseJson(r); if (!r.ok && !(j && j.error)) throw new Error('HTTP ' + r.status); return j; });
const fmtB = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : n > 1024 ? (n / 1024).toFixed(1) + ' KB' : n + ' B';
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const uid8 = () => (crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '').slice(0, 24) : Math.random().toString(36).slice(2) + Date.now().toString(36));
let toastT;
function toast(m) { const t = $('#toast'); if (!t) return; t.textContent = m; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, 3200); }
function showBanner(msg) { const b = $('#aiBanner'), t = $('#aiBannerTxt'); if (b && t) { t.textContent = msg; b.hidden = false; } }

function setStatus(kind, label, retry) {
  const el = $('#statusLine'); if (!el) return;
  if (!kind) { el.hidden = true; el.innerHTML = ''; return; }
  el.hidden = false;
  el.innerHTML = `<span class="status-pill${kind === 'err' ? ' err' : ''}">${kind === 'err' ? '⚠ ' : '<span class="spin"></span>'}${esc(label)}${retry ? ` <button id="stRetry">${esc(T('common.retry'))}</button>` : ''}</span>`;
  if (retry) on('#stRetry', 'click', () => { setStatus(null); retryLast(); });
}
const statusLabel = key => T('status.' + key);
function clearWd() { clearTimeout(S.wd1); clearTimeout(S.wd2); S.wd1 = S.wd2 = null; }
function retryLast() {
  if (!S.lastPayload) return;
  if (S.lastPayload.conversation_id && +S.lastPayload.conversation_id !== +S.convId) return;
  send({ retry: true });
}
function unlockComposer() { S.sending = false; const bs = $('#btnSend'), bt = $('#btnStop'); if (bs) bs.hidden = false; if (bt) bt.hidden = true; }
function invalidateGeneration(reason = 'navigation') {
  S.navGen++; S.streamGen++;
  if (S.abort) { try { S.abort.abort(reason); } catch (e) {} }
  S.abort = null; S.sending = false; clearWd();
  return S.navGen;
}
function runIsCurrent(run) { return !!run && run.gen === S.streamGen && run.nav === S.navGen && (!run.convId || +run.convId === +S.convId); }
const mathJobs = new WeakMap();
const streamPaints = new WeakMap();
const MATH_BATCH = 4;
function mathSourcePresent(root) {
  if (!root) return false;
  return !!root.querySelector('.math-display,.math-inline');
}
function scheduleMathTypeset(root, opts = {}) {
  if (!root || !window.MathJax || typeof window.MathJax.typesetPromise !== 'function') return;
  if (!mathSourcePresent(root)) return;
  const prev = mathJobs.get(root);
  if (prev && prev.timer) clearTimeout(prev.timer);
  const delay = opts.immediate ? 30 : Math.max(180, Number(opts.delay || 420));
  const job = { timer: setTimeout(() => typesetMathBatch(root), delay) };
  mathJobs.set(root, job);
}
async function typesetMathBatch(root) {
  const job = mathJobs.get(root);
  if (!root || !root.isConnected || !window.MathJax || typeof window.MathJax.typesetPromise !== 'function') {
    if (root) mathJobs.delete(root);
    return;
  }
  const nodes = [...root.querySelectorAll('.math-display,.math-inline')].filter(n => !n.dataset.mjxDone);
  if (!nodes.length) { mathJobs.delete(root); return; }
  const batch = nodes.slice(0, MATH_BATCH);
  const started = performance.now();
  try {
    // Only typeset fresh math wrappers. Never typeset the entire conversation root.
    // This is critical for long chats: MathJax work stays bounded and the UI remains responsive.
    await window.MathJax.typesetPromise(batch);
    batch.forEach(n => { n.dataset.mjxDone = '1'; });
    S.diag.math_typeset_calls++;
    S.diag.math_typeset_ms += Math.round(performance.now() - started);
  } catch (e) {
    // Keep the original TeX visible and continue with the remaining formulas.
    batch.forEach(n => { n.dataset.mjxError = '1'; n.dataset.mjxDone = '1'; });
  } finally {
    renderDev();
  }
  const remaining = [...root.querySelectorAll('.math-display,.math-inline')].some(n => !n.dataset.mjxDone);
  if (remaining && root.isConnected) {
    const next = { timer: setTimeout(() => typesetMathBatch(root), 20) };
    mathJobs.set(root, next);
  } else {
    mathJobs.delete(root);
  }
}
function typesetMath(root, opts = {}) { scheduleMathTypeset(root, opts); }

/* ---------- modal & keyboard ---------- */
function openModal(id) { const m = $('#' + id); if (!m) return; m.hidden = false; closeStack.push({ id, opener: document.activeElement }); const f = m.querySelector('input,textarea,button'); if (f) f.focus(); }
function closeModal(id) {
  const m = $('#' + id); if (!m || m.hidden) return; m.hidden = true;
  const i = closeStack.findIndex(x => x.id === id); if (i >= 0) { const o = closeStack.splice(i, 1)[0]; if (o.opener && o.opener.focus) o.opener.focus(); }
  if (id === 'camModal') stopCam();
  if (id === 'setModal') endCrop();
}
function closeTop() {
  if ($('.ctx')) { $('.ctx').remove(); return true; }
  for (const p of ['#engineMenu', '#convActionsMenu', '#toolsPop', '#acctMenu', '#pinsPop']) { const el = $(p); if (el && !el.hidden) { el.hidden = true; return true; } }
  if (closeStack.length) { closeModal(closeStack[closeStack.length - 1].id); return true; }
  if ($('#sidebar')?.classList.contains('open')) { $('#sidebar').classList.remove('open'); return true; }
  return false;
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { if (closeTop()) e.preventDefault(); return; }
  const k = e.key.toLowerCase();
  if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === 'k') { e.preventDefault(); openPalette(); return; }
  if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === 'o') { e.preventDefault(); newChat(); return; }
  if (e.altKey && !e.ctrlKey && k === 'n') { e.preventDefault(); newChat(); return; }
  if (e.ctrlKey && e.shiftKey && k === 'd') { const d = $('#devPanel'); if (d) { d.hidden = !d.hidden; if (!d.hidden) renderDev(); } }
});
document.addEventListener('click', e => {
  if (!e.target.closest('.ctx')) $('.ctx')?.remove();
  if (!e.target.closest('#engineMenu,#engineBtn')) { const m = $('#engineMenu'); if (m) m.hidden = true; }
  if (!e.target.closest('#convActionsMenu,#btnConvActions')) { const p = $('#convActionsMenu'); if (p) p.hidden = true; $('#btnConvActions')?.setAttribute('aria-expanded','false'); }
  if (!e.target.closest('#pinsPop,#btnPins')) { const p = $('#pinsPop'); if (p && !p.hidden) { p.hidden = true; $('#btnPins')?.setAttribute('aria-expanded', 'false'); } }
  if (!e.target.closest('#acctMenu,#acctBtn')) { const m = $('#acctMenu'); if (m) m.hidden = true; $('#acctBtn')?.setAttribute('aria-expanded', 'false'); }
  if (e.target.classList.contains('modal')) closeModal(e.target.id);
  if (e.target.closest('[data-close-banner]')) { const b = $('#aiBanner'); if (b) b.hidden = true; }
});
onAll('[data-close]', 'click', e => closeModal(e.currentTarget.dataset.close));

/* ---------- popup menu helper (posisi di dekat elemen) ---------- */
function popMenu(anchor, items, opts = {}) {
  $('.ctx')?.remove();
  const m = document.createElement('div'); m.className = 'ctx'; m.setAttribute('role', 'menu');
  m.innerHTML = items.map((it, i) => it === '-' ? '<div class="mi-sep" role="separator"></div>'
    : it.head ? `<div class="ctx-head">${esc(it.head)}</div>`
    : `<button role="menuitem" data-i="${i}"${it.danger ? ' class="danger"' : ''}>${esc(it.label)}</button>`).join('');
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  const w = m.offsetWidth, h = m.offsetHeight;
  m.style.left = Math.max(8, Math.min(r.left + (opts.alignRight ? r.width - w : 0), innerWidth - w - 8)) + 'px';
  m.style.top = ((r.bottom + h + 12 > innerHeight) ? Math.max(8, r.top - h - 4) : r.bottom + 4) + 'px';
  m.onclick = ev => { const b = ev.target.closest('[data-i]'); if (!b) return; const it = items[+b.dataset.i]; m.remove(); if (it && it.run) it.run(); };
  m.querySelector('button')?.focus();
  m.addEventListener('keydown', ev => { const bs = [...m.querySelectorAll('button')]; const i = bs.indexOf(document.activeElement);
    if (ev.key === 'ArrowDown') { ev.preventDefault(); (bs[i + 1] || bs[0]).focus(); } if (ev.key === 'ArrowUp') { ev.preventDefault(); (bs[i - 1] || bs[bs.length - 1]).focus(); } });
  return m;
}

/* ---------- sidebar: daftar & hasil pencarian ---------- */
function groupOf(dt) {
  const d = new Date(String(dt).replace(' ', 'T')), t = new Date(); t.setHours(0, 0, 0, 0);
  const df = Math.floor((t - new Date(d).setHours(0, 0, 0, 0)) / 864e5);
  return df <= 0 ? T('grp.today') : df === 1 ? T('grp.yesterday') : df <= 7 ? T('grp.week') : df <= 30 ? T('grp.month') : T('grp.older');
}
const projById = id => S.projects.find(p => +p.id === +id);
function renderChats() {
  const box = $('#convList'); if (!box) return;
  box.innerHTML = '';
  if (S.q) return renderSearchResults(box);
  const list = S.chats;
  if (!list.length) box.innerHTML = `<p class="list-empty">${esc(S.filter === 'archived' ? T('sb.empty.archive') : T('sb.empty'))}</p>`;
  const g = {}; list.forEach(c => { const k = groupOf(c.updated_at); (g[k] = g[k] || []).push(c); });
  for (const [k, items] of Object.entries(g)) {
    box.insertAdjacentHTML('beforeend', `<div class="chat-group">${esc(k)}</div>`);
    items.forEach(c => { const p = (!S.project && c.project_id) ? projById(c.project_id) : null;
      box.insertAdjacentHTML('beforeend', `<div class="conv-item${c.id === S.convId ? ' active' : ''}" data-id="${c.id}" data-pinned="${c.pinned ? 1 : 0}" title="${esc(c.title)}" tabindex="0" role="button"><span class="ci-t">${c.pinned ? '<span class="ci-pin" title="' + esc(T('pin.chat.badge')) + '">📌</span>' : ''}${p ? `<span class="ci-proj" title="${esc(p.name)}">${esc(p.icon)}</span>` : ''}${esc(c.title)}</span><button class="dots" data-menu="${c.id}" aria-label="${esc(T('sb.options'))}" aria-haspopup="menu">⋯</button></div>`); });
  }
  const bm = $('#btnMore'); if (bm) bm.hidden = !(S.chats.length < S.total);
}
function srcBadge(s) { return { title: T('srch.title'), user: T('srch.user'), assistant: T('srch.ai'), pinned: '📌 ' + T('srch.pinned'), file: '📄 ' + T('srch.file') }[s] || ''; }
function renderSearchResults(box) {
  const R = S.results; const bm = $('#btnMore');
  if (!R) { box.innerHTML = `<p class="list-empty">${esc(T('srch.searching'))}</p>`; if (bm) bm.hidden = true; return; }
  if (!R.items.length) { box.innerHTML = `<p class="list-empty">${esc(T('srch.none', { q: S.q }))}</p>`; if (bm) bm.hidden = true; return; }
  box.insertAdjacentHTML('beforeend', `<div class="chat-group">${esc(T('srch.count', { n: R.total }))}</div>`);
  R.items.forEach(it => {
    const loc = it.project ? `${esc(it.project.icon)} ${esc(it.project.name)} / ` : '';
    const dt = new Date(String(it.updated_at).replace(' ', 'T')).toLocaleDateString(dateLocale(), { day: 'numeric', month: 'short', year: 'numeric' });
    box.insertAdjacentHTML('beforeend', `<div class="conv-item sr${it.id === S.convId ? ' active' : ''}" data-id="${it.id}" data-mid="${it.message_id || ''}" tabindex="0" role="button">
      <div class="sr-t">${loc}${esc(it.title)}</div><div class="sr-s">${it.snippet}</div>
      <div class="sr-m"><span>${esc(srcBadge(it.source))}${it.page ? ' · ' + esc(T('srch.page', { n: it.page })) : ''}</span><span>${esc(dt)}</span></div></div>`);
  });
  if (bm) bm.hidden = R.next == null;
}
async function loadChats(reset = true) {
  if (S.q) return;
  if (reset) S.offset = 0;
  const r = await jget(API('/api/chat.php?action=list&filter=' + S.filter + '&offset=' + S.offset + (S.project ? '&project=' + S.project : '')));
  S.total = r.total || 0;
  S.chats = reset ? (r.chats || []) : S.chats.concat(r.chats || []);
  renderChats();
}
async function runSearch(more = false) {
  const q = S.q; if (!q) { S.results = null; return renderChats(); }
  const off = more && S.results ? S.results.next : 0;
  try {
    const r = await jget(API('/api/search.php?scope=chats&limit=20&offset=' + off + '&q=' + encodeURIComponent(q) + (S.project ? '&project=' + S.project : '')));
    if (q !== S.q) return;   // hasil basi
    if (!r.ok) { toast(r.error || T('srch.fail')); return; }
    S.results = more && S.results ? { ...r, items: S.results.items.concat(r.items) } : r;
    S.results.terms = r.terms || [];
  } catch (e) { toast(T('srch.fail')); return; }
  renderChats();
}
const runSearchDebounced = debounce(() => runSearch(false), 250);
on('#btnMore', 'click', async () => { if (S.q) return runSearch(true); S.offset += 50; await loadChats(false); });
on('#chatSearch', 'input', e => { S.q = e.target.value.trim(); S.results = null; if (S.q) { renderChats(); runSearchDebounced(); } else renderChats() || loadChats(); });
on('#chatSearch', 'keydown', e => { if (e.key === 'Escape' && S.q) { e.target.value = ''; S.q = ''; S.results = null; loadChats(); e.stopPropagation(); } });
onAll('.sb-tab', 'click', e => { S.filter = e.currentTarget.dataset.filter;
  $$('.sb-tab').forEach(x => { x.classList.toggle('active', x === e.currentTarget); x.setAttribute('aria-selected', String(x === e.currentTarget)); });
  loadChats(); });

function ctxMenu(id, anchor) {
  const c = S.chats.find(v => v.id === id) || (S.results && S.results.items.find(v => v.id === id)); if (!c) return;
  const archived = +c.archived;
  const pinned = +c.pinned === 1;
  const items = [
    { label: (pinned ? '📌 ' + T('ctx.unpin') : '📌 ' + T('ctx.pin')), run: async () => { const r = await jpost(API('/api/chat.php?action=pin_conversation'), { id, pinned: !pinned }); if (r.ok) { c.pinned = r.pinned ? 1 : 0; refreshLists(); if (id === S.convId) updateConvHeader(); toast(r.pinned ? T('pin.chat.done') : T('pin.chat.removed')); } else toast(r.error || T('toast.mem_fail')); } },
    { label: '✏️ ' + T('ctx.rename'), run: async () => { const t = prompt(T('ctx.rename.prompt'), c.title); if (t && (await jpost(API('/api/chat.php?action=rename'), { id, title: t })).ok) { if (id === S.convId) { S.conv && (S.conv.title = t); setTitle(t); } refreshLists(); } } },
    { label: '📁 ' + T('ctx.move'), run: () => openMovePicker(id, c.project_id || (c.project && c.project.id)) },
  ];
  if (c.project_id || c.project) items.push({ label: '📂 ' + T('ctx.unmove'), run: async () => { await jpost(API('/api/chat.php?action=move'), { id, project_id: 0 }); if (id === S.convId) openConv(id); refreshLists(); loadProjects(); toast(T('toast.moved_out')); } });
  if (CAPS.share) items.push({ label: '🔗 ' + T('ctx.share'), run: () => openShare(id) });
  items.push({ label: '⇩ ' + T('ctx.download'), run: () => window.wanDownloadConv && window.wanDownloadConv(id, c.title) });
  items.push('-');
  items.push({ label: (archived ? '📤 ' + T('ctx.unarchive') : '🗄 ' + T('ctx.archive')), run: async () => { await jpost(API('/api/chat.php?action=archive'), { id }); if (id === S.convId) openConv(null); refreshLists(); toast(archived ? T('toast.unarchived') : T('toast.archived')); } });
  items.push({ label: '🗑 ' + T('ctx.delete'), danger: true, run: async () => { if (!confirm(T('ctx.delete.confirm'))) return; await jpost(API('/api/chat.php?action=delete'), { id }); if (id === S.convId) openConv(null); refreshLists(); loadProjects(); toast(T('toast.trashed')); } });
  popMenu(anchor, items, { alignRight: true });
}
function refreshLists() { if (S.q) runSearch(false); else loadChats(); }
on('#convList', 'click', e => {
  const d = e.target.closest('[data-menu]');
  if (d) { ctxMenu(+d.dataset.menu, d); e.stopPropagation(); return; }
  const it = e.target.closest('.conv-item'); if (it) { openConv(+it.dataset.id, { jump: +it.dataset.mid || 0, terms: S.results ? S.results.terms : null }); $('#sidebar')?.classList.remove('open'); }
});
on('#convList', 'keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('conv-item')) { e.preventDefault(); e.target.click(); } });
function newChat() { openConv(null); $('#sidebar')?.classList.remove('open'); $('#input')?.focus(); }
on('#btnNewChat', 'click', newChat);
on('#btnSideOpen', 'click', () => $('#sidebar')?.classList.add('open'));
on('#btnSideClose', 'click', () => $('#sidebar')?.classList.remove('open'));

/* ---------- pesan ---------- */
const AV_AI = `<span class="av"><img class="logo-light" src="${W.base}/assets/img/wan-blue.svg" alt=""><img class="logo-dark" src="${W.base}/assets/img/wan-dark.svg" alt=""></span>`;
function srcBlock(items, mid = 0) {
  const seen = new Set();
  const uniq = (items || []).filter(s => {
    const key = s.type === 'doc' ? 'doc:' + (+s.att || s.title || '') : 'web:' + (s.url || s.title || '');
    if (seen.has(key)) return false; seen.add(key); return true;
  });
  const web = uniq.filter(s => s.type !== 'doc'), docs = uniq.filter(s => s.type === 'doc');
  const attr = mid ? ` data-for-mid="${+mid}"` : '';
  const d = new Date().toLocaleDateString(dateLocale(), { day: 'numeric', month: 'short', year: 'numeric' });
  let h = '';
  if (docs.length) h += `<div class="src-block"${attr}><span class="lbl">${esc(T('src.doc'))}</span>${docs.map(s => `<button class="src-chip doc" data-doc="${+s.att}" title="${esc(s.title)}">📄 ${esc(s.title).slice(0, 34)} — ${esc(s.pages)}</button>`).join('')}</div>`;
  if (web.length) h += `<div class="src-block"${attr}><span class="lbl">${esc(T('src.web', { d }))}</span>${web.map((s, i) => `<a class="src-chip" href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">[${i + 1}] ${esc(s.title).slice(0, 42)}</a>`).join('')}</div>`;
  return h;
}
const attUrl = a => API('/api/file.php?id=' + a.id);
/** Fallback tahan-error untuk preview gambar: browser default "broken image" diganti UI yang jujur + retry/open. */
function wanImgFallback(img) {
  if (img.dataset.wanFailed) return;
  img.dataset.wanFailed = '1';
  const url = img.dataset.src || img.src; const name = img.getAttribute('alt') || '';
  const box = document.createElement('span'); box.className = 'att-broken'; box.setAttribute('role', 'img'); box.setAttribute('aria-label', name);
  box.innerHTML = `<span class="ab-ic" aria-hidden="true">🖼️</span><span class="ab-txt">${esc(T('att.preview_fail'))}</span>`
    + `<span class="ab-actions"><button type="button" data-retry>${esc(T('common.retry'))}</button><a href="${esc(url)}${url.includes('?') ? '&' : '?'}dl=1" target="_blank" rel="noopener">${esc(T('att.open'))}</a></span>`;
  box.querySelector('[data-retry]').onclick = () => {
    const img2 = document.createElement('img');
    img2.loading = 'lazy'; img2.alt = name; img2.dataset.src = url; img2.dataset.lb = img.dataset.lb || url;
    img2.onerror = () => wanImgFallback(img2);
    img2.src = url + (url.includes('?') ? '&' : '?') + '_r=' + Date.now();
    box.replaceWith(img2);
  };
  img.replaceWith(box);
}
window.wanImgFallback = wanImgFallback;
function attHtml(atts) {
  if (!atts || !atts.length) return '';
  return `<div class="att-row" role="group" aria-label="${esc(T('att.group'))}">${atts.map(a => a.kind === 'image'
    ? `<img src="${esc(attUrl(a))}" data-src="${esc(attUrl(a))}" data-lb="${esc(attUrl(a))}" alt="${esc(a.original_name)}" loading="lazy" data-wanfb="1">`
    : `<button class="att-doc" data-doc="${+a.id}">📄 ${esc(a.original_name)}${a.pages ? ` <small>${+a.pages}${a.mime === 'application/pdf' ? 'p' : ''}</small>` : ''}</button>`).join('')}</div>`;
}
function actionsHtml(role) {
  const b = (a, ic, key, extra = '') => `<button data-a="${a}"${extra}>${ic ? ic + ' ' : ''}<span data-i18n="${key}">${esc(T(key))}</span></button>`;
  return role === 'assistant'
    ? b('copy', '⧉', 'msg.copy') + `<button data-a="tts" aria-pressed="false" title="${esc(T('tts.read'))}" data-i18n-title="tts.read" aria-label="${esc(T('tts.read'))}" data-i18n-aria="tts.read">🔊</button>` + `<span class="split">${b('regen', '⟳', 'msg.regen')}<button data-a="regenmenu" aria-haspopup="menu" data-i18n-aria="msg.regen.more" aria-label="${esc(T('msg.regen.more'))}">▾</button></span>`
      + `<button data-a="more" aria-haspopup="menu" data-i18n-aria="msg.more" aria-label="${esc(T('msg.more'))}">⋯</button>`
    : b('edit', '✏️', 'msg.edit') + b('copy', '⧉', 'msg.copy') + `<button data-a="more" aria-haspopup="menu" data-i18n-aria="msg.more" aria-label="${esc(T('msg.more'))}">⋯</button>`;
}
function msgEl(role, content, atts = [], meta = {}, id = null, pinned = false) {
  const el = document.createElement('div');
  el.className = 'msg ' + (role === 'user' ? 'user' : 'assistant');
  el.setAttribute('role', 'article'); el.setAttribute('aria-label', role === 'user' ? (W.user.name || W.user.username) : 'WanSQ');
  if (id) el.dataset.mid = id;
  if (pinned) el.dataset.pinned = '1';
  const av = role === 'user' ? `<span class="av user"><img src="${esc(W.user.avatar)}" data-fb="${W.base}/assets/img/avatar-default.svg" alt=""></span>` : AV_AI;
  const srcs = (meta && meta.sources && meta.sources.length) ? srcBlock(meta.sources, id || 0) : '';
  el.innerHTML = `${av}<div class="body"><div class="who">${role === 'user' ? esc(W.user.name || W.user.username) : 'WanSQ'}<span class="pin-badge" ${pinned ? '' : 'hidden'} title="${esc(T('pin.badge'))}">📌 <span class="sr-only">${esc(T('pin.badge'))}</span></span>${meta && meta.partial ? ` <em class="warn">(${esc(T('msg.partial'))})</em>` : ''}</div>${attHtml(atts)}<div class="bubble"${role === 'assistant' ? ' style="display:contents"' : ''}><div class="md"></div></div>${srcs}<div class="msg-actions">${actionsHtml(role)}</div></div>`;
  const mdEl = el.querySelector('.md'); mdEl.innerHTML = role === 'assistant' ? md(content) : esc(content).replace(/\n/g, '<br>'); mdEl.dataset.raw = content;
  if (meta && meta.image) el.dataset.gen = '1';
  return el;
}
function typingEl() { const el = document.createElement('div'); el.className = 'msg assistant';
  el.innerHTML = `${AV_AI}<div class="body"><div class="who">WanSQ</div><div class="typing-dots" aria-hidden="true"><span></span><span></span><span></span></div></div>`; return el; }
const scrollBottom = () => { const c = $('#chatScroll'); if (c) c.scrollTop = c.scrollHeight; };

/* follow-up suggestions (dapat diklik) */
function renderFollowups(msgNode, items) {
  $$('#messages .followups').forEach(x => x.remove());
  if (!msgNode || !items || !items.length) return;
  const d = document.createElement('div'); d.className = 'followups'; d.setAttribute('role', 'group'); d.setAttribute('aria-label', T('fu.title'));
  d.innerHTML = `<span class="fu-lbl">${esc(T('fu.title'))}</span>` + items.map((f, i) => `<button class="fu-chip" data-fu="${i}" title="${esc(f.prompt)}">${esc(f.label)}</button>`).join('');
  d._items = items; msgNode.querySelector('.body').appendChild(d);
}
on('#messages', 'click', e => { const b = e.target.closest('.fu-chip'); if (!b) return; const box = b.closest('.followups'); const it = box._items[+b.dataset.fu]; if (it) { box.remove(); send({ text: it.prompt }); } });

/* empty state (capability-aware & configurable lewat kamus bahasa) */
function emptyState() {
  const items = (T('empty.items') || []).filter(x => {
    if (x.need === 'vision') return CAPS.vision; if (x.need === 'image_gen') return CAPS.image_gen; if (x.need === 'web') return true; return true; });
  const first = W.user.name ? W.user.name.split(' ')[0] : '';
  return `<div class="empty"><img class="logo-light" src="${W.base}/assets/img/wan-blue.png" data-fb="${W.base}/assets/img/wan-blue.svg" alt=""><img class="logo-dark" src="${W.base}/assets/img/wan-dark.png" data-fb="${W.base}/assets/img/wan-dark.svg" alt=""><h2>${esc(T('empty.title'))}</h2><p>${esc(T('empty.sub', { name: first }))}</p><div class="sug-grid">${items.map((x, i) => `<button class="sug" data-sug="${i}">${esc(x.ic)} ${esc(x.label)}</button>`).join('')}</div></div>`;
}
function onSuggestion(i) {
  const items = (T('empty.items') || []).filter(x => (x.need === 'vision' ? CAPS.vision : x.need === 'image_gen' ? CAPS.image_gen : true));
  const x = items[i]; if (!x) return;
  if (x.act === 'attach') { const inp = $('#input'); if (inp && !inp.value) { inp.value = x.fill || ''; autoSize(); } $('#filePick')?.click(); return; }
  if (x.act === 'image') { const inp = $('#input'); if (inp) { inp.value = x.fill || ''; autoSize(); inp.focus(); } return; }
  send({ text: x.q });
}
function setTitle(t) { const ct = $('#convTitle'); if (ct) { ct.textContent = t || T('conv.new'); if (!t) ct.dataset.i18n = 'conv.new'; else delete ct.dataset.i18n; } document.title = (t ? t + ' · ' : '') + 'WanSQ'; }

function highlightTerms(root, terms) {
  if (!terms || !terms.length) return;
  const re = new RegExp('(' + terms.map(t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'gi');
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.parentElement && !n.parentElement.closest('pre,mark')) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT });
  const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
  nodes.forEach(n => { if (!re.test(n.nodeValue)) return; re.lastIndex = 0;
    const span = document.createElement('span'); span.innerHTML = esc(n.nodeValue).replace(new RegExp('(' + terms.map(t => esc(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'gi'), '<mark>$1</mark>'); n.replaceWith(...span.childNodes); });
}

async function openConv(id, opts = {}) {
  const nav = invalidateGeneration('navigation');
  S.convId = id; S.conv = null; S.lastPayload = null; S.att = []; renderAtt();
  const box = $('#messages'); if (!box) return;
  box.innerHTML = ''; setStatus(null); $('#pinsPop') && ($('#pinsPop').hidden = true); unlockComposer();
  if (!id) { setTitle(null); box.innerHTML = emptyState(); updateConvHeader(); restoreDraft(); renderChats(); const btn = $('#btnConvActions'); if (btn) btn.hidden = true; return; }
  const r = await jget(API('/api/chat.php?action=messages&id=' + id));
  if (nav !== S.navGen || id !== S.convId) return;
  if (!r.ok) { toast(r.error || T('err.open')); return openConv(null); }
  S.conv = r.conv; S.convId = id;
  const btn = $('#btnConvActions'); if (btn) btn.hidden = false;
  setTitle(r.conv.title);
  const msgs = r.messages || []; let lastA = null;
  msgs.forEach(m => { const el = msgEl(m.role, m.content, (r.attachments || {})[m.id] || [], m.meta, m.id, !!m.pinned); box.appendChild(el); if (m.role === 'assistant') { lastA = { el, m }; if (m.meta && m.meta.sources) { /* sudah dirender oleh msgEl */ } } });
  S.pins = msgs.filter(m => m.pinned).length;
  if (lastA && lastA.m.meta && lastA.m.meta.followups && msgs[msgs.length - 1] === lastA.m) renderFollowups(lastA.el, lastA.m.meta.followups);
  // Restore Markdown first, then perform exactly one MathJax pass for the loaded conversation.
  scheduleMathTypeset(box, { immediate: true });
  updateConvHeader(); restoreDraft(); renderChats();
  if (opts.jump) { const t = box.querySelector(`[data-mid="${opts.jump}"]`); if (t) { highlightTerms(t.querySelector('.md'), opts.terms); t.scrollIntoView({ block: 'center' }); t.classList.add('flash'); setTimeout(() => t.classList.remove('flash'), 2400); return; } }
  scrollBottom();
}

/* ---------- send / stream / stop ---------- */
function failSend(run, msg) {
  if (run.typ) run.typ.remove();
  $$('#messages .msg.streaming').forEach(x => x.classList.remove('streaming'));
  clearWd(); unlockComposer();
  setStatus('err', msg, true);
}
async function send(opts = {}) {
  if (S.sending) return;
  if (!opts.retry && S.att.some(a => ['uploading', 'processing', 'ocr', 'needs_ocr'].includes(a.state))) { toast(T('att.wait')); return; }
  if (!opts.retry && S.att.some(a => a.state === 'failed')) { toast(T('att.failed')); return; }
  const nav = S.navGen;
  if (opts.retry && S.lastPayload && S.lastPayload.conversation_id && +S.lastPayload.conversation_id !== +S.convId) return;
  const input = $('#input');
  let text = opts.text !== undefined ? opts.text : (input ? input.value.trim() : '');
  if (!opts.retry && !opts.regen && !opts.transform && !text && !S.att.length) return;
  const box = $('#messages');
  const gen = ++S.streamGen;
  const runConvId = S.convId;
  S.sending = true; S.abort = new AbortController(); S.startRx = false; S.first = false; S.lastDone = null;
  const bs = $('#btnSend'), bt = $('#btnStop'); if (bs) bs.hidden = true; if (bt) bt.hidden = false;
  $('#messages .empty')?.remove(); $$('#messages .followups').forEach(x => x.remove());
  const run = { typ: null, el: null, mdEl: null, raw: '', src: null, img: null, gen, nav, convId: runConvId };
  if (opts.retry) {
    // Reuse CID so the backend deduplicates the user message, but issue a fresh correlation ID.
    S.lastPayload = { ...S.lastPayload, request_id: uid8() };
  } else {
    S.lastPayload = { conversation_id: S.convId, project_id: (!S.convId && S.project) ? S.project : 0, text, cid: uid8(), request_id: uid8(),
      attachments: S.att.filter(a => a.id).map(a => a.id).slice(0, MAX_ATT), web: false, engine: S.engine,
      mode: 'auto', regenerate: !!opts.regen, style: opts.style || '', transform: opts.transform || null };
    if (opts.regen) { // buang balasan lama dari tampilan (server mengarsipkan, bukan menghapus)
      const all = $$('#messages .msg'); for (let i = all.length - 1; i >= 0 && !all[i].classList.contains('user'); i--) all[i].remove();
    } else {
      box.appendChild(msgEl('user', text || (opts.transform ? '↻' : ''), S.att.filter(a => a.id).map(a => ({ id: a.id, kind: a.kind, original_name: a.name, mime: a.mime, pages: a.pages }))));
      if (input) { input.value = ''; autoSize(); clearDraft(); }
    }
    S.att = []; renderAtt();
  }
  const typ = typingEl(); run.typ = typ; box.appendChild(typ); scrollBottom();
  setStatus('run', statusLabel('preparing'));
  S.wd1 = setTimeout(() => { if (S.sending && !S.startRx) failSend(run, T('err.timeout_conn')); }, 20000);
  let evDone = false;
  try {
    const res = await fetch(API('/api/chat.php?action=send'), { method: 'POST', signal: S.abort.signal, headers: { ...HDR, 'Content-Type': 'application/json' }, body: JSON.stringify(S.lastPayload) });
    if (!res.ok) { const j = await res.json().catch(() => ({})); const er = new Error(j.error || ('HTTP ' + res.status)); er.http = true; throw er; }
    const rd = res.body.getReader(); const dec = new TextDecoder(); let buf = '';
    while (true) {
      const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
        const line = chunk.split('\n').find(l => l.startsWith('data:')); if (!line) continue;
        let ev; try { ev = JSON.parse(line.slice(5)); } catch (e) { continue; }
        if (ev.rid && S.lastPayload && ev.rid !== S.lastPayload.request_id) continue;
        if (!runIsCurrent(run)) continue;
        if (ev.t === 'start') { S.startRx = true; const isNew = !S.convId; S.convId = ev.conv; run.convId = ev.conv; if (S.lastPayload) S.lastPayload.conversation_id = ev.conv; clearTimeout(S.wd1);
          if (isNew) { S.conv = S.conv || { id: ev.conv, title: T('conv.new'), project: ev.project ? (projById(ev.project) ? { id: ev.project, name: projById(ev.project).name, icon: projById(ev.project).icon } : null) : null, share: null }; updateConvHeader(); }
          const u = $$('#messages .msg.user').pop(); if (u && ev.mid && !u.dataset.mid) u.dataset.mid = ev.mid;
          S.wd2 = setTimeout(() => { if (S.sending && !S.first && !evDone) failSend(run, T('err.timeout_first')); }, 60000); }
        if (ev.t === 'status') { setStatus('run', statusLabel(ev.key)); clearTimeout(S.wd2); S.wd2 = setTimeout(() => { if (S.sending && !S.first && !evDone) failSend(run, T('err.timeout_first')); }, 90000); }
        if (ev.t === 'sources') run.src = ev.items;
        if (ev.t === 'delta') {
          if (!S.first) { S.first = true; clearTimeout(S.wd2); typ.remove(); setStatus('run', statusLabel('generating'));
            const el = msgEl('assistant', ''); el.classList.add('streaming'); box.appendChild(el); run.el = el; run.mdEl = el.querySelector('.md'); }
          run.raw += ev.c;
          // Coalesce bursty SSE deltas into one DOM/Markdown paint per animation frame.
          // MathJax is intentionally never invoked here; it runs once after completion.
          if (run.mdEl && !streamPaints.get(run.mdEl)) {
            // 50ms batching (~20 paints/s max) prevents long Markdown responses from
            // becoming an O(n²) DOM workload while still looking live to the user.
            streamPaints.set(run.mdEl, setTimeout(() => {
              streamPaints.delete(run.mdEl);
              if (runIsCurrent(run) && run.mdEl) { run.mdEl.innerHTML = md(run.raw); scrollBottom(); }
            }, 50));
          }
        }
        if (ev.t === 'image') {
          typ.remove(); const el = msgEl('assistant', ev.caption || '', [{ id: ev.id, kind: 'image', original_name: 'image', mime: 'image/png' }], { image: true }, ev.mid); box.appendChild(el); run.el = el; run.img = true; scrollBottom();
        }
        if (ev.t === 'title') { setTitle(ev.title); if (S.conv) S.conv.title = ev.title; loadChats(); }
        if (ev.t === 'followups') { if (run.el && run.el.isConnected && run.el === $$('#messages .msg').pop()) renderFollowups(run.el, ev.items); }
        if (ev.t === 'done') {
          evDone = true; S.lastDone = ev; clearWd();
          if (run.el) { run.el.classList.remove('streaming'); if (ev.mid) run.el.dataset.mid = ev.mid; }
          if (run.mdEl) {
            const pendingPaint = streamPaints.get(run.mdEl); if (pendingPaint) { clearTimeout(pendingPaint); streamPaints.delete(run.mdEl); }
            run.mdEl.innerHTML = md(run.raw); run.mdEl.dataset.raw = run.raw; typesetMath(run.mdEl, { immediate: true });
            if (run.src && run.src.length) { const parent=run.mdEl.closest('.body'); parent?.querySelectorAll('.source-block').forEach(x=>x.remove()); const bubble=run.mdEl.closest('.bubble'); bubble?.insertAdjacentHTML('afterend', srcBlock(run.src, run.el?.dataset.mid || 0)); }
            if (ev.partial) run.el.querySelector('.who').insertAdjacentHTML('beforeend', ` <em class="warn">(${esc(T('msg.partial'))})</em>`); }
          setStatus(null); unlockComposer(); loadChats(); scrollBottom();   // composer dibuka segera; follow-up/judul menyusul
        }
        if (ev.t === 'error') { if (typ.isConnected) typ.remove(); clearWd(); evDone = true; unlockComposer(); const msg = ev.kind === 'database_connection_lost' ? 'Koneksi database terputus setelah proses panjang. Jawaban dapat disimpan sebagian; buka ulang percakapan lalu coba lagi bila perlu.' : (ev.error || 'WanSQ mengalami gangguan internal.'); setStatus('err', msg, true); }
      }
    }
  } catch (e) {
    if (!runIsCurrent(run)) return;
    if (typ.isConnected) typ.remove(); clearWd();
    if (e.name === 'AbortError') { setStatus(null); toast(T('toast.stopped')); if (run.mdEl) { run.el.classList.remove('streaming'); run.mdEl.dataset.raw = run.raw; } unlockComposer(); }
    else if (e.http) failSend(run, e.message || T('err.network'));
    else failSend(run, T('err.network'));
    return;
  }
  if (!runIsCurrent(run)) return;
  clearWd(); if (S.sending) { unlockComposer(); if (!evDone) { if (typ.isConnected) typ.remove(); if (!run.raw && !run.img) setStatus('err', T('err.empty_stream'), true); else setStatus(null); } }
  loadChats(); scrollBottom();
}
on('#btnSend', 'click', () => send());
on('#btnStop', 'click', () => { if (S.abort) S.abort.abort(); });

/* ---------- aksi pesan ---------- */
async function copyText(t, btn) { try { await navigator.clipboard.writeText(t); } catch (e) { toast(T('toast.copy_fail')); return; } if (btn) { const o = btn.innerHTML; btn.textContent = '✓ ' + T('msg.copied'); setTimeout(() => btn.innerHTML = o, 1200); } }
function msgMenu(msg, anchor) {
  const role = msg.classList.contains('user') ? 'user' : 'assistant'; const mid = +msg.dataset.mid || 0;
  const raw = msg.querySelector('.md').dataset.raw || msg.querySelector('.md').textContent;
  const pinned = msg.dataset.pinned === '1';
  const items = [{ label: (pinned ? '📌 ' + T('pin.unpin') : '📌 ' + T('pin.pin')), run: () => togglePin(msg, !pinned) }];
  if (role === 'assistant' && !msg.dataset.gen) {
    if (typeof window.wsArtifactFromMessage === 'function') items.push({ label: '▦ Create Artifact', run: () => window.wsArtifactFromMessage(msg) }, '-');
    items.push('-', { head: T('tf.title') });
    const to = W.lang === 'en' ? 'id' : 'en';
    [['summarize', 'tf.summarize'], ['clarify', 'tf.clarify'], ['table', 'tf.table'], ['bullets', 'tf.bullets'], ['translate', 'tf.translate'], ['academic', 'tf.academic'], ['simple', 'tf.simple']]
      .forEach(([k, key]) => items.push({ label: T(key) + (k === 'translate' ? ' (' + to.toUpperCase() + ')' : ''), run: () => { if (!mid) return toast(T('err.no_mid')); send({ text: '↻ ' + T(key), transform: { mid, kind: k, to } }); } }));
    items.push('-');
    items.push({ label: '🧠 ' + T('msg.remember'), run: async () => { const r = await jpost(API('/api/profile.php?action=remember'), { content: raw.slice(0, 500) }); toast(r.ok ? T('toast.mem_saved') : T('toast.mem_fail')); } });
    if (S.conv && S.conv.project) items.push({ label: '🧠 ' + T('msg.remember_proj', { p: S.conv.project.name }), run: async () => { const r = await jpost(API('/api/projects.php?action=mem_add'), { project_id: S.conv.project.id, content: raw.slice(0, 500) }); toast(r.ok ? T('toast.pmem_saved') : T('toast.mem_fail')); } });
  }
  items.push('-', { label: '🗑 ' + T('msg.delete'), danger: true, run: async () => {
    if (!mid) return toast(T('err.no_mid')); if (!confirm(T(role === 'user' ? 'msg.delete.confirm_turn' : 'msg.delete.confirm'))) return;
    const r = await jpost(API('/api/chat.php?action=delete_message'), { id: mid });
    if (r.ok) { (r.ids || []).forEach(i => $(`#messages [data-mid="${i}"]`)?.remove()); $$('#messages .followups').forEach(x => x.remove()); loadPins(); } else toast(r.error || T('toast.mem_fail')); } });
  popMenu(anchor, items, { alignRight: true });
}
async function togglePin(msg, pin) {
  const mid = +msg.dataset.mid || 0; if (!mid) return toast(T('err.no_mid'));
  let label = '';
  if (pin) { const l = prompt(T('pin.label.prompt'), ''); if (l === null) return; label = l.trim(); }
  const r = await jpost(API('/api/chat.php?action=pin'), { id: mid, pinned: pin, label });
  if (!r.ok) return toast(r.error || T('toast.mem_fail'));
  msg.dataset.pinned = pin ? '1' : ''; const b = msg.querySelector('.pin-badge'); if (b) b.hidden = !pin;
  toast(pin ? T('pin.done') : T('pin.removed')); loadPins();
}
on('#messages', 'click', async e => {
  const lb = e.target.closest('[data-lb]');
  if (lb) { const i = $('#lbImg'); if (i) i.src = lb.dataset.lb; openModal('lbModal'); return; }
  const sug = e.target.closest('.sug'); if (sug) { onSuggestion(+sug.dataset.sug); return; }
  const dc = e.target.closest('[data-doc]'); if (dc) { openDocPreview(+dc.dataset.doc); return; }
  const rc = e.target.closest('[data-copycode]');
  if (rc) { const pre = $('#' + rc.dataset.copycode)?.querySelector('pre'); if (pre) copyText(pre.textContent, rc); return; }
  const rn = e.target.closest('[data-run]'); if (rn) { const bx = $('#' + rn.dataset.run); if (bx) runSandbox(bx, rn.dataset.lang || 'js'); return; }
  const rr = e.target.closest('[data-runremote]');
  if (rr) { const pre = $('#' + rr.dataset.runremote)?.querySelector('pre'); if (pre) {
      const r = await jpost(API('/api/tools.php?action=run'), { lang: rr.dataset.lang, code: pre.textContent });
      showOut($('#' + rr.dataset.runremote), r.ok ? (r.result.output + r.result.stderr) : (r.error || T('code.fail'))); } return; }
  const b = e.target.closest('[data-a]'); if (!b) return;
  const msg = b.closest('.msg'); const mdEl = msg.querySelector('.md');
  const raw = mdEl.dataset.raw || mdEl.textContent; const a = b.dataset.a;
  if (a === 'copy') copyText(raw, b);
  if (a === 'more') msgMenu(msg, b);
  if (a === 'regen') send({ regen: true });
  if (a === 'regenmenu') popMenu(b, [{ label: T('rg.normal'), run: () => send({ regen: true }) }, { label: T('rg.shorter'), run: () => send({ regen: true, style: 'shorter' }) }, { label: T('rg.detailed'), run: () => send({ regen: true, style: 'detailed' }) }, { label: T('rg.formal'), run: () => send({ regen: true, style: 'formal' }) }]);
  if (a === 'edit') {
    const bub = msg.querySelector('.bubble');
    bub.innerHTML = `<textarea class="edit-box" aria-label="${esc(T('msg.edit'))}">${esc(raw)}</textarea><div class="edit-row"><button class="btn-primary" data-e="save">${esc(T('msg.resend'))}</button><button class="btn-ghost" data-e="cancel">${esc(T('common.cancel'))}</button></div>`;
    bub.querySelector('.edit-box').focus();
    bub.querySelector('[data-e="cancel"]').onclick = () => { bub.innerHTML = '<div class="md"></div>'; const m2 = bub.querySelector('.md'); m2.innerHTML = esc(raw).replace(/\n/g, '<br>'); m2.dataset.raw = raw; };
    bub.querySelector('[data-e="save"]').onclick = async () => { const nv = bub.querySelector('.edit-box').value.trim(); if (!nv) return;
      const mid = +msg.dataset.mid; if (!mid) return toast(T('err.no_mid'));
      const r = await jpost(API('/api/chat.php?action=truncate'), { id: mid }); if (!r.ok) return toast(r.error || T('toast.mem_fail'));
      let n = msg; const rm = []; while (n) { rm.push(n); n = n.nextElementSibling; } rm.forEach(x => x.remove()); $$('#messages .followups').forEach(x => x.remove());
      send({ text: nv }); };
  }
});
function showOut(box, txt) { if (!box) return; let o = box.querySelector('.code-out'); if (!o) { o = document.createElement('div'); o.className = 'code-out'; box.appendChild(o); } o.textContent = txt; }
/* Runner kode: iframe sandbox + runner.html (CSP khusus). JS dijalankan di iframe baru tiap Run; Python memakai satu iframe
   hangat (Pyodide di Web Worker) agar Run berikutnya cepat. Tanpa cookie/akses DOM/API induk (origin opaque). */
const RUNNER = { py: null, pyWarm: false, n: 0 };
function runnerFrame() {
  return new Promise((resolve, reject) => {
    const f = document.createElement('iframe');
    f.setAttribute('sandbox', 'allow-scripts'); f.setAttribute('aria-hidden', 'true'); f.tabIndex = -1;
    f.style.cssText = 'position:absolute;width:0;height:0;border:0;visibility:hidden';
    const to = setTimeout(() => { removeEventListener('message', h); f.remove(); reject(new Error('runner timeout')); }, 8000);
    const h = ev => { if (ev.source === f.contentWindow && ev.data && ev.data.__wr === 'ready') { clearTimeout(to); removeEventListener('message', h); resolve(f); } };
    addEventListener('message', h); f.src = API('/runner.html?v=' + encodeURIComponent(W.version || '')); document.body.appendChild(f);
  });
}
async function runCode(lang, code, onWait) {
  const isPy = lang === 'python'; let f;
  try { f = (isPy && RUNNER.py && RUNNER.py.isConnected) ? RUNNER.py : await runnerFrame(); if (isPy) RUNNER.py = f; }
  catch (e) { return T('code.fail'); }
  if (isPy && !RUNNER.pyWarm && onWait) onWait(T('code.py_loading'));
  return new Promise(resolve => {
    const id = ++RUNNER.n, limit = isPy ? (RUNNER.pyWarm ? 20000 : 120000) : 6000; let done = false;
    const finish = (text, kill) => {
      if (done) return; done = true; clearTimeout(tm); removeEventListener('message', h);
      if (!isPy || kill) { f.remove(); if (isPy) { RUNNER.py = null; RUNNER.pyWarm = false; } }
      resolve(text);
    };
    const h = ev => {
      const d = ev.data; if (ev.source !== f.contentWindow || !d || d.__wr !== 'result' || d.id !== id) return;
      if (isPy && !d.fatal) RUNNER.pyWarm = true;
      finish(d.fatal ? ('Error: ' + d.fatal) : d.out, !!d.fatal && isPy);
    };
    const tm = setTimeout(() => finish(T('code.timeout'), true), limit);
    addEventListener('message', h);
    f.contentWindow.postMessage({ __wr: 1, id, lang, code, pyBase: location.origin + API('/assets/vendor/pyodide/') }, '*');
  });
}
async function runSandbox(box, lang) {
  const pre = box.querySelector('pre'); if (!pre) return;
  const btn = box.querySelector('[data-run]'); if (btn) btn.disabled = true;
  showOut(box, T('code.running'));
  try { const out = await runCode(lang === 'python' ? 'python' : 'js', pre.textContent, m => showOut(box, m)); showOut(box, (out && String(out).trim()) ? out : T('code.noout')); }
  finally { if (btn) btn.disabled = false; }
}

/* ---------- bahasa UI: instan tanpa kehilangan state ---------- */
function setLang(l) {
  if (!['id', 'en'].includes(l) || l === W.lang) return;
  W.lang = l; applyI18n(); renderChats(); renderProjects(); updateConvHeader(); renderAtt(); refreshToolsPop();
  if (!S.convId && $('#messages .empty')) $('#messages').innerHTML = emptyState();
  if (window.__initMic) window.__initMic();
  if (!S.convId) setTitle(null); else setTitle(S.conv ? S.conv.title : null);
  $$('[data-ui-lang]').forEach(b => b.classList.toggle('sel', b.dataset.uiLang === l));
  const ws = document.querySelector('.ws'), cb = $('#btnSideCollapse');
  if (ws && cb) { const on_ = ws.classList.contains('sb-collapsed'); cb.title = T(on_ ? 'sb.expand' : 'sb.collapse'); cb.setAttribute('aria-label', cb.title); }
}

/* ---------- composer ---------- */
function autoSize() { const i = $('#input'); if (!i) return; i.style.height = 'auto'; i.style.height = Math.min(i.scrollHeight, 200) + 'px'; }
on('#input', 'input', () => { autoSize(); saveDraftDebounced(); });
on('#input', 'keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } });
on('#chatScroll', 'scroll', () => { const c = $('#chatScroll'), b = $('#btnScroll'); if (!c || !b) return; b.hidden = !(c.scrollTop < c.scrollHeight - c.clientHeight - 240); });
on('#btnScroll', 'click', () => scrollBottom());

/* draft (localStorage; debounce — tanpa tulis DB per karakter) */
const draftKey = () => 'wansq_draft_' + (S.convId || ('new' + (S.project ? '_p' + S.project : '')));
const saveDraftDebounced = debounce(() => { try { const v = $('#input')?.value || ''; v ? localStorage.setItem(draftKey(), v) : localStorage.removeItem(draftKey()); } catch (e) {} }, 500);
function restoreDraft() { try { const i = $('#input'); if (i && !i.value) { i.value = localStorage.getItem(draftKey()) || ''; autoSize(); } } catch (e) {} }
function clearDraft() { try { localStorage.removeItem(draftKey()); } catch (e) {} }

/* ---------- account menu & engine ---------- */
on('#acctBtn', 'click', e => { e.stopPropagation(); const m = $('#acctMenu'); if (!m) return; m.hidden = !m.hidden; e.currentTarget.setAttribute('aria-expanded', String(!m.hidden)); });
on('#acctMenu', 'click', e => {
  const a = e.target.closest('[data-act]'); if (!a) return;
  const m = $('#acctMenu'); if (m) m.hidden = true;
  if (a.dataset.act === 'logout') location.href = API('/logout.php');
  if (a.dataset.act === 'settings') openSettings('profile');
  if (a.dataset.act === 'memory') openSettings('memory');
  if (a.dataset.act === 'language') openSettings('language');
  if (a.dataset.act === 'palette') openPalette();
  if (a.dataset.act === 'feedback') location.href = 'mailto:?subject=' + encodeURIComponent(T('fb.mail.subject')) + '&body=' + encodeURIComponent(T('fb.mail.body'));
});
(function initEngine() {
  const m = $('#engineMenu'); const btn = $('#engineBtn'); if (!m || !btn) return;
  const modeOrder = ['auto','thinking','fast'];
  const engines = Object.fromEntries(modeOrder.filter(k => W.engines[k]).map(k => [k, W.engines[k]]));
  let legacy = ''; try { legacy = localStorage.getItem('wansq_engine') || ''; } catch (e) {}
  if (legacy === 'reason') S.engine = 'thinking';
  else if (legacy === 'vision') S.engine = 'auto';
  else if (legacy && engines[legacy]) S.engine = legacy;
  if (!engines[S.engine]) S.engine = 'auto';
  m.innerHTML = Object.entries(engines).map(([k, v]) => `<button class="engine-opt${k === S.engine ? ' sel' : ''}" role="menuitem" data-engine="${k}"><b>${esc(v.label)}</b><small>${esc(v.desc)}</small></button>`).join('');
  btn.onclick = e => { e.stopPropagation(); m.hidden = !m.hidden; btn.setAttribute('aria-expanded', String(!m.hidden)); };
  m.onclick = e => { const o = e.target.closest('[data-engine]'); if (!o) return; S.engine = o.dataset.engine;
    const l = $('#engineLabel'); if (l) l.textContent = W.engines[S.engine].label;
    $$('.engine-opt', m).forEach(x => x.classList.toggle('sel', x === o)); m.hidden = true; try { localStorage.setItem('wansq_engine', S.engine); } catch (e2) {} };
  try { localStorage.setItem('wansq_engine', S.engine); } catch (e) {}
  $('#engineLabel').textContent = engines[S.engine].label;
  $$('.engine-opt', m).forEach(x => x.classList.toggle('sel', x.dataset.engine === S.engine));
})();

/* ---------- conversation action surface ---------- */
// The top-right conversation button intentionally reuses the exact same action builder
// as the sidebar. This keeps rename/move/share/pin/archive/delete behavior in one place.
on('#btnConvActions','click',e=>{ e.stopPropagation(); if (S.convId) ctxMenu(S.convId, e.currentTarget); });

/* ---------- health & dev ---------- */
function renderDev() {
  const d = $('#devPanel'); if (!d) return;
  d.textContent = JSON.stringify({ health: S.health || null, last: S.lastDone || null, diagnostics: S.diag, caps: CAPS, engine: S.engine, conv: S.convId, version: W.version }, null, 1);
}
async function bootHealth() {
  const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 9000);
  try {
    const r = await fetch(API('/api/health.php'), { headers: HDR, signal: ctl.signal }).then(r => r.json());
    S.health = r;
    if (!r.groq) showBanner(T('health.ai', { e: r.groq_error || '—' }));
    else if (!r.db) showBanner(T('health.db'));
    else if (r.schema === false) showBanner(T('health.schema'));
    else if (r.chat_model === false) showBanner(T('health.model'));
  } catch (e) { /* bukan blocker */ }
  clearTimeout(to);
}
