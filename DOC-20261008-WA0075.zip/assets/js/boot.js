/* WanSQ · boot (dimuat terakhir) */
(function initSidebarCollapse() {
  const ws = document.querySelector('.ws'); const btn = $('#btnSideCollapse'); if (!ws || !btn) return;
  const apply = on_ => {
    ws.classList.toggle('sb-collapsed', on_);
    btn.setAttribute('aria-pressed', String(on_));
    btn.title = T(on_ ? 'sb.expand' : 'sb.collapse');
    btn.setAttribute('aria-label', T(on_ ? 'sb.expand' : 'sb.collapse'));
  };
  let saved = false; try { saved = localStorage.getItem('wansq_sb_collapsed') === '1'; } catch (e) {}
  apply(saved);
  btn.addEventListener('click', () => {
    const on_ = !ws.classList.contains('sb-collapsed'); apply(on_);
    try { localStorage.setItem('wansq_sb_collapsed', on_ ? '1' : '0'); } catch (e) {}
  });
})();
(function boot() {
  applyI18n(); refreshToolsPop(); if (window.__initMic) window.__initMic();
  $$('[data-ui-lang]').forEach(b => b.classList.toggle('sel', b.dataset.uiLang === W.lang));
  const box = $('#convList'); if (box) box.innerHTML = `<p class="list-empty">${esc(T('sb.loading'))}</p>`;
  bootHealth(); loadProjects();
  loadChats()
    .catch(() => { S.chats = []; renderChats(); showBanner(T('err.history')); })
    .then(() => {
      const m = location.hash.match(/^#c=(\d+)$/); if (m) return openConv(+m[1]);
      return openConv(null);
    });
})();
