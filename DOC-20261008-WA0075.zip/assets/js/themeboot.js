(function () {
  const html = document.documentElement;
  const mq = window.matchMedia('(prefers-color-scheme: dark)');
  function resolve() {
    const pref = localStorage.getItem('wansq_theme') || html.getAttribute('data-theme-pref') || 'system';
    const resolved = pref === 'system' ? (mq.matches ? 'dark' : 'light') : pref;
    html.setAttribute('data-theme-resolved', resolved);
    html.setAttribute('data-theme-pref', pref);
  }
  mq.addEventListener('change', resolve);
  window.WAN_THEME = {
    set(pref) { localStorage.setItem('wansq_theme', pref); resolve(); },
    get() { return html.getAttribute('data-theme-pref'); }
  };
  resolve();
})();

/* Fallback gambar tanpa inline handler (CSP script-src 'self' memblokir atribut onerror=). Fase capture karena 'error' tidak bubble. */
document.addEventListener('error', function (e) {
  var t = e.target;
  if (!t || t.tagName !== 'IMG' || !t.dataset) return;
  if (t.dataset.fb && !t.dataset.fbDone) { t.dataset.fbDone = '1'; t.src = t.dataset.fb; return; }
  if (t.dataset.wanfb && typeof window.wanImgFallback === 'function') { window.wanImgFallback(t); return; }
  if (t.dataset.fbhide && !t.dataset.fbDone) {
    t.dataset.fbDone = '1';
    var s = document.createElement('span'); s.className = 'att-broken'; s.textContent = '\uD83D\uDDBC\uFE0F Preview tidak tersedia';
    if (t.parentNode) t.parentNode.replaceChild(s, t);
  }
}, true);
