(() => {
  const q = s => document.querySelector(s);
  const qa = s => [...document.querySelectorAll(s)];
  let current = null;

  async function loadArtifacts() {
    const box=q('#artifactList'); if(!box) return;
    box.innerHTML='<div class="workspace-empty">Loading artifacts…</div>';
    try {
      const r=await jget(API('/api/workspace.php?action=artifacts'+(S.project?'&project='+S.project:'')));
      if(!r.ok) throw new Error(r.error||'Failed');
      const items=r.artifacts||[];
      const count=q('#artifactCount'); if(count) count.textContent=items.length+' artifact'+(items.length===1?'':'s');
      if(!items.length){box.innerHTML='<div class="workspace-empty"><b>No artifacts yet.</b><span>Create one from an assistant response or build it from scratch.</span></div>';return;}
      box.innerHTML=items.map(a=>`<button class="artifact-card" data-art="${+a.id}">
        <span class="artifact-type">${esc(a.type.replaceAll('_',' '))}</span>
        <strong>${esc(a.title)}</strong>
        <span>v${+a.version} · ${esc(a.updated_at||'')}</span>
      </button>`).join('');
    }catch(e){box.innerHTML='<div class="workspace-empty">Unable to load artifacts.</div>';}
  }
  async function loadJobs(){
    const box=q('#jobList'); if(!box)return;
    box.innerHTML='<div class="workspace-empty">Loading activity…</div>';
    try{
      const r=await jget(API('/api/workspace.php?action=jobs&limit=30'));
      if(!r.ok)throw new Error();
      const items=r.jobs||[];
      if(!items.length){box.innerHTML='<div class="workspace-empty"><b>Nothing running.</b><span>Long-running work will appear here.</span></div>';return;}
      box.innerHTML=items.map(j=>`<div class="job-card">
        <div class="job-line"><strong>${esc(j.title)}</strong><span class="job-pill ${esc(j.status)}">${esc(j.status)}</span></div>
        <div class="job-meta">${esc(j.kind)} · ${+j.progress||0}% · ${esc(j.updated_at||'')}</div>
        <div class="job-bar"><i style="width:${Math.max(0,Math.min(100,+j.progress||0))}%"></i></div>
        ${j.error?`<div class="job-error">${esc(j.error)}</div>`:''}
      </div>`).join('');
    }catch(e){box.innerHTML='<div class="workspace-empty">Unable to load activity.</div>';}
  }
  function openWorkspace(tab='artifacts'){
    const m=q('#workspaceModal'); if(!m)return;
    m.hidden=false; q('#btnWorkspace')?.setAttribute('aria-expanded','true');
    qa('.wtab').forEach(b=>b.classList.toggle('active',b.dataset.wtab===tab));
    qa('.w-pane').forEach(p=>p.classList.toggle('active',p.dataset.wpane===tab));
    if(tab==='artifacts')loadArtifacts(); else loadJobs();
  }
  function closeWorkspace(){q('#workspaceModal')?.setAttribute('hidden','');q('#btnWorkspace')?.setAttribute('aria-expanded','false');}
  function fillVersions(vs, cur){
    const sel=q('#artifactVersions'); if(!sel)return;
    sel.innerHTML=(vs||[]).map(v=>`<option value="${+v.version_no}"${+v.version_no===+cur?' selected':''}>v${+v.version_no} · ${esc(v.created_at||'')}</option>`).join('');
    sel._v=vs||[];
  }
  function editArtifact(a,versions){
    current=a; q('#artifactList').hidden=true; q('#artifactEditor').hidden=false;
    q('#artifactTitle').value=a.title; q('#artifactType').value=a.type; q('#artifactContent').value=a.content;
    q('#artifactStatus').textContent=`Version ${a.version}`;
    if(versions)fillVersions(versions,a.version);
  }
  function artifactExt(t){return ({markdown:'md',code:'txt',html:'html',table:'csv',report:'md',study_guide:'md',document:'md',chart:'json'})[t]||'txt';}
  async function reloadCurrent(){
    if(!current)return; const r=await jget(API('/api/workspace.php?action=artifact&id='+current.id)); if(r.ok)editArtifact(r.artifact,r.versions);
  }
  async function saveArtifact(){
    if(!current)return;
    const title=q('#artifactTitle').value.trim(), content=q('#artifactContent').value;
    const st=q('#artifactStatus'); st.textContent='Saving…';
    const type=q('#artifactType').value;
    const r=await jpost(API('/api/workspace.php?action=artifact_save'),{id:current.id,title,content,type});
    if(r.ok){current=r.artifact;st.textContent=`Saved as version ${current.version}`;await reloadCurrent();loadArtifacts();}else st.textContent=r.error||'Save failed.';
  }
  async function createArtifactFromMessage(msg){
    const md=msg?.querySelector('.md'); if(!md)return;
    const raw=md.dataset.raw||md.textContent||''; if(!raw.trim())return;
    const title=(S.conv?.title||'WanSQ Artifact').slice(0,120);
    const r=await jpost(API('/api/workspace.php?action=artifact_create'),{
      title,type:'document',content:raw,conversation_id:S.convId||0,project_id:S.conv?.project?.id||S.project||0
    });
    if(r.ok){toast('Artifact created');openWorkspace('artifacts');}else toast(r.error||'Artifact creation failed.');
  }
  window.wsArtifactFromMessage=createArtifactFromMessage;
  window.wsOpen=openWorkspace;

  document.addEventListener('click',e=>{
    if(e.target.closest('#btnWorkspace')){e.stopPropagation();openWorkspace('artifacts');return;}
    const tab=e.target.closest('.wtab');if(tab){openWorkspace(tab.dataset.wtab);return;}
    if(e.target.closest('#artifactRefresh')){loadArtifacts();return;}
    if(e.target.closest('#jobRefresh')){loadJobs();return;}
    if(e.target.closest('#jobClear')){jpost(API('/api/workspace.php?action=job_clear'),{}).then(r=>{if(r.ok){toast('Riwayat aktivitas dibersihkan');loadJobs();}});return;}
    const card=e.target.closest('[data-art]');if(card){
      jget(API('/api/workspace.php?action=artifact&id='+card.dataset.art)).then(r=>{if(r.ok)editArtifact(r.artifact,r.versions);});return;
    }
    if(e.target.closest('#artifactBack')){q('#artifactEditor').hidden=true;q('#artifactList').hidden=false;loadArtifacts();return;}
    if(e.target.closest('#artifactSave')){saveArtifact();return;}
    if(e.target.closest('#artifactRestore')){
      const v=+q('#artifactVersions').value; if(!current||!v)return; if(v===+current.version){q('#artifactStatus').textContent='Ini sudah versi aktif.';return;}
      jpost(API('/api/workspace.php?action=artifact_restore'),{id:current.id,version:v}).then(r=>{if(r.ok){toast('Versi dipulihkan sebagai versi baru');reloadCurrent();loadArtifacts();}else toast(r.error||'Gagal memulihkan.');});return;
    }
    if(e.target.closest('#artifactDelete')){
      if(!current||!confirm('Hapus artifact ini beserta seluruh riwayat versinya? Tindakan ini tidak dapat dibatalkan.'))return;
      jpost(API('/api/workspace.php?action=artifact_delete'),{id:current.id}).then(r=>{if(r.ok){current=null;q('#artifactEditor').hidden=true;q('#artifactList').hidden=false;loadArtifacts();toast('Artifact dihapus');}else toast(r.error||'Gagal menghapus.');});return;
    }
    if(e.target.closest('#artifactCopy')){
      const txt=q('#artifactContent').value; (navigator.clipboard?navigator.clipboard.writeText(txt):Promise.reject()).then(()=>toast('Disalin'),()=>{q('#artifactContent').select();toast('Tekan Ctrl+C untuk menyalin');});return;
    }
    if(e.target.closest('#artifactDownload')){
      const t=q('#artifactType').value, name=(q('#artifactTitle').value.trim()||'artifact').replace(/[\\/:*?"<>|]+/g,'_').slice(0,80)+'.'+artifactExt(t);
      const blob=new Blob([q('#artifactContent').value],{type:t==='html'?'text/html;charset=utf-8':'text/plain;charset=utf-8'});
      const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},500);return;
    }
    if(e.target.closest('[data-close="workspaceModal"]'))closeWorkspace();
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!q('#workspaceModal')?.hidden)closeWorkspace();});
})();
