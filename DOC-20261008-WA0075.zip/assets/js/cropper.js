/* WanSQ · Cropper inline (dipasang DI DALAM pane Profile Settings) */
window.WanCrop = (function () {
  const CV = 320;
  let img = null, zoom = 1, ox = 0, oy = 0, rot = 0, dragging = false, lx = 0, ly = 0, bound = false;
  const $ = id => document.getElementById(id);
  const baseScale = () => { const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height; return Math.max(CV / iw, CV / ih); };
  const clampPan = () => { const lim = (CV * (zoom - 1)) / 2 + CV * 0.35; ox = Math.max(-lim, Math.min(lim, ox)); oy = Math.max(-lim, Math.min(lim, oy)); };
  function draw() {
    const c = $('cropCanvas'); if (!c || !img) return;
    c.width = CV; c.height = CV;
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, CV, CV);
    ctx.save();
    ctx.translate(CV / 2 + ox, CV / 2 + oy);
    ctx.rotate(rot * Math.PI / 180);
    const s = baseScale() * zoom;
    const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    ctx.drawImage(img, -iw * s / 2, -ih * s / 2, iw * s, ih * s);
    ctx.restore();
  }
  function bind() {
    if (bound) return; bound = true;
    const cv = $('cropCanvas'); if (!cv) return;
    cv.addEventListener('pointerdown', e => { dragging = true; lx = e.clientX; ly = e.clientY; cv.setPointerCapture(e.pointerId); });
    cv.addEventListener('pointermove', e => { if (!dragging) return; ox += e.clientX - lx; oy += e.clientY - ly; lx = e.clientX; ly = e.clientY; clampPan(); draw(); });
    cv.addEventListener('pointerup', () => dragging = false);
    cv.addEventListener('pointercancel', () => dragging = false);
    $('cropZoom').addEventListener('input', e => { zoom = parseFloat(e.target.value) || 1; clampPan(); draw(); });
    $('cropZoomIn').addEventListener('click', () => { zoom = Math.min(4, zoom + 0.2); $('cropZoom').value = zoom; clampPan(); draw(); });
    $('cropZoomOut').addEventListener('click', () => { zoom = Math.max(1, zoom - 0.2); $('cropZoom').value = zoom; clampPan(); draw(); });
    $('cropRotate').addEventListener('click', () => { rot = (rot + 90) % 360; draw(); });
  }
  function load(source) {
    bind();
    zoom = 1; ox = 0; oy = 0; rot = 0;
    const z = $('cropZoom'); if (z) z.value = '1';
    const apply = image => { img = image; draw(); };
    if (source instanceof Image) { apply(source); return; }
    const u = URL.createObjectURL(source); const i = new Image();
    i.onload = () => { URL.revokeObjectURL(u); apply(i); };
    i.onerror = () => URL.revokeObjectURL(u);
    i.src = u;
  }
  function exportBlob(cb) {
    if (!img) { cb(null); return; }
    const out = document.createElement('canvas'); out.width = 512; out.height = 512;
    const ctx = out.getContext('2d');
    ctx.clearRect(0, 0, 512, 512);
    ctx.save();
    ctx.translate(256 + ox * (512 / CV), 256 + oy * (512 / CV));
    ctx.rotate(rot * Math.PI / 180);
    const s = baseScale() * zoom * (512 / CV);
    const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    ctx.drawImage(img, -iw * s / 2, -ih * s / 2, iw * s, ih * s);
    ctx.restore();
    out.toBlob(b => cb(b), 'image/jpeg', 0.92);
  }
  function reset() { img = null; }
  return { load, exportBlob, reset };
})();