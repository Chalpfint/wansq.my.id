document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('wansq_theme');
  if (saved) window.WAN_THEME.set(saved);
  const g = document.getElementById('btnGoogle');
  if (g) g.addEventListener('click', () => { g.classList.add('loading'); g.setAttribute('aria-busy', 'true'); });
});