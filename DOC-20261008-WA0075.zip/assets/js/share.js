/* WanSQ · halaman share publik (read-only). Eksternal agar sesuai CSP: script-src 'self'. */
(function () {
  var nodes = document.querySelectorAll('#messages .msg.assistant .md');
  nodes.forEach(function (el) { el.innerHTML = md(el.dataset.raw || '', { readonly: true }); });
  function typeset() {
    if (!window.MathJax || !window.MathJax.typesetPromise) return false;
    var mathNodes = [].slice.call(document.querySelectorAll('#messages .math-display, #messages .math-inline'));
    if (!mathNodes.length) return true;
    var ready = (window.MathJax.startup && window.MathJax.startup.promise) ? window.MathJax.startup.promise : Promise.resolve();
    ready.then(function () { return window.MathJax.typesetPromise(mathNodes); }).catch(function () {});
    return true;
  }
  if (!typeset()) {
    var tries = 0, iv = setInterval(function () { if (typeset() || ++tries > 40) clearInterval(iv); }, 250);
  }
  // Salin kode (codebox) pada halaman publik
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copycode]'); if (!b) return;
    var box = document.getElementById(b.getAttribute('data-copycode')); var pre = box && box.querySelector('pre');
    if (pre && navigator.clipboard) navigator.clipboard.writeText(pre.textContent || '').catch(function () {});
  });
})();
