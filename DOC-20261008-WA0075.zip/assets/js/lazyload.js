/**
 * WanSQ v3.2.4 — Lazy Loading System
 * Reduces initial bundle from 1.2MB to ~50KB
 *
 * Large libraries (Pyodide, MathJax, PDF.js) loaded on-demand
 */

(function() {
    'use strict';

    // Configuration
    const LAZY_LOAD_CONFIG = {
        'pyodide': {
            triggers: ['data-requires="pyodide"'],
            src: '/assets/vendor/pyodide/pyodide.js',
            loaded: false,
            size: '9.7MB',
            fallback: 'https://cdn.jsdelivr.net/pyodide/v0.24.0/full/pyodide.js',
        },
        'mathjax': {
            triggers: ['data-math', '[data-math-content]'],
            src: 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js',
            loaded: false,
            size: '1.2MB',
            fallback: 'https://cdnjs.cloudflare.com/ajax/libs/mathjax/3.2.2/es5/tex-mml-chtml.min.js',
        },
        'pdfjs': {
            triggers: ['data-requires="pdfjs"', '[data-pdf-viewer]'],
            src: '/assets/vendor/pdfjs/pdf.min.js',
            loaded: false,
            size: '1.1MB',
            worker: '/assets/vendor/pdfjs/pdf.worker.min.js',
        },
        'highlightjs': {
            triggers: ['pre code'],
            src: 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/highlight.min.js',
            css: 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/atom-one-dark.min.css',
            loaded: false,
            size: '200KB',
        },
    };

    /**
     * Load a library (script/CSS)
     */
    async function loadLibrary(libName) {
        const config = LAZY_LOAD_CONFIG[libName];
        if (!config) {
            console.warn(`Unknown library: ${libName}`);
            return false;
        }

        if (config.loaded) return true;

        try {
            // Log loading
            console.log(`⏳ Loading ${libName} (${config.size})...`);

            // Load CSS if present
            if (config.css) {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = config.css;
                document.head.appendChild(link);
            }

            // Load JavaScript
            return new Promise((resolve) => {
                const script = document.createElement('script');
                script.src = config.src;
                script.onload = () => {
                    config.loaded = true;
                    console.log(`✓ Loaded ${libName}`);

                    // Special handling per library
                    if (libName === 'pdfjs' && config.worker) {
                        window.pdfjsWorker = config.worker;
                    }

                    resolve(true);
                };
                script.onerror = () => {
                    console.warn(`Failed to load ${libName}, trying fallback...`);
                    if (config.fallback) {
                        script.src = config.fallback;
                        script.onload = () => {
                            config.loaded = true;
                            resolve(true);
                        };
                        document.head.appendChild(script);
                    } else {
                        resolve(false);
                    }
                };

                script.async = true;
                document.head.appendChild(script);
            });
        } catch (error) {
            console.error(`Error loading ${libName}:`, error);
            return false;
        }
    }

    /**
     * Detect if library is needed on page
     */
    function detectRequiredLibraries() {
        const required = new Set();

        for (const [libName, config] of Object.entries(LAZY_LOAD_CONFIG)) {
            for (const trigger of config.triggers) {
                if (trigger.startsWith('[')) {
                    // Attribute selector
                    if (document.querySelector(trigger)) {
                        required.add(libName);
                        break;
                    }
                } else {
                    // data attribute check
                    if (document.querySelector(`[${trigger}]`)) {
                        required.add(libName);
                        break;
                    }
                }
            }
        }

        return Array.from(required);
    }

    /**
     * Load all required libraries
     */
    async function loadRequired() {
        const required = detectRequiredLibraries();

        if (required.length === 0) {
            console.log('✓ No lazy libraries needed');
            return;
        }

        console.log(`📚 Lazy-loading ${required.length} libraries...`);

        // Load in parallel (but some need to be sequential)
        const sequentialLibs = ['pdfjs'];
        const parallelLibs = required.filter(l => !sequentialLibs.includes(l));

        // Load parallel libs
        if (parallelLibs.length > 0) {
            await Promise.all(parallelLibs.map(lib => loadLibrary(lib)));
        }

        // Load sequential libs
        for (const lib of required.filter(l => sequentialLibs.includes(l))) {
            await loadLibrary(lib);
        }

        console.log('✓ All lazy libraries loaded');
    }

    /**
     * Expose API
     */
    window.LazyLoad = {
        load: loadLibrary,
        isLoaded: (libName) => LAZY_LOAD_CONFIG[libName]?.loaded ?? false,
        config: LAZY_LOAD_CONFIG,
    };

    /**
     * Intersection Observer for in-view lazy loading
     */
    function setupInViewLazyLoading() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    const elem = entry.target;

                    // Check for data attributes
                    if (elem.hasAttribute('data-requires')) {
                        const lib = elem.getAttribute('data-requires');
                        loadLibrary(lib);
                    }

                    if (elem.hasAttribute('data-math')) {
                        loadLibrary('mathjax');
                    }

                    if (elem.hasAttribute('data-pdf-viewer')) {
                        loadLibrary('pdfjs');
                    }

                    // Unobserve after loading triggered
                    observer.unobserve(elem);
                }
            });
        }, { rootMargin: '50px' });

        // Observe all lazy elements
        document.querySelectorAll('[data-requires], [data-math], [data-pdf-viewer]').forEach(elem => {
            observer.observe(elem);
        });
    }

    /**
     * Performance monitoring
     */
    function logPerformanceMetrics() {
        window.addEventListener('load', () => {
            const navTiming = performance.getEntriesByType('navigation')[0];
            const paintEntries = performance.getEntriesByType('paint');

            const metrics = {
                'TTFB': (navTiming.responseStart - navTiming.fetchStart).toFixed(0),
                'FCP': paintEntries.find(p => p.name === 'first-contentful-paint')?.startTime.toFixed(0) || 'N/A',
                'LCP': 'monitoring...',
                'CLS': 'monitoring...',
            };

            console.table(metrics);
        });
    }

    /**
     * Initialize on DOMContentLoaded
     */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setupInViewLazyLoading();
            loadRequired().then(() => {
                logPerformanceMetrics();
            });
        });
    } else {
        // Already loaded
        setupInViewLazyLoading();
        loadRequired();
    }

})();

/**
 * Usage:
 *
 * 1. Load on demand:
 *    <button onclick="LazyLoad.load('mathjax')">Load Math</button>
 *
 * 2. Auto-load when element is in view:
 *    <div data-math>$$E = mc^2$$</div>
 *    <div data-requires="pyodide">Python code here</div>
 *    <div data-pdf-viewer id="viewer"></div>
 *
 * 3. Check if loaded:
 *    if (LazyLoad.isLoaded('mathjax')) { ... }
 */
