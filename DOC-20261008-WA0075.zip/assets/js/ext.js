/* ================= WanSQ Workspace v3.0 — modul (lampiran/OCR, project, cari, share, pin, pengaturan) ================= */

/* ---------- LAMPIRAN: status upload & pemrosesan terpisah ---------- */
function attIcon(a) {
  if (a.state === 'uploading' || a.state === 'processing' || a.state === 'ocr') return '<span class="chip-spin" aria-hidden="true"></span>';
  if (a.kind === 'image' && a.url) return `<img src="${esc(a.url)}" data-src="${esc(a.url)}" alt="" data-wanfb="1">`;
  const ex = (a.name || '').split('.').pop().toLowerCase();
  if (ex === 'pdf') return '<span class="chip-ext pdf">PDF</span>';
  if (ex === 'docx') return '<span class="chip-ext doc">DOC</span>';
  return '<span class="chip-ext">' + esc(ex.slice(0, 4).toUpperCase() || 'TXT') + '</span>';
}
function attStatusText(a) {
  switch (a.state) {
    case 'uploading': return T('att.uploading', { p: a.pct || 0 });
    case 'processing': return T(a.kind === 'image' ? 'att.processing_img' : 'att.reading_doc');
    case 'ocr': return T('att.ocr', { d: a.ocrDone || 0, t: a.ocrTotal || '?' });
    case 'ready': return '✓ ' + T(a.kind === 'image' ? 'att.ready_img' : 'att.ready_doc');
    case 'needs_ocr': return '⚠ ' + T('att.needs_ocr');
    case 'failed': return '✕ ' + (a.err || T('att.failed'));
    default: return '';
  }
}
function renderAtt() {
  const r = $('#attachRow'); if (!r) return;
  r.hidden = !S.att.length;
  r.innerHTML = S.att.map((a, i) => `<span class="attach-chip st-${a.state}" role="group" aria-label="${esc(a.name)}">
    <button class="chip-main" data-prev="${i}" title="${esc(T('att.preview'))}">${attIcon(a)}<span class="chip-txt"><span class="chip-name">${esc(a.name)}${a.size ? ` <span class="chip-size">${fmtB(a.size)}</span>` : ''}</span><span class="chip-st" role="status">${esc(attStatusText(a))}</span></span></button>
    ${a.state === 'ocr' ? `<button class="chip-cancel" data-cancel="${i}">${esc(T('att.skip_ocr'))}</button>` : ''}<button class="x" data-i="${i}" aria-label="${esc(T('att.remove'))}">✕</button></span>`).join('');
  $$('.x', r).forEach(b => b.onclick = () => removeAtt(+b.dataset.i));
  $$('[data-prev]', r).forEach(b => b.onclick = () => { const a = S.att[+b.dataset.prev]; if (!a || !a.id) return; if (a.kind === 'image') { $('#lbImg').src = a.url; openModal('lbModal'); } else openDocPreview(a.id); });
  $$('[data-cancel]', r).forEach(b => b.onclick = () => { const a = S.att[+b.dataset.cancel]; if (a) a.cancel = true; });
}
async function removeAtt(i) {
  const a = S.att[i]; if (!a) return; a.cancel = true; if (a.xhr) try { a.xhr.abort(); } catch (e) {}
  S.att.splice(i, 1); renderAtt();
  if (a.id) jpost(API('/api/files.php?action=remove'), { id: a.id });   // lampiran belum terkirim → hapus di server; tidak dipakai lagi
}
function xhrUpload(file, att, extra = {}) {
  return new Promise(res => {
    const x = new XMLHttpRequest(); att.xhr = x; x.open('POST', API('/api/upload.php')); x.setRequestHeader('X-CSRF-Token', W.csrf);
    x.upload.onprogress = e => { if (e.lengthComputable && att.state === 'uploading') { att.pct = Math.round(e.loaded / e.total * 100); renderAtt(); } };
    x.upload.onload = () => { if (att.state === 'uploading') { att.state = 'processing'; renderAtt(); } };   // byte terkirim → server mulai membaca/mengindeks
    x.onload = () => { let j; try { j = JSON.parse(x.responseText); } catch (e) { j = { ok: false, error: T('err.bad_response', { s: x.status }) }; } res(j); };
    x.onerror = () => res({ ok: false, error: T('att.net') }); x.onabort = () => res({ ok: false, error: 'abort', aborted: true });
    const fd = new FormData(); fd.append('file', file); fd.append('kind', 'attach'); fd.append('csrf', W.csrf); Object.entries(extra).forEach(([k, v]) => fd.append(k, v));
    x.send(fd);
  });
}
async function uploadFiles(fileList, opts = {}) {
  const files = [...fileList]; let firstReady = null;
  for (const f of files) {
    const isImg = (f.type || '').startsWith('image/');
    if (!opts.projectId) {
      if (S.att.length >= MAX_ATT) { toast(T('att.max', { n: MAX_ATT })); break; }
      if (isImg && S.att.filter(a => a.kind === 'image').length >= MAX_IMG) { toast(T('att.max_img', { n: MAX_IMG })); continue; }
      if (isImg && !CAPS.vision && !CAPS.image_edit) { toast(T('att.no_vision')); continue; }
    }
    const att = { state: 'uploading', pct: 0, kind: isImg ? 'image' : 'doc', name: f.name, size: f.size, url: '', mime: f.type };
    if (!opts.projectId) { S.att.push(att); renderAtt(); }
    const r = await xhrUpload(f, att, opts.projectId ? { project_id: opts.projectId } : {});
    if (opts.projectId) { if (!r.ok) toast(f.name + ': ' + (r.error || T('att.failed'))); else if (r.attachment.status === 'needs_ocr' && r.attachment.mime === 'application/pdf') { await ocrProjectFile(f, r.attachment); } continue; }
    const idx = S.att.indexOf(att); if (idx < 0) { if (r.ok && r.attachment) jpost(API('/api/files.php?action=remove'), { id: r.attachment.id }); continue; }
    if (!r.ok) { if (r.aborted) { continue; } S.att.splice(idx, 1); renderAtt(); toast(f.name + ': ' + (r.error || T('att.failed'))); continue; }
    Object.assign(att, r.attachment, { url: r.attachment.url || '', state: 'ready', xhr: null, name: r.attachment.name });
    if (r.attachment.status === 'needs_ocr') { att.state = 'needs_ocr'; renderAtt(); if (CAPS.ocr) await runOcr(att, f); else { att.state = 'failed'; att.err = T('att.no_ocr'); } }
    renderAtt(); if (!firstReady) firstReady = att;
  }
  const inp = $('#input'); if (firstReady && inp && !inp.value.trim() && S.att.length) { /* biarkan kosong: pengguna bertanya bebas */ }
  if (opts.projectId && window.__projRefresh) window.__projRefresh();
}
on('#btnAttach', 'click', () => $('#filePick')?.click());
on('#filePick', 'change', e => { uploadFiles(e.target.files); e.target.value = ''; });

/* ---------- OCR (halaman dirender di browser via pdf.js → dibaca model vision) ---------- */
let __pdfjs = null;
function loadPdfJs() {
  if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
  if (__pdfjs) return __pdfjs;
  __pdfjs = new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = API('/assets/vendor/pdfjs/pdf.min.js');
    s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = API('/assets/vendor/pdfjs/pdf.worker.min.js'); res(window.pdfjsLib); };
    s.onerror = () => rej(new Error('pdf.js gagal dimuat')); document.head.appendChild(s);
  });
  return __pdfjs;
}
async function ocrPdf(file, attId, pages, onProgress, isCancelled) {
  const lib = await loadPdfJs();
  const pdf = await lib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false }).promise;
  let okN = 0, fail = 0;
  for (let i = 0; i < pages.length; i++) {
    if (isCancelled()) break;
    const p = pages[i]; if (p > pdf.numPages) continue;
    try {
      const page = await pdf.getPage(p); const v1 = page.getViewport({ scale: 1 });
      const sc = Math.min(2.2, 1700 / Math.max(v1.width, v1.height)); const vp = page.getViewport({ scale: sc });
      const cv = document.createElement('canvas'); cv.width = Math.floor(vp.width); cv.height = Math.floor(vp.height);
      const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height);
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      const blob = await new Promise(r => cv.toBlob(r, 'image/jpeg', 0.85)); cv.width = cv.height = 0;
      let done = false;
      for (let t = 0; t < 3 && !done; t++) {
        const fd = new FormData(); fd.append('att_id', attId); fd.append('page', p); fd.append('img', blob, 'p' + p + '.jpg'); fd.append('csrf', W.csrf);
        const j = await fetch(API('/api/ocr.php?action=page'), { method: 'POST', headers: { 'X-CSRF-Token': W.csrf }, body: fd }).then(parseJson);
        if (j.ok) { done = true; okN++; } else if (/Terlalu banyak|429/.test(j.error || '')) await new Promise(r => setTimeout(r, 4000)); else break;
      }
      if (!done) fail++;
    } catch (e) { fail++; }
    onProgress(i + 1, pages.length);
  }
  const fj = await fetch(API('/api/ocr.php?action=finish&att_id=' + attId), { method: 'POST', headers: { ...HDR, 'Content-Type': 'application/json' }, body: '{}' }).then(parseJson).catch(() => null);
  return { okN, fail, status: fj && fj.status };
}
async function runOcr(att, file) {
  const pages = att.ocr_pages || []; att.state = 'ocr'; att.ocrDone = 0; att.ocrTotal = pages.length; renderAtt();
  if (att.ocr_total > pages.length) toast(T('att.ocr_cap', { n: pages.length, t: att.ocr_total }));
  try {
    const r = await ocrPdf(file, att.id, pages, (d, t) => { att.ocrDone = d; att.ocrTotal = t; renderAtt(); }, () => att.cancel);
    if (att.cancel) { att.state = 'needs_ocr'; att.err = ''; }
    else if (r.status === 'ready' && r.okN > 0) att.state = 'ready';
    else { att.state = 'failed'; att.err = T('att.ocr_failed'); }
  } catch (e) { att.state = 'failed'; att.err = T('att.ocr_failed') + ' (' + e.message + ')'; }
  renderAtt();
}
async function ocrProjectFile(file, a) {
  if (!CAPS.ocr) return; const pages = a.ocr_pages || [];
  const st = $('#projFileStatus'); if (st) st.textContent = T('att.ocr', { d: 0, t: pages.length });
  try { await ocrPdf(file, a.id, pages, (d, t) => { if (st) st.textContent = T('att.ocr', { d, t }); }, () => false); } catch (e) {}
  if (st) st.textContent = '';
}

/* ---------- pratinjau dokumen ---------- */
async function openDocPreview(id) {
  openModal('docModal'); $('#docTitle').textContent = '…'; $('#docMeta').textContent = T('common.loading'); $('#docPreview').textContent = '';
  const r = await jget(API('/api/files.php?action=preview&id=' + id));
  if (!r.ok) { $('#docMeta').textContent = r.error || T('att.failed'); return; }
  $('#docTitle').textContent = r.name;
  const unit = /\.pdf$/i.test(r.name) ? T('doc.pages') : T('doc.sections');
  $('#docMeta').innerHTML = [fmtB(r.size), r.pages ? `${r.pages} ${esc(unit)}` : '', `${esc(T('doc.status'))}: ${esc(T('doc.st.' + r.status))}`, r.ocr_pages ? `OCR: ${r.ocr_pages}` : '', r.chunks != null ? `${r.chunks} ${esc(T('doc.chunks'))}` : ''].filter(Boolean).map(x => `<span>${x}</span>`).join('');
  $('#docPreview').textContent = r.preview || r.summary || T('doc.nopreview');
}

/* ---------- drag & drop (composer, percakapan, project) ---------- */
(function initDrop() {
  const zone = $('#mainZone'), ov = $('#dropOverlay'); if (!zone) return; let cnt = 0;
  const hasFiles = e => e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
  zone.addEventListener('dragenter', e => { if (!hasFiles(e)) return; e.preventDefault(); cnt++; ov.hidden = false; zone.classList.add('dragover'); });
  zone.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
  zone.addEventListener('dragleave', e => { if (!hasFiles(e)) return; cnt = Math.max(0, cnt - 1); if (!cnt) { ov.hidden = true; zone.classList.remove('dragover'); } });
  zone.addEventListener('drop', e => { if (!hasFiles(e)) return; e.preventDefault(); cnt = 0; ov.hidden = true; zone.classList.remove('dragover'); if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files); });
  window.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); }); window.addEventListener('drop', e => { if (hasFiles(e)) e.preventDefault(); });
  document.addEventListener('paste', e => { const fl = e.clipboardData && e.clipboardData.files; if (fl && fl.length) { uploadFiles(fl); e.preventDefault(); } });
  // seret file ke project di sidebar → simpan sebagai file project
  const pl = $('#projList');
  if (pl) { pl.addEventListener('dragover', e => { const it = e.target.closest('.proj-item'); if (it && hasFiles(e)) { e.preventDefault(); it.classList.add('drop'); } });
    pl.addEventListener('dragleave', e => e.target.closest('.proj-item')?.classList.remove('drop'));
    pl.addEventListener('drop', async e => { const it = e.target.closest('.proj-item'); if (!it || !hasFiles(e)) return; e.preventDefault(); e.stopPropagation(); it.classList.remove('drop'); cnt = 0; ov.hidden = true;
      const pid = +it.dataset.pid; toast(T('proj.files.uploading')); await uploadFiles(e.dataTransfer.files, { projectId: pid }); toast(T('proj.files.done')); loadProjects(); }); }
})();

/* ---------- capability-aware composer ----------
   Web search and image generation are intent-driven. Legacy toggle state is retained
   only for backward compatibility with older sessions; it is no longer rendered. */
function setImageMode(on_) {
  S.imageMode = false;
  const i = $('#input'); if (i) i.placeholder = T('cmp.placeholder');
}
function refreshToolsPop() {
  const i = $('#input'); if (i) i.placeholder = T('cmp.placeholder');
}
/* ---------- dikte suara (hanya bila browser mendukung) ---------- */
window.__initMic = function () {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition; const btn = $('#btnMic'); if (!SR || !btn) return;
  btn.hidden = false;
  const rec = new SR(); rec.lang = W.lang === 'en' ? 'en-US' : 'id-ID'; rec.interimResults = true; rec.continuous = false; let base = '';
  rec.onresult = ev => { let t = ''; for (const r of ev.results) t += r[0].transcript; const i = $('#input'); if (i) { i.value = base + (base ? ' ' : '') + t; autoSize(); } };
  rec.onend = () => { S.listening = false; btn.classList.remove('listening'); btn.setAttribute('aria-pressed', 'false'); };
  rec.onerror = () => { S.listening = false; btn.classList.remove('listening'); toast(T('mic.fail')); };
  btn.onclick = () => { if (S.listening) { rec.stop(); return; } base = ($('#input')?.value || '').trim(); rec.start(); S.listening = true; btn.classList.add('listening'); btn.setAttribute('aria-pressed', 'true'); };
};

/* ---------- PROJECT ---------- */
async function loadProjects() {
  try { const r = await jget(API('/api/projects.php?action=list')); if (r.ok) { S.projects = r.projects || []; renderProjects(); } } catch (e) {}
}
function renderProjects() {
  const box = $('#projList'); if (!box) return;
  if (!S.projects.length) { box.innerHTML = `<p class="list-empty sm">${esc(T('proj.empty'))}</p>`; }
  else box.innerHTML = S.projects.map(p => `<div class="proj-item${+S.project === +p.id ? ' active' : ''}" data-pid="${p.id}" tabindex="0" role="button" aria-pressed="${+S.project === +p.id}" title="${esc(p.name)}"><span class="pi-ic">${esc(p.icon)}</span><span class="pi-n">${esc(p.name)}</span><span class="pi-c">${+p.convs}</span><button class="dots" data-pedit="${p.id}" aria-label="${esc(T('proj.edit'))}">⚙</button></div>`).join('');
  const f = $('#projFilter');
  if (f) { const p = projById(S.project); f.hidden = !p; if (p) f.innerHTML = `<span>${esc(p.icon)} ${esc(p.name)}</span><span class="pf-act"><button id="pfNew" class="btn-ghost sm">+ ${esc(T('proj.newchat'))}</button><button id="pfClear" class="icon-btn sm" aria-label="${esc(T('proj.clear'))}">✕</button></span>`; }
}
function selectProject(id) { S.project = (+S.project === +id) ? null : id; renderProjects(); if (S.q) runSearch(false); else loadChats(); if (S.project) { S.convId && S.conv && !S.conv.project && 0; } }
on('#projList', 'click', e => { const ed = e.target.closest('[data-pedit]'); if (ed) { e.stopPropagation(); openProjectModal(+ed.dataset.pedit); return; } const it = e.target.closest('.proj-item'); if (it) selectProject(+it.dataset.pid); });
on('#projList', 'keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('proj-item')) { e.preventDefault(); e.target.click(); } });
on('#projFilter', 'click', e => { if (e.target.closest('#pfClear')) { S.project = null; renderProjects(); loadChats(); } if (e.target.closest('#pfNew')) { openConv(null); $('#input')?.focus(); $('#sidebar')?.classList.remove('open'); } });
on('#btnNewProject', 'click', () => openProjectModal(0));
on('#projToggle', 'click', e => { const l = $('#projList'); const ex = e.currentTarget.getAttribute('aria-expanded') === 'true'; e.currentTarget.setAttribute('aria-expanded', String(!ex)); if (l) l.hidden = ex; });
let PM = { id: 0 };
function projTab(t) { $$('.ptab').forEach(b => b.classList.toggle('active', b.dataset.ptab === t)); $$('.ppane').forEach(p => p.classList.toggle('active', p.dataset.ppane === t)); }
onAll('.ptab', 'click', e => { if (!PM.id && e.currentTarget.dataset.ptab !== 'general') { toast(T('proj.save_first')); return; } projTab(e.currentTarget.dataset.ptab); });
async function openProjectModal(id) {
  PM = { id }; projTab('general'); $('#projStatus').textContent = '';
  $('#projModalTitle').textContent = T(id ? 'proj.edit' : 'proj.new'); $('#projDelete').hidden = !id;
  $('#projName').value = ''; $('#projIcon').value = '📁'; $('#projInstr').value = ''; $('#projMemList').innerHTML = ''; $('#projFileList').innerHTML = '';
  openModal('projModal');
  if (id) { const r = await jget(API('/api/projects.php?action=get&id=' + id)); if (!r.ok) { toast(r.error); closeModal('projModal'); return; }
    $('#projName').value = r.project.name; $('#projIcon').value = r.project.icon; $('#projInstr').value = r.project.instructions || ''; renderProjMem(r.memories); renderProjFiles(r.files); }
}
function renderProjMem(list) { $('#projMemList').innerHTML = list.length ? list.map(m => `<li>${esc(m.content)}<button data-pmdel="${m.id}" aria-label="${esc(T('common.delete'))}">✕</button></li>`).join('') : `<li class="mem-empty">${esc(T('proj.mem.empty'))}</li>`; }
function renderProjFiles(list) { $('#projFileList').innerHTML = list.length ? list.map(f => `<li>${f.kind === 'image' ? '🖼️' : '📄'} ${esc(f.original_name)} <small>${fmtB(+f.size)}${f.pages ? ' · ' + f.pages : ''}${f.status === 'needs_ocr' ? ' · ⚠ ' + esc(T('att.needs_ocr')) : ''}</small><button data-pfdel="${f.id}" aria-label="${esc(T('common.delete'))}">✕</button></li>`).join('') : `<li class="mem-empty">${esc(T('proj.files.empty'))}</li>`; }
window.__projRefresh = async () => { if (!PM.id) return; const r = await jget(API('/api/projects.php?action=get&id=' + PM.id)); if (r.ok) renderProjFiles(r.files); };
on('#projSave', 'click', async () => {
  const name = $('#projName').value.trim(); if (!name) { $('#projStatus').textContent = T('proj.name.req'); return; }
  const body = { id: PM.id, name, icon: $('#projIcon').value.trim() || '📁', instructions: $('#projInstr').value };
  const r = await jpost(API('/api/projects.php?action=' + (PM.id ? 'update' : 'create')), body);
  if (!r.ok) { $('#projStatus').textContent = r.error || T('toast.mem_fail'); return; }
  if (!PM.id) { PM.id = r.id; $('#projDelete').hidden = false; $('#projModalTitle').textContent = T('proj.edit'); }
  $('#projStatus').textContent = T('common.saved'); await loadProjects(); if (S.convId) { const c = await jget(API('/api/chat.php?action=messages&id=' + S.convId)); if (c.ok) { S.conv = c.conv; updateConvHeader(); } }
});
on('#projDelete', 'click', async () => { if (!PM.id || !confirm(T('proj.delete.confirm'))) return; const r = await jpost(API('/api/projects.php?action=delete'), { id: PM.id });
  if (r.ok) { if (+S.project === +PM.id) S.project = null; closeModal('projModal'); await loadProjects(); loadChats(); if (S.conv && S.conv.project && +S.conv.project.id === +PM.id) openConv(S.convId); toast(T('proj.deleted')); } });
on('#projMemAdd', 'click', async () => { const i = $('#projMemInput'); const v = i.value.trim(); if (!v || !PM.id) return; const r = await jpost(API('/api/projects.php?action=mem_add'), { project_id: PM.id, content: v });
  if (r.ok) { i.value = ''; const g = await jget(API('/api/projects.php?action=get&id=' + PM.id)); renderProjMem(g.memories); loadProjects(); } });
on('#projMemInput', 'keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#projMemAdd').click(); } });
on('#projMemList', 'click', async e => { const b = e.target.closest('[data-pmdel]'); if (!b) return; await jpost(API('/api/projects.php?action=mem_delete'), { id: +b.dataset.pmdel }); const g = await jget(API('/api/projects.php?action=get&id=' + PM.id)); renderProjMem(g.memories); loadProjects(); });
on('#projFileBtn', 'click', () => { if (!PM.id) return toast(T('proj.save_first')); $('#projFilePick').click(); });
on('#projFilePick', 'change', async e => { const fl = [...e.target.files]; e.target.value = ''; if (!fl.length || !PM.id) return; $('#projFileStatus').textContent = T('proj.files.uploading'); await uploadFiles(fl, { projectId: PM.id }); $('#projFileStatus').textContent = ''; loadProjects(); });
on('#projFileList', 'click', async e => { const b = e.target.closest('[data-pfdel]'); if (!b) return; await jpost(API('/api/files.php?action=remove'), { id: +b.dataset.pfdel }); window.__projRefresh(); loadProjects(); });

/* header percakapan: crumb project, pin, share */
function updateConvHeader() {
  const c = S.conv, cr = $('#projCrumb'), bp = $('#btnPins'), bs = $('#btnShare');
  if (cr) { cr.hidden = !(c && c.project); if (c && c.project) { cr.innerHTML = `${esc(c.project.icon)} ${esc(c.project.name)} <span aria-hidden="true">/</span>`; cr.onclick = () => openProjectModal(+c.project.id); cr.title = T('proj.edit'); } }
  if (bp) { bp.hidden = !S.convId; }
  if (bs) bs.hidden = !S.convId || !CAPS.share;
  if (bs) { bs.classList.toggle('on', !!(c && c.share && c.share.enabled)); }
  updatePinCount();
}
function updatePinCount() { const n = $$('#messages .msg[data-pinned="1"]').length; S.pins = n; const b = $('#pinCount'); if (b) { b.textContent = n; b.hidden = !n; } $('#btnPins')?.setAttribute('aria-pressed', String(n > 0)); }
async function loadPins() {
  updatePinCount(); const pop = $('#pinsPop'); if (!pop || pop.hidden || !S.convId) return;
  const r = await jget(API('/api/chat.php?action=pins&id=' + S.convId));
  pop.innerHTML = `<div class="pp-head">${esc(T('pin.title'))}</div>` + ((r.pins || []).length ? r.pins.map(p => `<button class="pin-item" data-goto="${p.id}"><span class="pi-role">${p.role === 'user' ? esc(T('pin.you')) : 'WanSQ'}${p.pin_label ? ' · ' + esc(p.pin_label) : ''}</span><span class="pi-txt">${esc(p.content)}</span></button>`).join('') : `<p class="list-empty sm">${esc(T('pin.empty'))}</p>`);
}
on('#btnPins', 'click', async e => { e.stopPropagation(); const pop = $('#pinsPop'); pop.hidden = !pop.hidden; e.currentTarget.setAttribute('aria-expanded', String(!pop.hidden)); if (!pop.hidden) loadPins(); });
on('#pinsPop', 'click', e => { const b = e.target.closest('[data-goto]'); if (!b) return; const t = $(`#messages [data-mid="${b.dataset.goto}"]`); $('#pinsPop').hidden = true; if (t) { t.scrollIntoView({ block: 'center' }); t.classList.add('flash'); setTimeout(() => t.classList.remove('flash'), 2400); } });

/* pindahkan percakapan ke project */
function openMovePicker(convId, currentPid) {
  const box = $('#moveList');
  box.innerHTML = (S.projects.length ? S.projects.map(p => `<button class="pick-item${+currentPid === +p.id ? ' sel' : ''}" data-mv="${p.id}">${esc(p.icon)} ${esc(p.name)}</button>`).join('') : `<p class="list-empty sm">${esc(T('proj.empty'))}</p>`)
    + `<button class="pick-item new" data-mv="new">+ ${esc(T('proj.new'))}</button>`;
  box.onclick = async e => { const b = e.target.closest('[data-mv]'); if (!b) return;
    if (b.dataset.mv === 'new') { closeModal('moveModal'); openProjectModal(0); return; }
    const r = await jpost(API('/api/chat.php?action=move'), { id: convId, project_id: +b.dataset.mv });
    if (r.ok) { closeModal('moveModal'); toast(T('toast.moved')); if (convId === S.convId) openConv(convId); refreshLists(); loadProjects(); } else toast(r.error || T('toast.mem_fail')); };
  openModal('moveModal');
}

/* ---------- SHARE ---------- */
async function openShare(id) {
  const cid = id || S.convId; if (!cid) return; const body = $('#shareBody'); body.innerHTML = `<p>${esc(T('common.loading'))}</p>`; openModal('shareModal');
  const r = await jget(API('/api/sharing.php?action=status&id=' + cid)); renderShare(cid, r);
}
function renderShare(cid, r) {
  const body = $('#shareBody'); if (!r.ok) { body.innerHTML = `<p class="err">${esc(r.error || T('toast.mem_fail'))}</p>`; return; }
  const s = r.share;
  if (!s || !s.enabled) { body.innerHTML = `<p class="pane-hint">${esc(T('share.intro'))}</p><ul class="share-note"><li>${esc(T('share.n1'))}</li><li>${esc(T('share.n2'))}</li><li>${esc(T('share.n3'))}</li></ul>${s ? `<p class="pop-hint">${esc(T('share.was_disabled'))}</p>` : ''}<div class="modal-actions"><button class="btn-primary" id="shCreate">${esc(T('share.create'))}</button></div>`; }
  else body.innerHTML = `<p class="pane-hint">${esc(T('share.active'))}</p><div class="add-row"><input id="shUrl" readonly value="${esc(s.url)}" aria-label="${esc(T('share.link'))}"><button class="btn-primary" id="shCopy">${esc(T('share.copy'))}</button></div><p class="pop-hint">${esc(T('share.views', { n: s.views }))}</p><div class="modal-actions wrap"><button class="btn-ghost" id="shUpdate">${esc(T('share.update'))}</button><button class="btn-ghost" id="shRegen">${esc(T('share.regen'))}</button><button class="btn-ghost danger-txt" id="shDisable">${esc(T('share.disable'))}</button></div><p class="pop-hint">${esc(T('share.update.hint'))}</p>`;
  const act = async (a, msg) => { const j = await jpost(API('/api/sharing.php?action=' + a), { id: cid }); renderShare(cid, j); if (j.ok) { if (S.conv && cid === S.convId) { S.conv.share = j.share; updateConvHeader(); } if (msg) toast(msg); } };
  on('#shCreate', 'click', () => act('create', T('share.created'))); on('#shDisable', 'click', () => { if (confirm(T('share.disable.confirm'))) act('disable', T('share.disabled')); });
  on('#shRegen', 'click', () => { if (confirm(T('share.regen.confirm'))) act('regenerate', T('share.regenerated')); }); on('#shUpdate', 'click', () => act('update', T('share.updated')));
  on('#shCopy', 'click', async () => { const u = $('#shUrl'); try { await navigator.clipboard.writeText(u.value); toast(T('share.copied')); } catch (e) { u.select(); document.execCommand('copy'); toast(T('share.copied')); } });
  $('#shUrl')?.addEventListener('focus', e => e.target.select());
}
on('#btnShare', 'click', () => openShare(S.convId));

/* ---------- COMMAND PALETTE (Ctrl+K) ---------- */
const CMD = { items: [], idx: 0, q: '' };
function cmdActions() {
  return [
    { g: 'act', ic: '✏️', label: T('cmd.new'), run: () => newChat() },
    { g: 'act', ic: '📁', label: T('cmd.newproj'), run: () => openProjectModal(0) },
    { g: 'act', ic: '🧠', label: T('cmd.memory'), run: () => openSettings('memory') },
    { g: 'act', ic: '⚙', label: T('cmd.settings'), run: () => openSettings('profile') },
    { g: 'act', ic: '🌐', label: T('cmd.language'), run: () => openSettings('language') },
  ];
}
function renderCmd() {
  const box = $('#cmdList'); const groups = { act: T('cmd.g.act'), chat: T('cmd.g.chat'), project: T('cmd.g.project'), file: T('cmd.g.file'), memory: T('cmd.g.memory'), artifact: 'Artifacts' };
  let html = '', last = null; CMD.items.forEach((it, i) => { if (it.g !== last) { html += `<div class="cmd-g">${esc(groups[it.g])}</div>`; last = it.g; }
    html += `<button class="cmd-it${i === CMD.idx ? ' sel' : ''}" role="option" aria-selected="${i === CMD.idx}" data-i="${i}"><span class="cmd-ic">${esc(it.ic || '')}</span><span class="cmd-tx"><span class="cmd-l">${it.html || esc(it.label)}</span>${it.sub ? `<span class="cmd-s">${it.sub}</span>` : ''}</span></button>`; });
  box.innerHTML = html || `<p class="list-empty">${esc(T('cmd.none'))}</p>`;
  box.querySelector('.sel')?.scrollIntoView({ block: 'nearest' });
}
async function cmdSearch(q) {
  CMD.q = q;
  if (!q) { CMD.items = cmdActions().concat(S.projects.slice(0, 4).map(p => ({ g: 'project', ic: p.icon, label: p.name, run: () => { S.project = p.id; renderProjects(); loadChats(); } })), S.chats.slice(0, 5).map(c => ({ g: 'chat', ic: '💬', label: c.title, run: () => openConv(c.id) }))); CMD.idx = 0; return renderCmd(); }
  const ql = q.toLowerCase(); const acts = cmdActions().filter(a => a.label.toLowerCase().includes(ql));
  let r; try { r = await jget(API('/api/search.php?scope=all&q=' + encodeURIComponent(q))); } catch (e) { r = null; } if (q !== CMD.q) return;
  const items = acts.slice();
  if (r && r.ok) {
    (r.chats || []).forEach(c => items.push({ g: 'chat', ic: c.project ? c.project.icon : '💬', label: c.title, html: (c.project ? esc(c.project.name) + ' / ' : '') + esc(c.title), sub: c.snippet, run: () => openConv(c.id, { jump: c.message_id || 0, terms: r.terms }) }));
    (r.projects || []).forEach(p => items.push({ g: 'project', ic: p.icon, label: p.name, run: () => { S.project = +p.id; renderProjects(); loadChats(); } }));
    (r.files || []).forEach(f => items.push({ g: 'file', ic: f.kind === 'image' ? '🖼️' : '📄', label: f.name, run: () => (f.kind === 'image' ? (f.conversation_id ? openConv(+f.conversation_id) : null) : openDocPreview(+f.id)) }));
    (r.memory || []).forEach(m => items.push({ g: 'memory', ic: '🧠', label: m.content, sub: m.scope === 'project' ? esc(m.project) : '', run: () => openSettings('memory') }));
    (r.artifacts || []).forEach(a => items.push({ g: 'artifact', ic: '▦', label: a.title, sub: `v${a.version} · ${a.type}`, run: () => {
      if (typeof window.wsOpen === 'function') window.wsOpen('artifacts');
    }}));
  }
  CMD.items = items; CMD.idx = 0; renderCmd();
}
const cmdSearchDebounced = debounce(q => cmdSearch(q), 180);
function openPalette() { $('#sidebar')?.classList.remove('open'); if ($('#cmdModal').hidden) openModal('cmdModal'); const i = $('#cmdInput'); i.value = ''; i.focus(); cmdSearch(''); }
function cmdRun(i) { const it = CMD.items[i]; if (!it) return; closeModal('cmdModal'); if (it.run) it.run(); }
on('#cmdInput', 'input', e => { const q = e.target.value.trim(); if (!q) cmdSearch(''); else cmdSearchDebounced(q); });
on('#cmdInput', 'keydown', e => {
  if (e.key === 'ArrowDown') { e.preventDefault(); CMD.idx = Math.min(CMD.items.length - 1, CMD.idx + 1); renderCmd(); }
  if (e.key === 'ArrowUp') { e.preventDefault(); CMD.idx = Math.max(0, CMD.idx - 1); renderCmd(); }
  if (e.key === 'Enter') { e.preventDefault(); cmdRun(CMD.idx); }
});
on('#cmdList', 'click', e => { const b = e.target.closest('[data-i]'); if (b) cmdRun(+b.dataset.i); });

/* ---------- PENGATURAN: profil, tema, bahasa, memory, trash ---------- */
function openSettings(tab) { openModal('setModal'); setTab(tab); if (tab === 'memory') loadMemories(); if (tab === 'data') loadTrash(); markTheme(); markLang(); }
function setTab(t) {
  if (S.cropping && t !== 'profile') endCrop();
  $$('.set-link').forEach(x => x.classList.toggle('active', x.dataset.tab === t));
  $$('.set-pane').forEach(p => p.classList.toggle('active', p.dataset.pane === t));
  const cr = $('#setCrumb'); if (cr) cr.textContent = T('set.' + t);
}
onAll('.set-link', 'click', e => { const t = e.currentTarget.dataset.tab; setTab(t); if (t === 'memory') loadMemories(); if (t === 'data') loadTrash(); });
function saveStatus(el, ok, msg) { if (!el) return; el.textContent = msg; el.classList.toggle('err', !ok); if (ok) setTimeout(() => el.textContent = '', 2600); }
on('#btnSaveProfile', 'click', async e => {
  const btn = e.currentTarget; btn.disabled = true; btn.textContent = T('common.saving');
  const r = await jpost(API('/api/profile.php?action=update'), { full_name: $('#setName')?.value || '', username: $('#setUsername')?.value || '' });
  btn.disabled = false; btn.textContent = T('prof.save');
  if (r.ok) { saveStatus($('#profileStatus'), true, T('common.saved')); W.user.name = r.full_name; W.user.username = r.username; const n = $('#acctName'); if (n) n.textContent = r.full_name || r.username; }
  else saveStatus($('#profileStatus'), false, r.error || T('toast.mem_fail'));
});
on('#btnSavePw', 'click', async e => {
  const nw = $('#pwNew'), nw2 = $('#pwNew2');
  if (!nw || !nw2 || nw.value !== nw2.value) return saveStatus($('#pwStatus'), false, T('pw.mismatch'));
  const btn = e.currentTarget; btn.disabled = true; btn.textContent = T('common.saving');
  const r = await jpost(API('/api/profile.php?action=password'), { old: $('#pwOld') ? $('#pwOld').value : '', new: nw.value });
  btn.disabled = false; btn.textContent = T('pw.save');
  saveStatus($('#pwStatus'), r.ok, r.ok ? T('common.saved') : (r.error || T('toast.mem_fail')));
  if (r.ok) { nw.value = ''; nw2.value = ''; const o = $('#pwOld'); if (o) o.value = ''; }
});
function markTheme() { const cur = window.WAN_THEME.get(); $$('.theme-card[data-theme]').forEach(c => c.classList.toggle('sel', c.dataset.theme === cur)); }
onAll('.theme-card[data-theme]', 'click', async e => { window.WAN_THEME.set(e.currentTarget.dataset.theme); markTheme(); await jpost(API('/api/profile.php?action=theme'), { theme: e.currentTarget.dataset.theme }); });
function markLang() { $$('[data-ui-lang]').forEach(b => b.classList.toggle('sel', b.dataset.uiLang === W.lang)); $$('[data-reply-lang]').forEach(b => b.classList.toggle('sel', b.dataset.replyLang === W.reply_lang)); }
async function savePrefs(patch) { const r = await jpost(API('/api/profile.php?action=prefs'), patch); saveStatus($('#langStatus'), r.ok, r.ok ? T('common.saved') : (r.error || T('toast.mem_fail'))); return r.ok; }
onAll('[data-ui-lang]', 'click', async e => { const l = e.currentTarget.dataset.uiLang; setLang(l); markLang(); await savePrefs({ ui_lang: l }); });
onAll('[data-reply-lang]', 'click', async e => { const l = e.currentTarget.dataset.replyLang; W.reply_lang = l; markLang(); await savePrefs({ reply_lang: l }); });
async function loadMemories() {
  const ul = $('#memList'); if (!ul) return;
  const r = await jget(API('/api/profile.php?action=memories')); const list = r.memories || [];
  ul.innerHTML = list.length ? list.map(m => `<li>${esc(m.content)}<button data-del="${m.id}" aria-label="${esc(T('common.delete'))}">✕</button></li>`).join('') : `<li class="mem-empty">${esc(T('mem.empty'))}</li>`;
  $$('#memList [data-del]').forEach(b => b.onclick = async () => { await jpost(API('/api/profile.php?action=memory_delete'), { id: +b.dataset.del }); loadMemories(); toast(T('mem.deleted')); });
}
on('#btnMemClear', 'click', async () => { if (!confirm(T('mem.clear.confirm'))) return; await jpost(API('/api/profile.php?action=memory_clear'), {}); loadMemories(); toast(T('mem.cleared')); });
async function loadTrash() {
  const ul = $('#trashList'); if (!ul) return; const r = await jget(API('/api/chat.php?action=trash_list'));
  $('#trashHint').textContent = T('trash.hint', { d: r.days || 30 }); const list = r.chats || [];
  ul.innerHTML = list.length ? list.map(c => `<li><span class="grow">${esc(c.title)} <small>${esc(c.deleted_at)}</small></span><button class="btn-ghost sm" data-restore="${c.id}">${esc(T('trash.restore'))}</button><button class="btn-ghost sm danger-txt" data-purge="${c.id}">${esc(T('trash.purge'))}</button></li>`).join('') : `<li class="mem-empty">${esc(T('trash.empty'))}</li>`;
  $$('[data-restore]', ul).forEach(b => b.onclick = async () => { await jpost(API('/api/chat.php?action=restore'), { id: +b.dataset.restore }); loadTrash(); loadChats(); loadProjects(); toast(T('trash.restored')); });
  $$('[data-purge]', ul).forEach(b => b.onclick = async () => { if (!confirm(T('trash.purge.confirm'))) return; await jpost(API('/api/chat.php?action=purge'), { id: +b.dataset.purge }); loadTrash(); toast(T('trash.purged')); });
}

/* ---------- AVATAR: crop inline di Settings ---------- */
function startCrop(source) {
  const zone = $('#cropZone'), az = $('#avatarZone');
  if (!zone || !window.WanCrop) { toast(T('crop.na')); return; }
  if ($('#setModal').hidden) openSettings('profile');
  setTab('profile'); zone.hidden = false; if (az) az.hidden = true; S.cropping = true; WanCrop.load(source);
}
function endCrop() { const zone = $('#cropZone'), az = $('#avatarZone'); if (zone) zone.hidden = true; if (az) az.hidden = false; if (window.WanCrop) WanCrop.reset(); S.cropping = false; }
async function uploadAvatarBlob(blob) {
  const fd = new FormData(); fd.append('file', blob, 'avatar-' + Date.now() + '.jpg'); fd.append('kind', 'avatar'); fd.append('csrf', W.csrf);
  setStatus('run', T('prof.saving_photo')); let ok = false;
  try {
    const res = await fetch(API('/api/upload.php'), { method: 'POST', headers: { 'X-CSRF-Token': W.csrf }, body: fd }); const r = await parseJson(res);
    if (r.ok) { const t = '?t=' + Date.now(); const a1 = $('#setAvatar'), a2 = $('#acctAvatar'); if (a1) a1.src = r.avatar + t; if (a2) a2.src = r.avatar + t; W.user.avatar = r.avatar; toast(T('prof.photo_ok')); ok = true; }
    else toast(r.error || T('prof.photo_fail'));
  } catch (e) { toast(T('prof.photo_fail')); }
  setStatus(null); return ok;
}
on('#cropSave', 'click', () => { if (!window.WanCrop) return; WanCrop.exportBlob(async b => { if (!b) { toast(T('prof.photo_fail')); return; } if (await uploadAvatarBlob(b)) endCrop(); }); });
on('#cropCancel', 'click', endCrop);
on('#avatarPick', 'change', e => { const f = e.target.files[0]; e.target.value = ''; if (!f) return; if (!(f.type || '').startsWith('image/')) { toast(T('prof.need_image')); return; } startCrop(f); });
on('#btnAvGallery', 'click', () => $('#avatarPick')?.click());
on('#btnAvCamera', 'click', () => openCam('avatar'));
on('#btnAvReset', 'click', async () => { const r = await jpost(API('/api/profile.php?action=avatar_reset'), {});
  if (r.ok) { const t = '?t=' + Date.now(); const a1 = $('#setAvatar'), a2 = $('#acctAvatar'); if (a1) a1.src = r.avatar + t; if (a2) a2.src = r.avatar + t; W.user.avatar = r.avatar; toast(T('prof.reset_ok')); } });
let camStream = null, camMode = 'avatar';
async function openCam(mode) { camMode = mode; openModal('camModal');
  try { camStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }).catch(() => navigator.mediaDevices.getUserMedia({ video: true })); } catch (e) { toast(T('cam.denied')); closeModal('camModal'); return; }
  const v = $('#camVideo'); if (v) v.srcObject = camStream; }
function stopCam() { if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; } }
on('#camShot', 'click', () => { const v = $('#camVideo'); if (!v) return;
  const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight; c.getContext('2d').drawImage(v, 0, 0);
  c.toBlob(blob => { closeModal('camModal'); if (!blob) return; if (camMode === 'avatar') startCrop(blob); else uploadFiles([new File([blob], 'kamera-' + Date.now() + '.jpg', { type: 'image/jpeg' })]); }, 'image/jpeg', .92); });

/* ================= 3.2.4 patch: custom instructions, export, read-aloud ================= */
on('#btnCiSave', 'click', async () => {
  const r = await jpost(API('/api/profile.php?action=instructions'), { custom_instructions: $('#ciText')?.value || '' });
  const st = $('#ciStatus'); if (st) { st.textContent = r.ok ? T('common.saved') : (r.error || T('toast.mem_fail')); setTimeout(() => { st.textContent = ''; }, 2500); }
});

function convExportData() {
  const msgs = $$('#messages .msg').map(m => ({ role: m.classList.contains('user') ? 'user' : 'assistant', content: (m.querySelector('.md')?.dataset.raw || m.querySelector('.md')?.textContent || '').trim() })).filter(m => m.content);
  return { title: (S.conv && S.conv.title) || $('#convTitle')?.textContent || 'WanSQ', exported_at: new Date().toISOString(), app: 'WanSQ ' + (W.version || ''), messages: msgs };
}
function downloadText(name, text, mime) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime + ';charset=utf-8' })); a.download = name;
  document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
function exportConversation(fmt) {
  const d = convExportData(); if (!d.messages.length) return toast(T('exp.empty'));
  const base = (d.title || 'wansq').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 60);
  const who = r => r === 'user' ? (W.user.name || W.user.username || 'User') : 'WanSQ';
  if (fmt === 'json') return downloadText(base + '.json', JSON.stringify(d, null, 2), 'application/json');
  if (fmt === 'md') return downloadText(base + '.md', '# ' + d.title + '\n\n' + d.messages.map(m => '### ' + who(m.role) + '\n\n' + m.content).join('\n\n---\n\n') + '\n', 'text/markdown');
  if (fmt === 'txt') return downloadText(base + '.txt', d.title + '\n' + '='.repeat(Math.min(60, d.title.length)) + '\n\n' + d.messages.map(m => who(m.role) + ':\n' + m.content).join('\n\n'), 'text/plain');
  if (fmt === 'print') {
    document.body.classList.add('printing-chat');
    const done = () => { document.body.classList.remove('printing-chat'); removeEventListener('afterprint', done); };
    addEventListener('afterprint', done); window.print(); setTimeout(done, 4000);
  }
}
on('#btnExport', 'click', e => {
  e.stopPropagation();
  popMenu(e.currentTarget, [{ head: T('exp.title') },
    { label: '⇩ ' + T('exp.md'), run: () => exportConversation('md') }, { label: '⇩ ' + T('exp.txt'), run: () => exportConversation('txt') },
    { label: '⇩ ' + T('exp.json'), run: () => exportConversation('json') }, '-', { label: '🖨 ' + T('exp.print'), run: () => exportConversation('print') }], { alignRight: true });
});
(function () { // tampilkan tombol ekspor bila ada percakapan terbuka
  const orig = window.updateConvHeader || updateConvHeader;
  updateConvHeader = function () { orig(); const w = $('#btnWorkspace'); if (w) { w.hidden = false; w.title = 'Workspace: Artifacts & Activity'; w.setAttribute('aria-label', 'Workspace'); } const b = $('#btnExport'); if (b) { b.hidden = !S.convId; b.title = T('exp.title'); b.setAttribute('aria-label', T('exp.title')); } };
})();

/* Baca-keras (Web Speech API, gratis & lokal di browser) */
const TTS = { id: null };
function ttsClean(t) { return String(t).replace(/```[\s\S]*?```/g, ' ').replace(/\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\)|\$\$[\s\S]*?\$\$/g, ' ').replace(/`([^`]+)`/g, '$1').replace(/[#*_>|~-]{1,}/g, ' ').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/https?:\/\/\S+/g, ' ').replace(/\s+/g, ' ').trim(); }
function ttsToggle(msg, btn) {
  if (!('speechSynthesis' in window)) return toast(T('tts.unsupported'));
  const synth = window.speechSynthesis;
  if (TTS.id === msg) { synth.cancel(); TTS.id = null; btn.classList.remove('on'); return; }
  synth.cancel(); $$('[data-a="tts"].on').forEach(x => x.classList.remove('on'));
  const txt = ttsClean(msg.querySelector('.md')?.dataset.raw || msg.querySelector('.md')?.textContent || ''); if (!txt) return;
  const parts = txt.match(/[^.!?。\n]{1,220}[.!?。]?/g) || [txt];
  TTS.id = msg; btn.classList.add('on');
  const lang = W.lang === 'en' ? 'en-US' : 'id-ID';
  parts.forEach((p, i) => { const u = new SpeechSynthesisUtterance(p.trim()); u.lang = lang; u.rate = 1;
    if (i === parts.length - 1) u.onend = () => { if (TTS.id === msg) { TTS.id = null; btn.classList.remove('on'); } };
    u.onerror = () => { if (TTS.id === msg) { TTS.id = null; btn.classList.remove('on'); } }; synth.speak(u); });
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-a="tts"]'); if (b) { const msg = b.closest('.msg'); if (msg) ttsToggle(msg, b); }
});
addEventListener('beforeunload', () => { try { window.speechSynthesis.cancel(); } catch (e) {} });

/* Unduh percakapan mana pun (tidak harus terbuka) sebagai Markdown, lewat API. */
window.wanDownloadConv = async function (id, title) {
  const r = await jget(API('/api/chat.php?action=messages&id=' + id));
  if (!r || !r.ok || !(r.messages || []).length) return toast(T('ctx.download.fail'));
  const who = m => m.role === 'user' ? (W.user.name || W.user.username || 'User') : 'WanSQ';
  const name = String(title || 'wansq').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 60);
  const body = r.messages.filter(m => typeof m.content === 'string' && m.content.trim()).map(m => '### ' + who(m) + '\n\n' + m.content.trim()).join('\n\n---\n\n');
  downloadText(name + '.md', '# ' + (title || 'WanSQ') + '\n\n' + body + '\n', 'text/markdown');
};
