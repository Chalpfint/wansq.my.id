/* WanSQ · MathJax config (file eksternal agar lolos CSP script-src 'self'). Harus dimuat SEBELUM MathJax. */
window.MathJax = {
  tex: { inlineMath: [['\\(', '\\)'], ['$', '$']], displayMath: [['\\[', '\\]'], ['$$', '$$']], processEscapes: true, processEnvironments: true, packages: { '[+]': ['ams'] }, tags: 'ams' },
  options: { skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code'] },
  startup: { typeset: false }
};
