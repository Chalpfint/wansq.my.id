function canonicalTex(t) {
  let x = String(t);
  // Providers can return LaTeX with duplicated escaping (e.g. \\frac or \\()).
  // Collapse 2+ backslashes only when they introduce a command/delimiter.
  // Matrix row breaks (\\ followed by whitespace/newline) are preserved.
  x = x.replace(/\\{2,}(?=[A-Za-z,])/g, '\\');
  x = x.replace(/\\{2,}(?=[\[\]\(\)])/g, '\\');
  return x.trim();
}
/* WanSQ 3.2.4 · Markdown + safe LaTeX renderer. */
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
function hl(code) {
  const protectedParts = [];
  let s = String(code).replace(/("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\/\*[\s\S]*?\*\/|\/\/[^\n]*|#[^\n]*)/g, m => {
    protectedParts.push(m); return '\u0000P' + (protectedParts.length - 1) + '\u0000';
  });
  s = esc(s)
    .replace(/\b(function|const|let|var|if|else|for|while|return|import|from|export|class|def|print|echo|try|catch|async|await|new|switch|case|break|continue|in|of|not|and|or|None|True|False|null|true|false)\b/g, '<span class="tok-k">$1</span>')
    .replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="tok-n">$1</span>');
  return s.replace(/\u0000P(\d+)\u0000/g, (_, i) => '<span class="tok-s">' + esc(protectedParts[+i]) + '</span>');
}
function codebox(f, ro) {
  const id = 'cb' + Math.random().toString(36).slice(2, 8);
  const L = String(f.lang || '').toLowerCase();
  const isJs = ['js', 'javascript'].includes(L), isPy = ['python', 'py', 'python3'].includes(L);
  const remote = L === 'php' && typeof CAPS !== 'undefined' && CAPS && CAPS.code_remote;
  const lbl = (window.T ? T('code.run') : 'Run');
  const run = ro ? '' : (isJs || isPy) ? `<button data-run="${id}" data-lang="${isPy ? 'python' : 'js'}">▶ ${lbl}</button>`
    : (remote ? `<button data-runremote="${id}" data-lang="${L}">▶ ${lbl}</button>` : '');
  return `<div class="codebox" id="${id}"><div class="cb-head"><span>${esc(f.lang)}</span><span class="sp"></span>${run}<button data-copycode="${id}">⧉ ${(window.T ? T('code.copy') : 'Copy')}</button></div><pre data-lang="${esc(f.lang)}">${hl(f.code)}</pre></div>`;
}
function md(src, opts) {
  const ro = !!(opts && opts.readonly), fences = [], codes = [], maths = [];
  let s = String(src);
  s = s.replace(/```([\w+-]*)\r?\n([\s\S]*?)```/g, (_, l, c) => { fences.push({lang:l || 'text', code:c}); return '\u0000F' + (fences.length - 1) + '\u0000'; });
  s = s.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return '\u0000C' + (codes.length - 1) + '\u0000'; });
  // Normalize provider over-escaped math delimiters after code protection.
  // This intentionally handles 2, 3, 4... backslashes before a delimiter.
  s = s.replace(/\\{2,}(?=[\[\]\(\)])/g, '\\');
  s = s.replace(/\$\$([\s\S]*?)\$\$/g, (_, c) => { maths.push({display:true, tex:canonicalTex(c)}); return '\u0000M' + (maths.length - 1) + '\u0000'; });
  s = s.replace(/\\\[([\s\S]*?)\\\]/g, (_, c) => { maths.push({display:true, tex:canonicalTex(c)}); return '\u0000M' + (maths.length - 1) + '\u0000'; });
  s = s.replace(/\\\(([^\n]*?)\\\)/g, (_, c) => { maths.push({display:false, tex:canonicalTex(c)}); return '\u0000M' + (maths.length - 1) + '\u0000'; });
  s = s.replace(/\$([^$\n]+)\$/g, (_, c) => { maths.push({display:false, tex:canonicalTex(c)}); return '\u0000M' + (maths.length - 1) + '\u0000'; });
  s = esc(s);
  const inline = t => t
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\W)\*([^*\n]+)\*/g, '$1<em>$2</em>')
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  const L = s.split(/\r?\n/), out = [];
  let list = null, table = null, para = [];
  const fP = () => {
    if (!para.length) return;
    const text = para.join(' '); let last = 0, m; const re = /\u0000M(\d+)\u0000/g;
    while ((m = re.exec(text))) {
      const it = maths[+m[1]]; if (!it || it.display) continue;
      const before = text.slice(last, m.index); if (before.trim()) out.push('<p>' + inline(before) + '</p>');
      out.push(m[0]); last = m.index + m[0].length;
    }
    const after = text.slice(last); if (after.trim()) out.push('<p>' + inline(after) + '</p>');
    para = [];
  };
  const fL = () => { if (list) { out.push('<' + list.t + '>' + list.i.map(x => '<li>' + inline(x) + '</li>').join('') + '</' + list.t + '>'); list = null; } };
  const fT = () => { if (table) { out.push('<div class="table-wrap"><table>' + table.r.map((r,i) => '<tr>' + r.map(c => (i ? '<td>' : '<th>') + inline(c) + (i ? '</td>' : '</th>')).join('') + '</tr>').join('') + '</table></div>'); table = null; } };
  for (const ln of L) {
    let m;
    if ((m = ln.match(/^(#{1,6})\s+(.*)/))) { fP(); fL(); fT(); const lv = m[1].length + 1; out.push(`<h${lv}>${inline(m[2])}</h${lv}>`); continue; }
    if (/^(-{3,}|\*{3,})$/.test(ln.trim())) { fP(); fL(); fT(); out.push('<hr>'); continue; }
    if ((m = ln.match(/^>\s?(.*)/))) { fP(); fL(); fT(); out.push('<blockquote>' + inline(m[1]) + '</blockquote>'); continue; }
    if ((m = ln.match(/^\s*[-*]\s+(.*)/))) { fP(); fT(); list = (list && list.t === 'ul') ? list : {t:'ul',i:[]}; list.i.push(m[1]); continue; }
    if ((m = ln.match(/^\s*\d+\.\s+(.*)/))) { fP(); fT(); list = (list && list.t === 'ol') ? list : {t:'ol',i:[]}; list.i.push(m[1]); continue; }
    if (/^\s*\|.*\|\s*$/.test(ln)) { fP(); fL(); const c = ln.trim().slice(1,-1).split('|').map(x => x.trim()); if (!table) table = {r:[]}; if (!c.every(x => /^:?-{2,}:?$/.test(x))) table.r.push(c); continue; }
    if ((m = ln.match(/^\u0000F(\d+)\u0000$/))) { fP(); fL(); fT(); out.push(m[0]); continue; }
    if ((m = ln.match(/^\u0000M(\d+)\u0000$/)) && maths[+m[1]] && maths[+m[1]].display) { fP(); fL(); fT(); out.push(m[0]); continue; }
    if (!ln.trim()) { fP(); fL(); fT(); continue; }
    para.push(ln);
  }
  fP(); fL(); fT();
  return out.join('\n')
    .replace(/\u0000F(\d+)\u0000/g, (_,i) => codebox(fences[+i],ro))
    .replace(/\u0000C(\d+)\u0000/g, (_,i) => '<code>' + esc(codes[+i]) + '</code>')
    .replace(/\u0000M(\d+)\u0000/g, (_,i) => maths[+i].display ? '<div class="math-display">\\[' + esc(maths[+i].tex) + '\\]</div>' : '<span class="math-inline">\\(' + esc(maths[+i].tex) + '\\)</span>');
}
