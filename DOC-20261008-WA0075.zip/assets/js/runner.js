/* WanSQ · code runner — berjalan DI DALAM <iframe sandbox="allow-scripts"> (origin opaque: tanpa cookie, tanpa akses DOM/API induk).
 * JS  : dieksekusi di Web Worker blob: (async function, console.* ditangkap).
 * Py  : Pyodide (WebAssembly) di Web Worker blob: → loop tak berujung dapat dihentikan induk dengan menghapus iframe.
 * CSP khusus runner.html diatur di .htaccess (unsafe-eval hanya berlaku untuk dokumen terisolasi ini). */
(function () {
  'use strict';
  var worker = null, wseq = 0, wpending = {};
  /* JS juga dijalankan di Web Worker (blob:) — loop tak berujung hanya membakar worker, bukan thread utama tab;
     induk menghapus iframe saat timeout sehingga worker ikut mati. */
  var JSSRC = [
    'var out=[];',
    'function fmt(x){if(typeof x==="string")return x;if(x instanceof Error)return x.name+": "+x.message;try{return typeof x==="object"?JSON.stringify(x):String(x);}catch(e){return String(x);}}',
    '["log","info","warn","error","debug"].forEach(function(k){console[k]=function(){out.push((k==="error"?"Error: ":k==="warn"?"Warning: ":"")+[].slice.call(arguments).map(fmt).join(" "));};});',
    'onmessage=async function(e){try{var AF=Object.getPrototypeOf(async function(){}).constructor;var r=await new AF(e.data.code)();if(r!==undefined&&!out.length)out.push(fmt(r));}',
    'catch(err){out.push("Error: "+(err&&err.message?err.message:err));}',
    'postMessage({out:out.join("\\n")});};'
  ].join('\n');
  function runJs(code) {
    return new Promise(function (resolve) {
      try {
        var w = new Worker(URL.createObjectURL(new Blob([JSSRC], { type: 'text/javascript' })));
        w.onmessage = function (ev) { resolve((ev.data && ev.data.out) || ''); w.terminate(); };
        w.onerror = function (ev) { resolve('Error: ' + (ev.message || 'Worker error')); w.terminate(); };
        w.postMessage({ code: code });
      } catch (e) { resolve('Error: ' + (e && e.message ? e.message : e)); }
    });
  }
  var WSRC = [
    'var py=null;',
    'onmessage=async function(e){var d=e.data;try{',
    '  if(!py){importScripts(d.base+"pyodide.js");py=await loadPyodide({indexURL:d.base});}',
    '  var out=[];py.setStdout({batched:function(s){out.push(s);}});py.setStderr({batched:function(s){out.push(s);}});',
    '  var g=py.globals.get("dict")();',
    '  try{var r=await py.runPythonAsync(d.code,{globals:g});if(r!==undefined&&r!==null&&!out.length)out.push(String(r));}',
    '  catch(err){out.push(String(err&&err.message?err.message:err));}',
    '  finally{try{g.destroy();}catch(_){}}',
    '  postMessage({id:d.id,out:out.join("\\n")});',
    '}catch(err){postMessage({id:d.id,fatal:String(err&&err.message?err.message:err)});}};'
  ].join('\n');
  function runPy(code, base) {
    return new Promise(function (resolve) {
      try {
        if (!worker) {
          worker = new Worker(URL.createObjectURL(new Blob([WSRC], { type: 'text/javascript' })));
          worker.onmessage = function (ev) { var d = ev.data || {}; var p = wpending[d.id]; if (p) { delete wpending[d.id]; p(d); } };
          worker.onerror = function (ev) { Object.keys(wpending).forEach(function (k) { wpending[k]({ fatal: ev.message || 'Worker error' }); delete wpending[k]; }); };
        }
        var id = ++wseq; wpending[id] = resolve;
        worker.postMessage({ id: id, code: code, base: base });
      } catch (e) { resolve({ fatal: String(e && e.message ? e.message : e) }); }
    });
  }
  window.addEventListener('message', async function (ev) {
    var d = ev.data;
    if (ev.source !== window.parent || !d || d.__wr !== 1) return;
    var res;
    if (d.lang === 'python') {
      var r = await runPy(String(d.code || ''), String(d.pyBase || ''));
      res = r.fatal ? { fatal: r.fatal } : { out: r.out };
    } else {
      res = { out: await runJs(String(d.code || '')) };
    }
    window.parent.postMessage({ __wr: 'result', id: d.id, out: res.out, fatal: res.fatal }, '*');
  });
  window.parent.postMessage({ __wr: 'ready' }, '*');
})();
