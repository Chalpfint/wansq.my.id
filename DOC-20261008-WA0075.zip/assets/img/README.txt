Letakkan file logo Anda di folder ini dengan nama PERSIS:
  wan-blue.png   → logo "Wan" biru, background transparan (light mode + favicon)
  wan-dark.png   → logo "Wan" abu-abu gelap, background transparan (dark mode)
  favicon.png    → wan-blue.png di-resize 64×64 (ikon tab browser)
  avatar-default.svg → opsional (siluet default)
Selama file PNG belum ada, sistem otomatis memakai fallback SVG:
  wan-blue.svg, wan-dark.svg