# WanSQ v3.2.5 — Implementation Details & Technical Guide

**Document Version:** 1.0  
**Application Version:** 3.2.5  
**Database Schema:** 4.1.5  
**Date:** 2026-10-08

---

## 🎯 Implementation Overview

This document provides technical details for developers and system administrators implementing or maintaining WanSQ v3.2.5.

---

## 📁 File Structure

```
wansq/
├── index.php                           # Landing page
├── app.php                             # Main application shell
├── includes/
│   ├── config.php                      # Configuration loader
│   ├── config.local.php               # Local configuration (not in repo)
│   ├── config_ext.php                 # Extended configuration
│   ├── error_handler_v325.php         # ✨ NEW: Error handling system
│   ├── model_router.php               # ✨ NEW: Model routing engine
│   ├── openrouter_decisions.php       # Luna 6 integration
│   ├── chat_lib.php                   # Chat functionality
│   ├── auth.php                       # Authentication
│   ├── db.php                         # Database connection
│   ├── helpers.php                    # Utility functions
│   └── ... other modules
├── api/
│   ├── chat.php                       # Chat API
│   ├── image.php                      # ✨ NEW: Image processing
│   ├── research.php                   # ✨ NEW: Research mode
│   ├── decisions.php                  # Luna 6 decisions
│   └── ... other APIs
├── assets/
│   ├── css/style.css                  # Styles
│   ├── js/                            # JavaScript
│   └── img/                           # Images
├── sql/
│   ├── wansq_schema_v4.1.5_complete.sql        # ✨ Complete schema
│   └── wansq_migration_v4.1.3_to_v4.1.5.sql    # ✨ Migration only
└── docs/
    ├── WanSQ_UPDATE_HISTORY.md        # Version history
    └── WanSQ_IMPLEMENTATION_DETAILS.md # This file
```

---

## 🔧 Core Modules (v3.2.5)

### 1. error_handler_v325.php (15 KB)

**Purpose:** Production-grade error handling with recovery strategies

**Key Classes:**
```php
class ErrorHandlerV325
```

**Main Methods:**

```php
// Initialize error handlers
static function init(): void
    - Registers PHP error handler
    - Registers exception handler
    - Registers shutdown handler

// Handle PHP errors
static function handlePHPError(int $errno, string $errstr, string $errfile, int $errline): bool
    - Catches all error types
    - Logs with context
    - Returns recovery response

// Handle exceptions
static function handleException(Throwable $e): void
    - Catches all exceptions
    - Logs full stack trace
    - Returns error response

// Get error context
static function getContext(): array
    - Returns: user_id, method, uri, ip, memory_usage
    - Filters sensitive data
    - Includes timestamp

// Retry with exponential backoff
static function retry(callable $fn, int $maxAttempts = 3, string $errorType = 'network'): mixed
    - Implements exponential backoff
    - Handles timeouts and transient failures
    - Returns result or throws on final failure

// Safe API call wrapper
static function safeApiCall(string $url, array $options = []): array
    - Wraps curl_exec() with error handling
    - Returns ['ok' => bool, 'data' => response, 'error' => string]

// Get recovery response
static function getRecoveryResponse(string $errorType): array
    - Returns HTTP code, retry signals
    - For: model, rate_limit, timeout, auth, database, validation
```

**Error Categories & Retry Logic:**

| Error Type | HTTP | Max Retries | Strategy |
|-----------|------|-------------|----------|
| model | 503 | 3 | Exponential |
| rate_limit | 429 | 5 | Exponential |
| timeout | 504 | 2 | Linear |
| auth | 401 | 0 | None |
| database | 500 | 3 | Exponential |
| validation | 400 | 0 | None |

**Usage Example:**
```php
require_once 'error_handler_v325.php';

// Initialize on app start
ErrorHandlerV325::init();

// Safe API call
$result = ErrorHandlerV325::safeApiCall('https://api.example.com/endpoint', [
    'method' => 'POST',
    'headers' => ['Authorization: Bearer TOKEN'],
    'body' => json_encode(['query' => 'test'])
]);

if ($result['ok']) {
    echo $result['data'];
} else {
    error_log("API Error: " . $result['error']);
}

// Retry with backoff
try {
    $data = ErrorHandlerV325::retry(function() {
        return call_expensive_operation();
    }, 3, 'network');
} catch (Throwable $e) {
    handle_error($e);
}
```

---

### 2. model_router.php (25 KB)

**Purpose:** Intelligent automatic model selection

**Key Class:**
```php
class ModelRouter
```

**Main Methods:**

```php
// Route a query to the best model
function route(string $query, array $context = [], string $mode = ''): array
    - Input: query string, context array, optional mode
    - Returns: ['model' => string, 'label' => string, 'reasoning' => string]

// Detect query mode (uses Luna 6 or heuristic)
function detectMode(string $query, array $context = []): array
    - Returns: ['type' => string, 'complexity' => int, 'needs_reasoning' => bool, 'urgency' => string]

// Heuristic mode detection (fallback)
function detectModeHeuristic(string $query): string
    - Returns: 'vision' | 'research' | 'reasoning' | 'quick' | 'general'

// Route based on detected mode
function routeByDetection(array $detection): string
    - Returns model ID based on detection results

// Get available models
function getModels(): array
    - Returns array of all available models with specs

// Get specific model info
function getModel(string $modelId): ?array
    - Returns model config or null

// Get routing metrics
function getMetrics(): array
    - Returns routing statistics for this session
```

**Available Models:**

```php
[
    'qwen/qwen3.8-27b' => [
        'name' => 'Qwen3.8 27B',
        'type' => 'general_qa',
        'latency_ms' => 1200,
        'cost_per_1k' => 0.001,
        'context_window' => 131072,
        'supports' => ['text', 'json', 'tool_use']
    ],
    'qwen/qwen3-30b-a3b' => [
        'name' => 'Qwen3 30B A3B',
        'type' => 'complex_reasoning',
        'latency_ms' => 1800,
        'cost_per_1k' => 0.001,
        'context_window' => 131072,
        'supports' => ['text', 'reasoning', 'json']
    ],
    // ... more models
]
```

**Decision Tree Logic:**

```
Query received
    ↓
Analyze with Luna 6 (or heuristic if unavailable)
    ├─ Type: vision?
    │   └─→ Qwen2.5 VL 72B
    ├─ Type: research + complex?
    │   ├─ Urgent?
    │   │   └─→ Qwen3 30B (fast research)
    │   └─ Normal
    │       └─→ Qwen3 235B (deep research)
    ├─ Urgent + !reasoning?
    │   └─→ GPT-OSS 20B (ultra-fast)
    ├─ Complex + reasoning?
    │   └─→ Qwen3 30B
    └─ Default
        └─→ Qwen3.8 27B
    ↓
Log decision in model_usage_log
    ↓
Return model ID
```

**Usage Example:**
```php
require_once 'model_router.php';

$router = new ModelRouter();

// Route a query
$routing = $router->route(
    "Analyze this image and tell me what you see",
    ['attachments' => 1],
    'auto'
);

// Returns:
// [
//     'model' => 'qwen/qwen2.5-vl-72b-instruct',
//     'label' => 'Vision Analysis',
//     'reasoning' => 'Image attachment detected'
// ]

// Send to selected model
$result = call_model($routing['model'], $query);

// Log metrics
$pdo->prepare('INSERT INTO model_usage_log (user_id, model_selected, query_type, routing_source) VALUES (?, ?, ?, ?)')
    ->execute([$uid, $routing['model'], 'vision', 'model_router']);
```

---

### 3. api/image.php (12 KB)

**Purpose:** Image processing API with routing

**Endpoints:**

```bash
POST /api/image.php?action=analyze
    Input: {image_id: int, prompt: string}
    Output: {ok: bool, id: int, model: string, analysis: string}

POST /api/image.php?action=generate
    Input: {prompt: string, style: string}
    Output: {ok: bool, id: int, url: string, model: string}

POST /api/image.php?action=edit
    Input: {image_id: int, instructions: string}
    Output: {ok: bool, id: int, url: string}
```

**Database Integration:**
- Logs all operations to `image_history` table
- Tracks processing time, model used, status
- Records file size and metadata

---

### 4. api/research.php (14 KB)

**Purpose:** Deep research with multi-source synthesis

**Endpoints:**

```bash
POST /api/research.php?action=start
    Input: {query: string, conversation_id?: int}
    Output: {ok: bool, request_id: int, status: string}

GET /api/research.php?action=status&request_id=42
    Output: {ok: bool, status: string, sources_count: int}

GET /api/research.php?action=result&request_id=42
    Output: {ok: bool, result: object, sources: array, status: string}

GET /api/research.php?action=analytics
    Output: {ok: bool, stats: object, recent: array}
```

**Database Integration:**
- Stores research in `research_requests` table
- Sources tracked in `research_sources` table
- Relevance scoring for each source
- Attribution metadata

---

## 💾 Database Schema v4.1.5

### Complete Schema Structure

**User Tables:**
- `users` — User accounts and profiles
- `projects` — User projects (optional grouping)
- `project_memories` — Project-specific memory

**Conversation Tables:**
- `conversations` — Chat conversations
- `messages` — Individual messages
- `conversation_branches` — Message editing branches
- `attachments` — File attachments in messages

**Sharing & Access:**
- `shares` — Public conversation shares
- `comments` — Comments on shared conversations

**Analytics & Tracking (NEW):**
- `model_usage_log` — Model selection metrics
- `decisions_log` — Luna 6 decision history
- `image_history` — Image operations
- `research_requests` — Research requests
- `research_sources` — Research attribution
- `user_analytics` — Daily user statistics
- `conversation_tags` — Conversation tags
- `api_quota_log` — API usage tracking

**Version Management:**
- `schema_version` — Migration tracking

### Key Indexes (25+)

```sql
-- Performance indexes
idx_user_created          (user_id, created_at)
idx_model_selected        (model_selected)
idx_query_type           (query_type)
idx_satisfaction         (user_satisfaction)
idx_status               (status)
idx_user_date            (user_id, date)

-- Search indexes
ft_input                 FULLTEXT (decisions_log.input_text)
ft_query                 FULLTEXT (research_requests.research_query)
ft_proj_name             FULLTEXT (projects.name)
```

---

## 🔄 Migration Process

### From v4.1.3 to v4.1.5

**Using MySQL CLI:**
```bash
mysql -u root -p wansq_db < sql/wansq_migration_v4.1.3_to_v4.1.5.sql
```

**Using Navicat:**
1. Right-click database → Query → New Query
2. Open `sql/wansq_migration_v4.1.3_to_v4.1.5.sql`
3. Execute (Run All or F9)

**Verification:**
```sql
-- Check new tables
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA='wansq_db' 
AND TABLE_NAME IN ('model_usage_log','decisions_log','image_history','research_requests','research_sources','user_analytics','conversation_tags','api_quota_log');

-- Expected: 8 rows
```

---

## ⚙️ Configuration Guide

### config.local.php Template

```php
<?php
return [
    // Database
    'DB_HOST' => 'localhost',
    'DB_PORT' => '3306',
    'DB_NAME' => 'wansq_db',
    'DB_USER' => 'root',
    'DB_PASS' => 'password',
    
    // OpenRouter
    'OPENROUTER_API_KEY' => 'sk-or-v1-GANTI_DENGAN_KEY_ANDA',
    'OPENROUTER_BASE' => 'https://openrouter.ai/api/v1',
    'OPENROUTER_REFERER' => 'https://wansq.my.id',
    'OPENROUTER_TITLE' => 'WanSQ',
    
    // Performance tuning
    'MAX_OUTPUT_TOKENS' => 8192,
    'CONTEXT_CHAR_BUDGET' => 120000,
    'RATE_LIMIT_PER_MIN' => 60,
    'SEND_AUTO_RETRY' => 2,
    
    // Optional: Custom models
    'MODEL_CHAT' => 'qwen/qwen3-235b-a22b',
    'MODEL_FAST' => 'qwen/qwen3.8-27b',
    'MODEL_VISION' => 'qwen/qwen2.5-vl-72b-instruct',
];
```

---

## 🐛 Troubleshooting

### Issue: "Model not found"
**Cause:** Model unavailable on OpenRouter  
**Solution:** Update MODEL_CHAT, MODEL_FAST, MODEL_VISION in config.local.php

### Issue: "Luna 6 decision call failed"
**Cause:** API key invalid or rate limited  
**Solution:**
```bash
grep OPENROUTER_API_KEY includes/config.local.php
curl https://openrouter.ai/api/v1/auth/whoami -H "Authorization: Bearer YOUR_KEY"
```

### Issue: Database migration fails
**Cause:** Foreign key constraints or schema mismatch  
**Solution:**
```bash
mysql -u root -p wansq_db -e "SELECT * FROM schema_version WHERE version LIKE '4.1%';"
mysql -u root -p wansq_db < sql/wansq_migration_v4.1.3_to_v4.1.5.sql
```

### Issue: High memory usage
**Cause:** Caching accumulation in error_handler  
**Solution:**
```bash
rm -rf storage/cache/*.json
rm -rf storage/logs/errors_*.log
systemctl restart php-fpm
```

---

## 📊 Monitoring & Analytics

### Model Usage
```sql
SELECT model_selected, COUNT(*) as count, 
    ROUND(AVG(response_time_ms), 2) as avg_time_ms,
    ROUND(SUM(cost_cents)/100, 2) as cost_usd
FROM model_usage_log
WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY model_selected
ORDER BY count DESC;
```

### Error Tracking
```sql
SELECT error_code, COUNT(*) as count,
    ROUND(AVG(response_time_ms), 2) as avg_time_ms
FROM model_usage_log
WHERE error_code IS NOT NULL
AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY);
```

### User Analytics
```sql
SELECT date, user_id, requests_count, avg_response_time_ms,
    total_cost_cents, avg_satisfaction_score
FROM user_analytics
WHERE date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
ORDER BY date DESC;
```

---

## ✅ Rollback Procedure

If critical issues occur:

```bash
# 1. Stop web server
systemctl stop nginx

# 2. Restore previous version
rm -rf /path/to/wansq
cp -r /path/to/wansq-backup /path/to/wansq

# 3. Drop new tables (if needed)
mysql -u root -p wansq_db -e "
  DROP TABLE IF EXISTS model_usage_log, decisions_log, image_history,
    research_requests, research_sources, user_analytics,
    conversation_tags, api_quota_log;
  DELETE FROM schema_version WHERE version = '4.1.5';
"

# 4. Restore database
mysql -u root -p wansq_db < wansq-backup.sql

# 5. Restart
systemctl start nginx
```

---

## 🎓 Integration Examples

### Python Client
```python
import requests
import json

class WanSQClient:
    def __init__(self, base_url, token):
        self.base_url = base_url
        self.headers = {'Authorization': f'Bearer {token}'}
    
    def start_research(self, query):
        return requests.post(
            f'{self.base_url}/api/research.php?action=start',
            json={'query': query},
            headers=self.headers
        ).json()
    
    def get_research_result(self, request_id):
        return requests.get(
            f'{self.base_url}/api/research.php?action=result&request_id={request_id}',
            headers=self.headers
        ).json()

# Usage
client = WanSQClient('https://wansq.my.id', 'YOUR_TOKEN')
result = client.start_research('Latest AI trends in 2026')
print(f"Research started: {result['request_id']}")
```

---

## 📝 Notes

- All APIs require authentication (token-based)
- All responses are JSON with `ok` and optional `error` fields
- Rate limiting: 60 requests/minute per user
- Context budget: 120,000 characters max
- Max output: 8,192 tokens
- All sensitive data filtered from logs
- HTTPS required for production
- CSRF protection on all forms

---

**Made with precision and care for enterprise deployment**

Version: 3.2.5 | Database: 4.1.5 | Last Updated: 2026-10-08

