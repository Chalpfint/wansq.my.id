<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/docs.php';
require __DIR__ . '/../includes/search_lib.php';
session_boot();
$user = require_api_login();
$uid = (int)$user['id'];
session_write_close();
$q = trim((string)($_GET['q'] ?? ''));
if (mb_strlen($q) > 120) $q = mb_substr($q, 0, 120);
if (!rate_bucket_ok($uid, 'search', 240)) json_out(['ok' => false, 'error' => 'Terlalu banyak pencarian'], 429);
try {
    if (($_GET['scope'] ?? 'chats') === 'all') { $r = search_all($uid, $q); json_out(['ok' => true] + $r); }
    $off = max(0, (int)($_GET['offset'] ?? 0)); $lim = min(50, max(1, (int)($_GET['limit'] ?? 20)));
    $proj = (int)($_GET['project'] ?? 0);
    $arch = isset($_GET['archived']) && $_GET['archived'] !== '' ? (int)$_GET['archived'] : null;
    $r = search_chats($uid, $q, $off, $lim, $proj ?: null, $arch);
    json_out(['ok' => true, 'q' => $q, 'items' => $r['items'], 'total' => $r['total'], 'ms' => $r['ms'], 'terms' => $r['terms'] ?? [], 'next' => ($off + $lim) < $r['total'] ? $off + $lim : null]);
} catch (Throwable $e) { app_log('search fatal: ' . $e->getMessage()); $kind = db_is_connection_error($e) ? 'database_connection_lost' : 'search_failure'; json_out(['ok' => false, 'error' => $kind === 'database_connection_lost' ? 'Koneksi database terputus. Coba ulangi pencarian.' : 'Pencarian gagal diproses. Coba lagi.', 'kind' => $kind], 500); }
