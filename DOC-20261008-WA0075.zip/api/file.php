<?php
declare(strict_types=1);
/** Penyaji lampiran privat: hanya pemilik (sesi login) yang dapat mengakses. Path storage tidak pernah terekspos. */
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/groq.php';
session_boot();
$user = require_api_login();
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare('SELECT * FROM attachments WHERE id=? AND user_id=? AND removed=0');
$st->execute([$id, (int)$user['id']]);
$a = $st->fetch();
if (!$a) { http_response_code(404); header('Content-Type: text/plain'); exit('Not found'); }
$fs = stored_to_fs((string)$a['stored_path']);
if (!is_file($fs)) { http_response_code(404); header('Content-Type: text/plain'); exit('File hilang'); }
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($fs) ?: 'application/octet-stream';
$isImg = $a['kind'] === 'image' && strpos($mime, 'image/') === 0;
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=3600, no-transform');
header('Content-Length: ' . filesize($fs));
if ($isImg && empty($_GET['dl'])) {
    header('Content-Type: ' . $mime);
    header('Content-Disposition: inline; filename="' . rawurlencode((string)$a['original_name']) . '"');
} else {
    header('Content-Type: ' . ($isImg ? $mime : ($a['mime'] ?: 'application/octet-stream')));
    header('Content-Disposition: attachment; filename="' . rawurlencode((string)$a['original_name']) . '"');
}
readfile($fs);
