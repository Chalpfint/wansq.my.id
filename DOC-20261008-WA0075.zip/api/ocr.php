<?php
declare(strict_types=1);
/** OCR halaman PDF hasil pindai. Halaman dirender di browser (pdf.js) → dikirim sebagai gambar → dibaca model vision. */
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/models.php';
require __DIR__ . '/../includes/docs.php';
require __DIR__ . '/../includes/vision.php';

session_boot();
$user = require_api_login();
$uid = (int)$user['id']; $pdo = db();
csrf_check();
$act = (string)($_GET['action'] ?? 'page');

$attId = (int)($_POST['att_id'] ?? ($_GET['att_id'] ?? 0));
$st = $pdo->prepare("SELECT * FROM attachments WHERE id=? AND user_id=? AND kind='doc' AND removed=0"); $st->execute([$attId, $uid]); $att = $st->fetch();
if (!$att || $att['mime'] !== 'application/pdf') json_out(['ok' => false, 'error' => 'Dokumen PDF tidak ditemukan'], 404);

try {
    if ($act === 'finish') {
        $n = (int)$pdo->query('SELECT COUNT(*) FROM doc_chunks WHERE attachment_id=' . $attId)->fetchColumn();
        $status = $n > 0 ? 'ready' : 'failed';
        $pdo->prepare('UPDATE attachments SET status=? WHERE id=?')->execute([$status, $attId]);
        json_out(['ok' => true, 'status' => $status, 'chunks' => $n]);
    }
    if (!llm_available('vision', true)) json_out(['ok' => false, 'error' => 'Model vision untuk OCR tidak tersedia'], 503);
    if (!rate_bucket_ok($uid, 'ocr', OCR_RATE_PER_MIN)) json_out(['ok' => false, 'error' => 'Terlalu banyak permintaan OCR, tunggu sebentar'], 429);
    $page = (int)($_POST['page'] ?? 0);
    if ($page < 1 || $page > max(1, (int)$att['pages'])) json_out(['ok' => false, 'error' => 'Nomor halaman tidak valid'], 422);
    if (empty($_FILES['img']) || $_FILES['img']['error'] !== UPLOAD_ERR_OK) json_out(['ok' => false, 'error' => 'Gambar halaman tidak diterima'], 422);
    $img = $_FILES['img']; if ($img['size'] > 6 * 1048576) json_out(['ok' => false, 'error' => 'Gambar halaman terlalu besar'], 413);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($img['tmp_name']);
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) json_out(['ok' => false, 'error' => 'Format gambar halaman tidak didukung'], 415);
    $t0 = microtime(true);
    $r = vision_ocr_page((string)file_get_contents($img['tmp_name']), $mime, $page);
    if (!$r['ok']) { app_log("ocr fail att=$attId p=$page err=" . mb_substr((string)$r['err'], 0, 150)); json_out(['ok' => false, 'error' => 'OCR gagal: ' . mb_substr((string)$r['err'], 0, 140)], 502); }
    $txt = doc_clean($r['text']); $blank = (mb_strtolower(trim($txt, "[] \n")) === 'halaman kosong') || $txt === '';
    $pdo->prepare("DELETE FROM doc_chunks WHERE attachment_id=? AND page_start=? AND page_end=? AND source='ocr'")->execute([$attId, $page, $page]);
    $n = 0;
    if (!$blank) $n = doc_store_chunks($attId, $uid, doc_make_chunks([$page => $txt]), 'ocr');
    $cnt = (int)$pdo->query("SELECT COUNT(DISTINCT page_start) FROM doc_chunks WHERE attachment_id=$attId AND source='ocr'")->fetchColumn();
    $pdo->prepare('UPDATE attachments SET ocr_pages=? WHERE id=?')->execute([$cnt, $attId]);
    app_log(sprintf('ocr att=%d page=%d chars=%d chunks=%d ms=%d', $attId, $page, mb_strlen($txt), $n, ms_since($t0)));
    json_out(['ok' => true, 'page' => $page, 'chars' => mb_strlen($txt), 'blank' => $blank, 'ocr_pages' => $cnt, 'ms' => ms_since($t0)]);
} catch (Throwable $e) {
    app_log('ocr fatal: ' . $e->getMessage());
    $kind = db_is_connection_error($e) ? 'database_connection_lost' : 'ocr_failure';
    json_out(['ok' => false, 'error' => $kind === 'database_connection_lost' ? 'Koneksi database terputus saat menyimpan hasil OCR. Coba ulangi halaman ini.' : 'OCR gagal diproses. Coba ulangi halaman ini.', 'kind' => $kind], 500);
}
