<?php
/**
 * WanSQ v3.2.4 — Decisions API Endpoint
 * GPT Luna 6 Intelligent Decision Making
 *
 * Endpoints:
 * POST /api/decisions.php?action=classify    → Classify message (urgency, sentiment, intent)
 * POST /api/decisions.php?action=route       → Route query to appropriate feature
 * POST /api/decisions.php?action=analyze     → Analyze document/file
 * POST /api/decisions.php?action=detect      → Detect user intent
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/openrouter_decisions.php';
require_once __DIR__ . '/../includes/performance.php';

PerformanceMonitor::start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Check authentication
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Check Decisions API availability
if (!OpenRouterDecisions::isAvailable()) {
    http_response_code(503);
    echo json_encode(['error' => 'Decisions API not configured']);
    exit;
}

try {
    $action = $_GET['action'] ?? '';
    $decisions = new OpenRouterDecisions();
    $result = null;

    switch ($action) {
        case 'classify':
            // Classify a message for urgency, sentiment, intent
            $input = json_decode(file_get_contents('php://input'), true);

            if (!isset($input['message'])) {
                throw new Exception('Missing required field: message');
            }

            $message = trim($input['message']);
            if (strlen($message) === 0) {
                throw new Exception('Message cannot be empty');
            }
            if (strlen($message) > 4000) {
                throw new Exception('Message too long (max 4000 chars)');
            }

            $result = $decisions->classifyMessage($message);
            break;

        case 'route':
            // Route user query to appropriate feature
            $input = json_decode(file_get_contents('php://input'), true);

            if (!isset($input['query'])) {
                throw new Exception('Missing required field: query');
            }

            $query = trim($input['query']);
            $context = $input['context'] ?? '';

            if (strlen($query) === 0) {
                throw new Exception('Query cannot be empty');
            }
            if (strlen($query) > 2000) {
                throw new Exception('Query too long (max 2000 chars)');
            }

            $result = $decisions->routeQuery($query, $context);
            break;

        case 'analyze':
            // Analyze document for processing strategy
            $input = json_decode(file_get_contents('php://input'), true);

            if (!isset($input['filename']) || !isset($input['preview'])) {
                throw new Exception('Missing required fields: filename, preview');
            }

            $filename = trim($input['filename']);
            $preview = trim($input['preview']);

            if (strlen($filename) === 0 || strlen($preview) === 0) {
                throw new Exception('Filename and preview cannot be empty');
            }
            if (strlen($preview) > 1000) {
                $preview = substr($preview, 0, 1000);
            }

            $result = $decisions->analyzeDocument($filename, $preview);
            break;

        case 'detect':
            // Detect user intent
            $input = json_decode(file_get_contents('php://input'), true);

            if (!isset($input['query'])) {
                throw new Exception('Missing required field: query');
            }

            $query = trim($input['query']);

            if (strlen($query) === 0) {
                throw new Exception('Query cannot be empty');
            }
            if (strlen($query) > 2000) {
                throw new Exception('Query too long (max 2000 chars)');
            }

            $result = $decisions->detectIntent($query);
            break;

        default:
            throw new Exception("Unknown action: $action");
    }

    // Mark completion for performance monitoring
    PerformanceMonitor::mark('decisions_complete');
    PerformanceMonitor::logToHeader();

    // Success response
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'action' => $action,
        'result' => $result,
        'timestamp' => gmdate('c')
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

} catch (Exception $e) {
    PerformanceMonitor::mark('decisions_error');

    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => gmdate('c')
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
