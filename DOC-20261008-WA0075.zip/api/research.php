<?php
/**
 * WanSQ v3.2.5 — Deep Research API
 * Handles comprehensive research requests with multi-source synthesis
 *
 * Endpoints:
 * - POST /api/research.php?action=start   → Start research request
 * - POST /api/research.php?action=status  → Get research status
 * - POST /api/research.php?action=result  → Get research results
 */

declare(strict_types=1);

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => $e['message']]);
    }
});

require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/error_handler_v325.php';
require __DIR__ . '/../includes/model_router.php';

session_boot();
$user = require_api_login();
$uid = (int)$user['id'];
$pdo = db();

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $action = (string)($_GET['action'] ?? '');

    switch ($action) {
        case 'start': {
            // Start a new research request
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            $query = trim((string)($in['query'] ?? ''));
            $convId = (int)($in['conversation_id'] ?? 0);

            if (!$query) {
                json_out(['ok' => false, 'error' => 'Missing query'], 400);
            }

            if ($convId && !$pdo->prepare('SELECT id FROM conversations WHERE id = ? AND user_id = ?')->execute([$convId, $uid])->fetch()) {
                json_out(['ok' => false, 'error' => 'Conversation not found'], 404);
            }

            // Route query to research model
            $router = new ModelRouter();
            $routing = $router->route($query, ['type' => 'research'], 'research');

            $startTime = microtime(true);

            // Create research request record
            $pdo->prepare('
                INSERT INTO research_requests
                (user_id, conversation_id, research_query, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, NOW(), NOW())
            ')->execute([
                $uid,
                $convId ?: null,
                mb_substr($query, 0, 5000)
            ]);

            $requestId = $pdo->lastInsertId();

            // Log routing decision
            $pdo->prepare('
                INSERT INTO model_usage_log
                (user_id, model_selected, query_type, routing_source, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ')->execute([
                $uid,
                $routing['model'],
                'research',
                'model_router'
            ]);

            json_out([
                'ok' => true,
                'request_id' => (int)$requestId,
                'model' => $routing['model'],
                'label' => $routing['label'],
                'status' => 'pending',
                'started_at' => date('c')
            ]);
        }

        case 'status': {
            // Get research request status
            $requestId = (int)($_GET['request_id'] ?? 0);

            if (!$requestId) {
                json_out(['ok' => false, 'error' => 'Missing request_id'], 400);
            }

            $stmt = $pdo->prepare('
                SELECT id, status, sources_count, completion_time_ms
                FROM research_requests
                WHERE id = ? AND user_id = ?
            ');
            $stmt->execute([$requestId, $uid]);
            $row = $stmt->fetch();

            if (!$row) {
                json_out(['ok' => false, 'error' => 'Request not found'], 404);
            }

            json_out([
                'ok' => true,
                'request_id' => (int)$row['id'],
                'status' => $row['status'],
                'sources_count' => (int)$row['sources_count'],
                'completion_time_ms' => $row['completion_time_ms'] ? (int)$row['completion_time_ms'] : null
            ]);
        }

        case 'result': {
            // Get research results
            $requestId = (int)($_GET['request_id'] ?? 0);

            if (!$requestId) {
                json_out(['ok' => false, 'error' => 'Missing request_id'], 400);
            }

            $stmt = $pdo->prepare('
                SELECT id, status, search_results, analysis_result, completion_time_ms
                FROM research_requests
                WHERE id = ? AND user_id = ?
            ');
            $stmt->execute([$requestId, $uid]);
            $row = $stmt->fetch();

            if (!$row) {
                json_out(['ok' => false, 'error' => 'Request not found'], 404);
            }

            if ($row['status'] !== 'completed') {
                json_out(['ok' => true, 'status' => $row['status'], 'result' => null]);
            }

            // Get sources
            $srcStmt = $pdo->prepare('
                SELECT source_url, source_title, source_domain, relevance_score, quote_used
                FROM research_sources
                WHERE research_request_id = ?
                ORDER BY relevance_score DESC
            ');
            $srcStmt->execute([$requestId]);
            $sources = $srcStmt->fetchAll(PDO::FETCH_ASSOC);

            json_out([
                'ok' => true,
                'request_id' => (int)$row['id'],
                'status' => $row['status'],
                'result' => json_decode($row['analysis_result'] ?? 'null', true),
                'search_results' => json_decode($row['search_results'] ?? '[]', true),
                'sources' => $sources,
                'completion_time_ms' => $row['completion_time_ms'] ? (int)$row['completion_time_ms'] : null
            ]);
        }

        case 'analytics': {
            // Get research analytics for user
            $limit = (int)($_GET['limit'] ?? 10);
            $limit = min($limit, 100);

            $stmt = $pdo->prepare('
                SELECT
                    id, research_query, status, sources_count,
                    completion_time_ms, user_satisfaction, created_at
                FROM research_requests
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            ');
            $stmt->execute([$uid, $limit]);
            $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Calculate stats
            $stats = [
                'total_requests' => 0,
                'completed' => 0,
                'pending' => 0,
                'failed' => 0,
                'avg_time_ms' => 0,
                'avg_sources' => 0,
                'avg_satisfaction' => 0
            ];

            $totalTime = 0;
            $totalSources = 0;
            $totalSatisfaction = 0;
            $satisfactionCount = 0;

            foreach ($requests as $r) {
                $stats['total_requests']++;
                $stats[$r['status']]++;

                if ($r['completion_time_ms']) {
                    $totalTime += $r['completion_time_ms'];
                }
                $totalSources += (int)$r['sources_count'];

                if ($r['user_satisfaction']) {
                    $totalSatisfaction += (int)$r['user_satisfaction'];
                    $satisfactionCount++;
                }
            }

            if ($stats['total_requests'] > 0) {
                $stats['avg_time_ms'] = (int)($totalTime / $stats['total_requests']);
                $stats['avg_sources'] = $totalSources / $stats['total_requests'];
            }
            if ($satisfactionCount > 0) {
                $stats['avg_satisfaction'] = $totalSatisfaction / $satisfactionCount;
            }

            json_out([
                'ok' => true,
                'stats' => $stats,
                'recent' => array_slice($requests, 0, 5)
            ]);
        }

        default:
            json_out(['ok' => false, 'error' => 'Unknown action'], 400);
    }

} catch (Throwable $e) {
    app_log('research.php error: ' . $e->getMessage());
    json_out(['ok' => false, 'error' => 'Server error'], 500);
}
