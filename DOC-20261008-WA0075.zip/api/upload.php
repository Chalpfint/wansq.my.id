<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/docs.php';
require __DIR__ . '/../includes/processors.php';
require __DIR__ . '/../includes/groq.php';
require __DIR__ . '/../includes/imgproc.php';
require __DIR__ . '/../includes/chat_lib.php';
if (!function_exists('docx_extract_text')) { function docx_extract_text(string $p, int $m = 20000): string { return ''; } }

session_boot();
$user = require_api_login();
$uid = (int)$user['id']; $pdo = db();
csrf_check();

function att_payload(array $a, array $extra = array()): array {
    return array_merge(array('id' => (int)$a['id'], 'kind' => $a['kind'], 'name' => $a['original_name'], 'size' => (int)$a['size'], 'mime' => $a['mime'],
        'url' => $a['kind'] === 'image' ? base_url('/api/file.php?id=' . (int)$a['id']) : '', 'status' => $a['status'], 'pages' => (int)$a['pages'], 'width' => (int)($a['width'] ?? 0), 'height' => (int)($a['height'] ?? 0), 'processing_stage' => (string)($a['processing_stage'] ?? 'ready')), $extra);
}
function upload_err_msg(int $code): string {
    if ($code === UPLOAD_ERR_INI_SIZE || $code === UPLOAD_ERR_FORM_SIZE) return 'File melebihi batas ukuran unggah server (upload_max_filesize ' . ini_get('upload_max_filesize') . ').';
    if ($code === UPLOAD_ERR_NO_FILE) return 'File tidak diterima server';
    return 'Unggah gagal (kode ' . $code . ')';
}

try {
    @set_time_limit(180);
    if (empty($_FILES['file'])) json_out(['ok' => false, 'error' => 'File tidak diterima server (periksa post_max_size PHP)'], 422);
    $f = $_FILES['file'];
    if ($f['error'] !== UPLOAD_ERR_OK) json_out(['ok' => false, 'error' => upload_err_msg((int)$f['error'])], 413);
    $kind = (string)($_POST['kind'] ?? 'attach');
    $projectId = (int)($_POST['project_id'] ?? 0);
    if ($projectId && !chat_own_project($projectId, $uid)) json_out(['ok' => false, 'error' => 'Project tidak ditemukan'], 404);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $sha256 = hash_file('sha256', $f['tmp_name']) ?: null;
    $name = mb_substr(preg_replace('/[\x00-\x1F\/\\\\]/u', '', basename((string)$f['name'])), 0, 120);
    if ($name === '') $name = 'file';
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $day  = date('Y/m');
    $uniq = bin2hex(random_bytes(10));

    /* ---------- GAMBAR ---------- */
    if (str_starts_with((string)$mime, 'image/')) {
        if ($f['size'] > ORIGINAL_UPLOAD_LIMIT) json_out(['ok' => false, 'error' => 'Gambar terlalu besar (maks ' . (int)(UPLOAD_MAX_BYTES / 1048576) . ' MB)'], 413);
        $allow = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        if (!in_array($mime, $allow, true)) json_out(['ok' => false, 'error' => 'Format gambar tidak didukung (jpeg/png/webp/gif)'], 415);
        $isAvatar = ($kind === 'avatar');

        if ($isAvatar) {
            // Avatar tetap satu-tujuan (bulat, kecil) — tidak perlu arsitektur original+derivative.
            $dir = UPLOAD_DIR . '/' . $day; if (!is_dir($dir)) mkdir($dir, 0775, true);
            if (imgproc_gd_available()) {
                $src = @imagecreatefromstring((string)file_get_contents($f['tmp_name']));
                if (!$src) json_out(['ok' => false, 'error' => 'Gambar rusak'], 415);
                $w = imagesx($src); $h = imagesy($src); $max = 1568;
                if (max($w, $h) > $max) {
                    $s = $max / max($w, $h);
                    $dst = imagecreatetruecolor((int)($w * $s), (int)($h * $s));
                    imagealphablending($dst, true); imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
                    imagecopyresampled($dst, $src, 0, 0, 0, 0, imagesx($dst), imagesy($dst), $w, $h);
                    imagedestroy($src); $src = $dst;
                } else { $flat = imagecreatetruecolor($w, $h); imagefill($flat, 0, 0, imagecolorallocate($flat, 255, 255, 255)); imagecopy($flat, $src, 0, 0, 0, 0, $w, $h); imagedestroy($src); $src = $flat; }
                $rel = 'uploads/' . $day . '/' . $uniq . '.jpg';
                imagejpeg($src, $dir . '/' . $uniq . '.jpg', 85); imagedestroy($src);
            } else {
                $extMap = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
                $rel = 'uploads/' . $day . '/' . $uniq . '.' . $extMap[$mime];
                file_put_contents($dir . '/' . $uniq . '.' . $extMap[$mime], (string)file_get_contents($f['tmp_name']));
            }
            $pdo->prepare('UPDATE users SET avatar_local=? WHERE id=?')->execute([$rel, $uid]);
            json_out(['ok' => true, 'avatar' => base_url('/' . $rel)]);
        }

        /* Dedup: gambar identik (sha256) yang masih valid → jangan proses ulang, cukup buat baris baru yang mereferensikan hasil yang sama. */
        if ($sha256) {
            $st = $pdo->prepare("SELECT * FROM attachments WHERE user_id=? AND sha256=? AND kind='image' AND removed=0 ORDER BY id DESC LIMIT 1");
            $st->execute([$uid, $sha256]);
            $dup = $st->fetch();
            if ($dup && is_file(stored_to_fs((string)$dup['stored_path']))) {
                $pdo->prepare("INSERT INTO attachments (user_id,project_id,kind,original_name,stored_path,derivative_path,derivative_reason,mime,original_mime,size,status,sha256,width,height,processing_stage,vision_summary) VALUES (?,?,'image',?,?,?,?,?,?,?,'ready',?,?,?,'ready',?)")
                    ->execute([$uid, $projectId ?: null, $name, $dup['stored_path'], $dup['derivative_path'], $dup['derivative_reason'], $dup['mime'], $dup['original_mime'], $f['size'], $sha256, $dup['width'], $dup['height'], $dup['vision_summary']]);
                $id = (int)$pdo->lastInsertId();
                app_log("upload dedup image id=$id reuse_of={$dup['id']} sha256=" . substr($sha256, 0, 12));
                $st = $pdo->prepare('SELECT * FROM attachments WHERE id=?'); $st->execute([$id]);
                json_out(['ok' => true, 'attachment' => att_payload($st->fetch(), ['dedup' => true])]);
            }
        }

        // ORIGINAL: simpan byte-identik apa adanya (termasuk gambar sangat kecil/format asli) — tidak pernah ditimpa.
        $extMap = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
        $origDir = STORAGE_DIR . '/att/' . $day; if (!is_dir($origDir)) mkdir($origDir, 0775, true);
        $origRel = 'att/' . $day . '/' . $uniq . '.' . $extMap[$mime];
        $origAbs = $origDir . '/' . $uniq . '.' . $extMap[$mime];
        if (!move_uploaded_file($f['tmp_name'], $origAbs)) json_out(['ok' => false, 'error' => 'Gagal menyimpan gambar ke storage'], 500);
        list($ow, $oh) = imgproc_dimensions($origAbs);

        // DERIVATIVE: normalisasi khusus untuk inferensi model (orientasi, transparansi, ukuran) — tidak menimpa original.
        $derivRel = null; $derivReason = null;
        if (imgproc_gd_available()) {
            $d = imgproc_make_derivative($origAbs, $mime);
            if ($d['ok']) {
                $derivRel = imgproc_store_derivative($d['bytes'], $day);
                $derivReason = $derivRel ? $d['reason'] : null;
                if (!$ow) { $ow = $d['width']; $oh = $d['height']; }   // getimagesize gagal pada original → pakai dimensi hasil decode GD
            } else {
                app_log('imgproc derivative gagal untuk ' . basename($origAbs) . ' (mime=' . $mime . '); vision akan memakai original apa adanya.');
            }
        }

        $pdo->prepare("INSERT INTO attachments (user_id,project_id,kind,original_name,stored_path,derivative_path,derivative_reason,mime,original_mime,size,status,sha256,width,height,processing_stage) VALUES (?,?,'image',?,?,?,?,?,?,?,'ready',?,?,?,'ready')")
            ->execute([$uid, $projectId ?: null, $name, $origRel, $derivRel, $derivReason, $mime, $mime, $f['size'], $sha256, $ow ?: null, $oh ?: null]);
        $id = (int)$pdo->lastInsertId();
        app_log(sprintf('upload image id=%d dims=%dx%d derivative=%s reason=%s', $id, $ow, $oh, $derivRel ? 'yes' : 'no(original)', (string)$derivReason));
        $st = $pdo->prepare('SELECT * FROM attachments WHERE id=?'); $st->execute([$id]);
        json_out(['ok' => true, 'attachment' => att_payload($st->fetch())]);
    }

    /* ---------- DOKUMEN ---------- */
    if ($f['size'] > DOC_MAX_BYTES) json_out(['ok' => false, 'error' => 'Dokumen terlalu besar (maks ' . (int)(DOC_MAX_BYTES / 1048576) . ' MB)'], 413);
    $isPdf = ($ext === 'pdf' || $mime === 'application/pdf');
    $isDocx = ($ext === 'docx');
    $isText = in_array($ext, proc_supported_exts(), true) && !$isPdf && !$isDocx || (!$isPdf && !$isDocx && str_starts_with((string)$mime, 'text/'));
    if (!$isPdf && !$isDocx && !$isText) json_out(['ok' => false, 'error' => 'Tipe file tidak didukung. Gunakan gambar, PDF, DOCX, XLSX, PPTX, CSV/TSV, JSON, XML, YAML, HTML, teks, atau file kode.'], 415);

    /* Dedup: dokumen identik (sha256) yang sudah ready/needs_ocr → jangan ekstrak/chunk ulang, salin chunks-nya saja. */
    if ($sha256) {
        $st = $pdo->prepare("SELECT * FROM attachments WHERE user_id=? AND sha256=? AND kind='doc' AND removed=0 AND status IN ('ready','needs_ocr') ORDER BY id DESC LIMIT 1");
        $st->execute([$uid, $sha256]);
        $dup = $st->fetch();
        if ($dup && is_file(stored_to_fs((string)$dup['stored_path']))) {
            $pdo->prepare("INSERT INTO attachments (user_id,project_id,kind,original_name,stored_path,mime,original_mime,size,extracted_text,status,pages,ocr_pages,sha256,processing_stage) VALUES (?,?,'doc',?,?,?,?,?,?,?,?,?,?,?)")
                ->execute([$uid, $projectId ?: null, $name, $dup['stored_path'], $dup['mime'], $dup['original_mime'], $f['size'], $dup['extracted_text'], $dup['status'], $dup['pages'], $dup['ocr_pages'], $sha256, $dup['status']]);
            $id = (int)$pdo->lastInsertId();
            $pdo->prepare("INSERT INTO doc_chunks (attachment_id,user_id,page_start,page_end,idx,source,content) SELECT ?,user_id,page_start,page_end,idx,source,content FROM doc_chunks WHERE attachment_id=?")
                ->execute([$id, (int)$dup['id']]);
            $st2 = $pdo->prepare('SELECT COUNT(*) c FROM doc_chunks WHERE attachment_id=?'); $st2->execute([$id]); $nChunks = (int)$st2->fetch()['c'];
            if ($dup['status'] === 'ready' && $nChunks > 0) $pdo->prepare("UPDATE attachments SET ai_status='ready', ai_ready_at=NOW(), preview_mode='text' WHERE id=?")->execute([$id]);
            app_log("upload dedup doc id=$id reuse_of={$dup['id']} chunks=$nChunks sha256=" . substr($sha256, 0, 12));
            $st = $pdo->prepare('SELECT * FROM attachments WHERE id=?'); $st->execute([$id]);
            json_out(['ok' => true, 'attachment' => att_payload($st->fetch(), ['chunks' => $nChunks, 'dedup' => true])]);
        }
    }

    $sdir = STORAGE_DIR . '/att/' . $day; if (!is_dir($sdir)) mkdir($sdir, 0775, true);
    // Release the DB socket before PDF/DOCX/text extraction, which can take a long time.
    db_close();

    $storedExt = $isPdf ? 'pdf' : ($isDocx ? 'docx' : ($ext !== '' ? preg_replace('/[^a-z0-9]/', '', $ext) : 'txt'));
    $rel = 'att/' . $day . '/' . $uniq . '.' . $storedExt;
    $abs = STORAGE_DIR . '/' . $rel;
    if (!move_uploaded_file($f['tmp_name'], $abs)) json_out(['ok' => false, 'error' => 'Gagal menyimpan file di storage (izin folder storage/att)'], 500);

    $t0 = microtime(true); $pages = array(); $status = 'ready'; $pageCount = 0; $missing = array(); $storeMime = $mime; $engine = 'text'; $profile = '';
    if ($isPdf) {
        $storeMime = 'application/pdf';
        $r = doc_pdf_pages($abs); $engine = $r['engine']; $pageCount = (int)$r['count'];
        foreach ($r['pages'] as $n => $t) if (doc_text_ok((string)$t)) $pages[(int)$n] = $t;
        $missing = $r['missing'];
        $ratio = $pageCount > 0 ? count($missing) / $pageCount : 1;
        if (!$pages || $ratio >= 0.4) $status = 'needs_ocr';
    } elseif ($isDocx) {
        $txt = docx_extract_text($abs, 400000);
        if (trim($txt) === '') { @unlink($abs); json_out(['ok' => false, 'error' => 'DOCX tidak dapat dibaca (kosong atau ekstensi Zip PHP tidak aktif)'], 415); }
        $pages = doc_text_sections($txt); $pageCount = count($pages);
    } else {
        $pr = proc_extract($abs, $ext !== '' ? $ext : 'txt'); $engine = $pr['engine'] ?? 'text';
        if (empty($pr['ok'])) { @unlink($abs); json_out(['ok' => false, 'error' => (string)($pr['error'] ?? 'File tidak dapat dibaca')], 422); }
        $pages = $pr['pages']; $profile = (string)($pr['profile'] ?? '');
        if ($profile !== '') { $shift = array(1 => $profile); foreach ($pages as $n => $t) $shift[count($shift) + 1] = $t; $pages = $shift; }
        $pageCount = count($pages);
    }
    $preview = mb_substr(implode("\n\n", array_slice($pages, 0, 3)), 0, 4000);
    // Reopen after extraction; the old PDO socket was intentionally released above.
    $pdo = db();
    $pdo->prepare("INSERT INTO attachments (user_id,project_id,kind,original_name,stored_path,mime,original_mime,size,extracted_text,status,pages,sha256,processing_stage,processor) VALUES (?,?,'doc',?,?,?,?,?,?,?,?,?,?,?)")
        ->execute([$uid, $projectId ?: null, $name, $rel, $storeMime, $mime, $f['size'], $preview, $status, $pageCount, $sha256, $status, mb_substr((string)$engine, 0, 30)]);
    $id = (int)$pdo->lastInsertId();
    $nChunks = doc_store_chunks($id, $uid, doc_make_chunks($pages), 'text');
    if ($status === 'ready' && $nChunks > 0) $pdo->prepare("UPDATE attachments SET ai_status='ready', ai_ready_at=NOW(), preview_mode='text' WHERE id=?")->execute([$id]);
    $ms = ms_since($t0);
    require_once __DIR__ . '/../includes/workspace.php'; ws_job_record($uid, 'doc_extract', $name, true, null, null, 'attachment:' . $id);
    app_log(sprintf('upload doc id=%d type=%s engine=%s pages=%d text_pages=%d missing=%d chunks=%d status=%s extract=%dms', $id, $ext, $engine, $pageCount, count($pages), count($missing), $nChunks, $status, $ms));
    $st = $pdo->prepare('SELECT * FROM attachments WHERE id=?'); $st->execute([$id]);
    $extra = ['chunks' => $nChunks, 'extract_ms' => $ms, 'text_pages' => count($pages)];
    if ($status === 'needs_ocr') $extra += ['ocr_pages' => array_slice($missing ?: range(1, max(1, $pageCount)), 0, OCR_MAX_PAGES), 'ocr_total' => count($missing ?: range(1, max(1, $pageCount)))];
    json_out(['ok' => true, 'attachment' => att_payload($st->fetch(), $extra)]);
} catch (Throwable $ex) {
    app_log('upload fatal: ' . $ex->getMessage() . ' @' . basename($ex->getFile()) . ':' . $ex->getLine());
    $kind = db_is_connection_error($ex) ? 'database_connection_lost' : 'upload_processing';
    json_out(['ok' => false, 'error' => $kind === 'database_connection_lost' ? 'Koneksi database terputus saat menyimpan file. Silakan coba unggah kembali.' : 'File gagal diproses. Periksa format/ukuran file lalu coba lagi.', 'kind' => $kind], 500);
}
