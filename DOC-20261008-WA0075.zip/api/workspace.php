<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/workspace.php';
session_boot();
$user=require_api_login(); $uid=(int)$user['id']; $act=(string)($_GET['action']??'');
if(in_array($act,['artifact_create','artifact_save','artifact_restore','job_clear'],true))csrf_check();
try{
 switch($act){
  case 'jobs': json_out(['ok'=>true,'jobs'=>ws_jobs($uid,(int)($_GET['limit']??30))]);
  case 'artifacts': json_out(['ok'=>true,'artifacts'=>ws_artifacts($uid,((int)($_GET['project']??0))?:null,(int)($_GET['limit']??50))]);
  case 'artifact': $a=ws_artifact_get($uid,(int)($_GET['id']??0)); if(!$a)json_out(['ok'=>false,'error'=>'Artifact tidak ditemukan'],404); json_out(['ok'=>true,'artifact'=>$a,'versions'=>ws_artifact_versions($uid,(int)$a['id'])]);
  case 'artifact_create': $a=ws_artifact_create($uid,json_in()); json_out(['ok'=>true,'artifact'=>$a],201);
  case 'artifact_save': $a=ws_artifact_save($uid,json_in()); json_out(['ok'=>true,'artifact'=>$a]);
  case 'artifact_restore': $in=json_in();$a=ws_artifact_restore($uid,(int)($in['id']??0),(int)($in['version']??0));json_out(['ok'=>true,'artifact'=>$a]);
  case 'artifact_delete': csrf_check(); $in=json_in(); $id=(int)($in['id']??$_POST['id']??0); if($id<=0)json_out(['ok'=>false,'error'=>'ID artifact tidak valid'],422);
    $pdo=db(); $st=$pdo->prepare('SELECT id FROM artifacts WHERE id=? AND user_id=?'); $st->execute([$id,$uid]); if(!$st->fetch())json_out(['ok'=>false,'error'=>'Artifact tidak ditemukan'],404);
    $pdo->beginTransaction(); try{ $pdo->prepare('DELETE FROM artifact_versions WHERE artifact_id=? AND user_id=?')->execute([$id,$uid]); $pdo->prepare('DELETE FROM artifacts WHERE id=? AND user_id=?')->execute([$id,$uid]); $pdo->commit(); }catch(Throwable $e){ $pdo->rollBack(); throw $e; }
    json_out(['ok'=>true]);
  case 'job_clear': json_out(['ok'=>true,'removed'=>ws_jobs_clear($uid)]);
  case 'provenance': json_out(['ok'=>true,'items'=>ws_provenance_for_message($uid,(int)($_GET['message_id']??0))]);
  default: json_out(['ok'=>false,'error'=>'Aksi tidak dikenal'],404);
 }
}catch(InvalidArgumentException $e){json_out(['ok'=>false,'error'=>$e->getMessage()],422);}
catch(Throwable $e){app_log('workspace '.$act.': '.$e->getMessage());$kind=db_is_connection_error($e)?'database_connection_lost':'workspace_failure';json_out(['ok'=>false,'error'=>$kind==='database_connection_lost'?'Koneksi database terputus. Coba lagi.':'Workspace gagal diproses.','kind'=>$kind],500);}
