<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/groq.php';
require __DIR__ . '/../includes/memory.php';
require __DIR__ . '/../includes/chat_lib.php';
session_boot();
$user = require_api_login();
$uid = (int)$user['id']; $pdo = db();
$act = (string)($_GET['action'] ?? '');
csrf_check();
$in = ($_SERVER['REQUEST_METHOD'] === 'POST') ? json_in() : [];

function clean_icon(string $s): string { $s = trim($s); return $s === '' ? '📁' : mb_substr($s, 0, 4); }

try {
switch ($act) {
case 'list': {
    $st = $pdo->prepare("SELECT p.id,p.name,p.icon,p.updated_at,
        (SELECT COUNT(*) FROM conversations c WHERE c.project_id=p.id AND c.deleted_at IS NULL) AS convs,
        (SELECT COUNT(*) FROM project_memories m WHERE m.project_id=p.id) AS mems,
        (SELECT COUNT(*) FROM attachments a WHERE a.project_id=p.id AND a.removed=0) AS files
        FROM projects p WHERE p.user_id=? ORDER BY p.updated_at DESC");
    $st->execute([$uid]);
    json_out(['ok' => true, 'projects' => $st->fetchAll()]);
}
case 'get': {
    $p = chat_own_project((int)($_GET['id'] ?? 0), $uid);
    if (!$p) json_out(['ok' => false, 'error' => 'Project tidak ditemukan'], 404);
    $st = $pdo->prepare('SELECT id,content,created_at FROM project_memories WHERE project_id=? ORDER BY id DESC'); $st->execute([$p['id']]); $mem = $st->fetchAll();
    $st = $pdo->prepare('SELECT id,kind,original_name,mime,size,status,pages FROM attachments WHERE project_id=? AND user_id=? AND removed=0 ORDER BY id DESC'); $st->execute([$p['id'], $uid]); $files = $st->fetchAll();
    json_out(['ok' => true, 'project' => ['id' => (int)$p['id'], 'name' => $p['name'], 'icon' => $p['icon'], 'instructions' => (string)$p['instructions']], 'memories' => $mem, 'files' => $files]);
}
case 'create': {
    $name = mb_substr(trim((string)($in['name'] ?? '')), 0, 80);
    if ($name === '') json_out(['ok' => false, 'error' => 'Nama project wajib diisi'], 422);
    $st = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE user_id=?'); $st->execute([$uid]);
    if ((int)$st->fetchColumn() >= 100) json_out(['ok' => false, 'error' => 'Batas 100 project tercapai'], 422);
    $pdo->prepare('INSERT INTO projects (user_id,name,icon,instructions) VALUES (?,?,?,?)')
        ->execute([$uid, $name, clean_icon((string)($in['icon'] ?? '')), mb_substr((string)($in['instructions'] ?? ''), 0, 4000) ?: null]);
    json_out(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
}
case 'update': {
    $p = chat_own_project((int)($in['id'] ?? 0), $uid);
    if (!$p) json_out(['ok' => false, 'error' => 'Project tidak ditemukan'], 404);
    $name = mb_substr(trim((string)($in['name'] ?? $p['name'])), 0, 80); if ($name === '') json_out(['ok' => false, 'error' => 'Nama project wajib diisi'], 422);
    $pdo->prepare('UPDATE projects SET name=?, icon=?, instructions=? WHERE id=? AND user_id=?')
        ->execute([$name, clean_icon((string)($in['icon'] ?? $p['icon'])), array_key_exists('instructions', $in) ? (mb_substr((string)$in['instructions'], 0, 4000) ?: null) : $p['instructions'], $p['id'], $uid]);
    json_out(['ok' => true]);
}
case 'delete': {   // conversation di dalamnya TIDAK dihapus (project_id → NULL); memory & file project ikut dihapus
    $p = chat_own_project((int)($in['id'] ?? 0), $uid);
    if (!$p) json_out(['ok' => false, 'error' => 'Project tidak ditemukan'], 404);
    $st = $pdo->prepare('SELECT stored_path FROM attachments WHERE project_id=? AND user_id=? AND conversation_id IS NULL'); $st->execute([$p['id'], $uid]);
    foreach ($st->fetchAll() as $a) { $f = stored_to_fs((string)$a['stored_path']); if (is_file($f)) @unlink($f); }
    $pdo->prepare('DELETE FROM attachments WHERE project_id=? AND user_id=? AND conversation_id IS NULL')->execute([$p['id'], $uid]);
    $pdo->prepare('UPDATE attachments SET project_id=NULL WHERE project_id=? AND user_id=?')->execute([$p['id'], $uid]);
    $pdo->prepare('DELETE FROM projects WHERE id=? AND user_id=?')->execute([$p['id'], $uid]);
    json_out(['ok' => true]);
}
case 'mem_add': {
    $p = chat_own_project((int)($in['project_id'] ?? 0), $uid); $c = trim((string)($in['content'] ?? ''));
    if (!$p || $c === '') json_out(['ok' => false, 'error' => 'Data tidak valid'], 422);
    save_project_memory($uid, (int)$p['id'], $c);
    json_out(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
}
case 'mem_delete': {
    $pdo->prepare('DELETE FROM project_memories WHERE id=? AND user_id=?')->execute([(int)($in['id'] ?? 0), $uid]);
    json_out(['ok' => true]);
}
default: json_out(['ok' => false, 'error' => 'Aksi tidak dikenal'], 404);
}
} catch (Throwable $e) { app_log('projects ' . $act . ': ' . $e->getMessage()); $kind = db_is_connection_error($e) ? 'database_connection_lost' : 'internal'; json_out(['ok' => false, 'error' => $kind === 'database_connection_lost' ? 'Koneksi database terputus. Coba lagi.' : 'Terjadi gangguan saat memproses project.', 'kind' => $kind], 500); }
