<?php
declare(strict_types=1);
/* Handler fatal dipasang SEBELUM require apa pun */
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
        $msg = 'Kesalahan fatal PHP: ' . $e['message'] . ' (' . basename($e['file']) . ':' . $e['line'] . ')';
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => $msg));
        } else {
            echo "\ndata: " . json_encode(array('t' => 'error', 'error' => $msg)) . "\n\n";
        }
    }
});
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/models.php';
require __DIR__ . '/../includes/memory.php';
require __DIR__ . '/../includes/tools_lib.php';
require __DIR__ . '/../includes/tokens.php';
require __DIR__ . '/../includes/docs.php';
require __DIR__ . '/../includes/vision.php';
require_once __DIR__ . '/../includes/summary.php';
require __DIR__ . '/../includes/ctx.php';
require __DIR__ . '/../includes/caps.php';
require __DIR__ . '/../includes/orchestrator.php';
require __DIR__ . '/../includes/chat_lib.php';
require __DIR__ . '/../includes/workspace.php';
session_boot();
$user = require_api_login();
$uid  = (int)$user['id'];
$pdo  = db();
/* PERBAIKAN (DB): perpanjang timeout sesi MySQL agar socket tidak dibunuh server
   saat PHP sibuk menunggu panggilan jaringan yang lama (vision/imagegen/search). */
try { $pdo->exec('SET SESSION wait_timeout = 3600, SESSION interactive_timeout = 3600'); } catch (Throwable $e) {}
$act  = (string)($_GET['action'] ?? '');
csrf_check();
function sse(array $d): string { return 'data: ' . json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n\n"; }
function own_conv(int $id, int $uid): ?array { return chat_own_conv($id, $uid); }
function meta_public($meta): array {
    $m = is_array($meta) ? $meta : array();
    unset($m['model'], $m['usage'], $m['timings'], $m['attempts']);
    return $m;
}
try {
switch ($act) {
    case 'ping':
        json_out(array('ok' => true, 'pong' => true));
    case 'list': {
        $lim = 50; $off = max(0, (int)($_GET['offset'] ?? 0));
        $filter = ($_GET['filter'] ?? 'active') === 'archived' ? 1 : 0;
        $proj = (int)($_GET['project'] ?? 0);
        if (mt_rand(1, 25) === 1) chat_trash_sweep($uid);
        $w = 'user_id = ? AND deleted_at IS NULL AND archived = ?'; $a = array($uid, $filter);
        if ($proj > 0) { $w .= ' AND project_id = ?'; $a[] = $proj; }
        $st = $pdo->prepare("SELECT COUNT(*) AS c FROM conversations WHERE $w"); $st->execute($a);
        $tot = (int)$st->fetch()['c'];
        $st = $pdo->prepare("SELECT id,title,model,engine,archived,pinned,project_id,updated_at FROM conversations WHERE $w ORDER BY pinned DESC, updated_at DESC LIMIT $lim OFFSET $off");
        $st->execute($a);
        json_out(array('ok' => true, 'chats' => $st->fetchAll(), 'total' => $tot));
    }
    case 'create': {
        $in = json_in(); $pid = (int)($in['project_id'] ?? 0);
        if ($pid && !chat_own_project($pid, $uid)) json_out(array('ok' => false, 'error' => 'Project tidak ditemukan'), 404);
        $pdo->prepare('INSERT INTO conversations (user_id,title,project_id) VALUES (?,?,?)')->execute(array($uid, 'Percakapan Baru', $pid ?: null));
        json_out(array('ok' => true, 'id' => (int)$pdo->lastInsertId()));
    }
    case 'rename': {
        $in = json_in(); $id = (int)($in['id'] ?? 0); $t = trim((string)($in['title'] ?? ''));
        if (!own_conv($id, $uid) || $t === '') json_out(array('ok' => false, 'error' => 'Judul tidak valid'), 422);
        $pdo->prepare('UPDATE conversations SET title=? WHERE id=?')->execute(array(mb_substr($t, 0, 120), $id));
        json_out(array('ok' => true));
    }
    case 'pin_conversation': {
        $in = json_in(); $id = (int)($in['id'] ?? 0); $pin = !empty($in['pinned']);
        $c = own_conv($id, $uid);
        if (!$c) json_out(array('ok' => false, 'error' => 'Percakapan tidak ditemukan'), 404);
        $pdo->prepare('UPDATE conversations SET pinned=? WHERE id=? AND user_id=?')->execute(array((int)$pin, $id, $uid));
        json_out(array('ok' => true, 'pinned' => $pin));
    }
    case 'archive': {
        $in = json_in(); $id = (int)($in['id'] ?? 0); $c = own_conv($id, $uid);
        if (!$c) json_out(array('ok' => false), 404);
        $pdo->prepare('UPDATE conversations SET archived=? WHERE id=?')->execute(array((int)!$c['archived'], $id));
        json_out(array('ok' => true));
    }
    case 'move': {
        $in = json_in(); $id = (int)($in['id'] ?? 0); $pid = (int)($in['project_id'] ?? 0);
        if (!own_conv($id, $uid)) json_out(array('ok' => false), 404);
        if ($pid && !chat_own_project($pid, $uid)) json_out(array('ok' => false, 'error' => 'Project tidak ditemukan'), 404);
        $pdo->prepare('UPDATE conversations SET project_id=? WHERE id=? AND user_id=?')->execute(array($pid ?: null, $id, $uid));
        json_out(array('ok' => true));
    }
    case 'delete': {            // soft delete → Trash (dapat dipulihkan)
        $in = json_in(); $id = (int)($in['id'] ?? 0);
        if (!own_conv($id, $uid)) json_out(array('ok' => false), 404);
        $pdo->prepare('UPDATE conversations SET deleted_at=NOW() WHERE id=? AND user_id=?')->execute(array($id, $uid));
        $pdo->prepare('UPDATE shares SET enabled=0, revoked_at=NOW() WHERE conversation_id=?')->execute(array($id));
        json_out(array('ok' => true));
    }
    case 'restore': {
        $in = json_in(); $id = (int)($in['id'] ?? 0);
        if (!chat_own_conv($id, $uid, true)) json_out(array('ok' => false), 404);
        $pdo->prepare('UPDATE conversations SET deleted_at=NULL WHERE id=? AND user_id=?')->execute(array($id, $uid));
        json_out(array('ok' => true));
    }
    case 'purge': {             // hapus permanen (hanya yang sudah di Trash)
        $in = json_in(); $id = (int)($in['id'] ?? 0); $c = chat_own_conv($id, $uid, true);
        if (!$c || $c['deleted_at'] === null) json_out(array('ok' => false, 'error' => 'Hanya percakapan di Trash yang dapat dihapus permanen'), 422);
        chat_purge_files($id, $uid);
        $pdo->prepare('DELETE FROM conversations WHERE id=? AND user_id=?')->execute(array($id, $uid));
        json_out(array('ok' => true));
    }
    case 'trash_list': {
        $st = $pdo->prepare('SELECT id,title,deleted_at FROM conversations WHERE user_id=? AND deleted_at IS NOT NULL ORDER BY deleted_at DESC LIMIT 100'); $st->execute(array($uid));
        json_out(array('ok' => true, 'chats' => $st->fetchAll(), 'days' => TRASH_DAYS));
    }
    case 'truncate': {          // edit pesan: pesan ini & sesudahnya DIARSIPKAN (non-destruktif), bukan dihapus
        $in = json_in(); $mid = (int)($in['id'] ?? 0);
        $st = $pdo->prepare('SELECT conversation_id FROM messages WHERE id=?'); $st->execute(array($mid));
        $row = $st->fetch();
        if (!$row || !own_conv((int)$row['conversation_id'], $uid)) json_out(array('ok' => false), 404);
        $pdo->prepare('INSERT INTO conversation_branches (conversation_id,user_id,parent_message_id,label,created_at) VALUES (?,?,?,?,NOW())')
            ->execute(array((int)$row['conversation_id'],$uid,$mid,'Edit / regenerate'));
        $pdo->prepare('UPDATE messages SET active=0, superseded_at=NOW() WHERE conversation_id=? AND id>=? AND active=1')->execute(array($row['conversation_id'], $mid));
        json_out(array('ok' => true));
    }
    case 'feedback': {
        $in = json_in(); $mid = (int)($in['message_id'] ?? 0); $rating = (int)($in['rating'] ?? 0);
        if ($rating !== 1 && $rating !== -1) json_out(array('ok' => false), 422);
        $pdo->prepare('INSERT INTO feedback (user_id,message_id,rating,comment) VALUES (?,?,?,?)')
            ->execute(array($uid, $mid ?: null, $rating, mb_substr(trim((string)($in['comment'] ?? '')), 0, 500)));
        json_out(array('ok' => true));
    }
    case 'pin': {
        $in = json_in(); $mid = (int)($in['id'] ?? 0); $pin = !empty($in['pinned']);
        $st = $pdo->prepare('SELECT m.id,m.conversation_id FROM messages m WHERE m.id=? AND m.active=1'); $st->execute(array($mid)); $row = $st->fetch();
        if (!$row || !own_conv((int)$row['conversation_id'], $uid)) json_out(array('ok' => false), 404);
        $label = mb_substr(trim((string)($in['label'] ?? '')), 0, 120);
        $pdo->prepare('UPDATE messages SET pinned=?, pinned_at=?, pin_label=? WHERE id=?')->execute(array((int)$pin, $pin ? date('Y-m-d H:i:s') : null, $pin && $label !== '' ? $label : null, $mid));
        json_out(array('ok' => true, 'pinned' => $pin));
    }
    case 'pins': {
        $id = (int)($_GET['id'] ?? 0);
        if (!own_conv($id, $uid)) json_out(array('ok' => false), 404);
        $st = $pdo->prepare('SELECT id,role,content,pin_label,pinned_at FROM messages WHERE conversation_id=? AND active=1 AND pinned=1 ORDER BY pinned_at DESC');
        $st->execute(array($id)); $rows = $st->fetchAll();
        foreach ($rows as &$r) $r['content'] = clip((string)$r['content'], 400); unset($r);
        json_out(array('ok' => true, 'pins' => $rows));
    }
    case 'delete_message': {    // soft: user → giliran itu (user + balasan); assistant → hanya balasannya
        $in = json_in(); $mid = (int)($in['id'] ?? 0);
        $st = $pdo->prepare('SELECT id,role,conversation_id FROM messages WHERE id=? AND active=1'); $st->execute(array($mid)); $row = $st->fetch();
        if (!$row || !own_conv((int)$row['conversation_id'], $uid)) json_out(array('ok' => false), 404);
        $ids = array($mid);
        if ($row['role'] === 'user') {
            $st = $pdo->prepare('SELECT id,role FROM messages WHERE conversation_id=? AND id>? AND active=1 ORDER BY id ASC'); $st->execute(array($row['conversation_id'], $mid));
            foreach ($st->fetchAll() as $n) { if ($n['role'] === 'user') break; $ids[] = (int)$n['id']; }
        }
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $pdo->prepare("UPDATE messages SET active=0, superseded_at=NOW(), pinned=0 WHERE id IN ($ph)")->execute($ids);
        json_out(array('ok' => true, 'ids' => $ids));
    }
    case 'messages': {
        $id = (int)($_GET['id'] ?? 0); $c = own_conv($id, $uid);
        if (!$c) json_out(array('ok' => false), 404);
        $st = $pdo->prepare('SELECT id,role,content,meta,pinned,pin_label,created_at FROM messages WHERE conversation_id=? AND active=1 ORDER BY id ASC');
        $st->execute(array($id)); $msgs = $st->fetchAll();
        $ids = array();
        foreach ($msgs as &$m) { $m['meta'] = meta_public(json_decode((string)$m['meta'], true)); $m['pinned'] = (int)$m['pinned']; $ids[] = $m['id']; } unset($m);
        $atts = array();
        if ($ids) {
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $st = $pdo->prepare("SELECT id,message_id,kind,original_name,mime,size,status,pages,generated FROM attachments WHERE message_id IN ($ph) AND removed=0");
            $st->execute($ids);
            foreach ($st->fetchAll() as $a) $atts[(int)$a['message_id']][] = $a;
        }
        $proj = $c['project_id'] ? chat_own_project((int)$c['project_id'], $uid) : null;
        $sh = $pdo->prepare('SELECT token,enabled,max_message_id FROM shares WHERE conversation_id=?'); $sh->execute(array($id)); $share = $sh->fetch();
        json_out(array('ok' => true, 'messages' => $msgs, 'attachments' => $atts,
            'conv' => array('id' => $id, 'title' => $c['title'], 'project' => $proj ? array('id' => (int)$proj['id'], 'name' => $proj['name'], 'icon' => $proj['icon']) : null,
                'share' => $share ? array('enabled' => (int)$share['enabled'], 'url' => $share['enabled'] ? share_url($share['token']) : null) : null)));
    }
    case 'send': {
        @ini_set('memory_limit', '512M');
        /* PERBAIKAN (ANTI-CUT): bebaskan batas eksekusi SEJAK AWAL, bukan setelah header.
           Jawaban panjang (matematika/LaTeX) bisa memakan beberapa menit. */
        @ini_set('max_execution_time', '0');
        set_time_limit(0);
        if (!rate_limit_ok($uid)) json_out(array('ok' => false, 'error' => 'Terlalu banyak permintaan. Tunggu sebentar.'), 429);
        $in     = json_in();
        $text   = trim((string)($in['text'] ?? ''));
        $convId = (int)($in['conversation_id'] ?? 0);
        $regen  = !empty($in['regenerate']);
        $style  = in_array(($in['style'] ?? ''), array('shorter', 'detailed', 'formal'), true) ? (string)$in['style'] : '';
        $tf     = (isset($in['transform']) && is_array($in['transform'])) ? $in['transform'] : null;
        $cid    = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($in['cid'] ?? '')), 0, 40);
        $requestId = substr(preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($in['request_id'] ?? $cid)), 0, 40);
        if ($requestId === '') $requestId = bin2hex(random_bytes(10));
        $forceImg = (($in['mode'] ?? '') === 'image');
        $projIn = (int)($in['project_id'] ?? 0);
        $attIds = array();
        foreach ((array)($in['attachments'] ?? array()) as $aid) $attIds[] = (int)$aid;
        $attIds = array_slice(array_unique($attIds), 0, MAX_ATTACH);
        $T0 = microtime(true); $tm = array('prep_ms' => 0, 'perceive_ms' => null, 'retrieval_ms' => null, 'tool_ms' => null, 'first_token_ms' => null, 'total_ms' => 0);
        $langPref = in_array($user['reply_lang'] ?? 'auto', array('auto', 'id', 'en'), true) ? (string)$user['reply_lang'] : 'auto';
        if ($convId && !own_conv($convId, $uid)) json_out(array('ok' => false, 'error' => 'Percakapan tidak ditemukan'), 404);
        if (!$convId) {
            if ($projIn && !chat_own_project($projIn, $uid)) $projIn = 0;
            $pdo->prepare('INSERT INTO conversations (user_id,title,project_id) VALUES (?,?,?)')->execute(array($uid, 'Percakapan Baru', $projIn ?: null));
            $convId = (int)$pdo->lastInsertId();
        }
        $conv = own_conv($convId, $uid);
        $project = $conv['project_id'] ? chat_own_project((int)$conv['project_id'], $uid) : null;
        // teks untuk model (transformasi memakai isi jawaban target)
        $modelText = $text; $displayText = $text;
        if ($tf && !$regen) {
            $kind = (string)($tf['kind'] ?? ''); $tmid = (int)($tf['mid'] ?? 0);
            $st = $pdo->prepare("SELECT content FROM messages WHERE id=? AND conversation_id=? AND role='assistant' AND active=1"); $st->execute(array($tmid, $convId)); $target = $st->fetchColumn();
            $ins = chat_transform_instruction($kind, (($tf['to'] ?? '') === 'en') ? 'en' : 'id');
            if ($target === false || $ins === '') json_out(array('ok' => false, 'error' => 'Jawaban target untuk transformasi tidak ditemukan'), 422);
            $modelText = $ins . "\n--- JAWABAN SUMBER ---\n" . $target;
            if ($displayText === '') $displayText = '↻ ' . $kind;
        }
        if (!$regen && $displayText === '' && !$attIds) json_out(array('ok' => false, 'error' => 'Pesan kosong'), 422);
        $userMsgId = 0; $curAtts = array();
        if ($regen) {
            $st = $pdo->prepare("SELECT id,content FROM messages WHERE conversation_id=? AND role='user' AND active=1 ORDER BY id DESC LIMIT 1");
            $st->execute(array($convId)); $last = $st->fetch();
            if (!$last) json_out(array('ok' => false, 'error' => 'Tidak ada pesan untuk diregenerasi'), 422);
            $userMsgId = (int)$last['id']; $text = $modelText = $last['content'];
            $pdo->prepare("UPDATE messages SET active=0, superseded_at=NOW() WHERE conversation_id=? AND role='assistant' AND active=1 AND id>?")->execute(array($convId, $userMsgId));
            $st = $pdo->prepare('SELECT * FROM attachments WHERE message_id=? AND removed=0'); $st->execute(array($userMsgId)); $curAtts = $st->fetchAll();
            if (mb_strpos($text, '↻ ') === 0 && !$tf) { /* regenerasi dari transformasi: gunakan teks tampilan apa adanya */ }
        } else {
            $existing = null;
            if ($cid !== '') { $st = $pdo->prepare('SELECT id FROM messages WHERE conversation_id=? AND cid=?'); $st->execute(array($convId, $cid)); $existing = $st->fetchColumn(); }
            if ($existing) {   // percobaan ulang (retry) → pakai pesan yang sama, tidak menduplikasi
                $userMsgId = (int)$existing;
                $pdo->prepare("UPDATE messages SET active=0, superseded_at=NOW() WHERE conversation_id=? AND role='assistant' AND active=1 AND id>?")->execute(array($convId, $userMsgId));
            } else {
                $pdo->prepare('INSERT INTO messages (conversation_id,role,content,cid) VALUES (?,?,?,?)')->execute(array($convId, 'user', $displayText, $cid !== '' ? $cid : null));
                $userMsgId = (int)$pdo->lastInsertId();
            }
            if ($attIds) {
                $ph = implode(',', array_fill(0, count($attIds), '?'));
                $pdo->prepare("UPDATE attachments SET message_id=?, conversation_id=? WHERE id IN ($ph) AND user_id=? AND message_id IS NULL AND removed=0")
                    ->execute(array_merge(array($userMsgId, $convId), $attIds, array($uid)));
            }
            $st = $pdo->prepare('SELECT * FROM attachments WHERE message_id=? AND user_id=? AND removed=0'); $st->execute(array($userMsgId, $uid)); $curAtts = $st->fetchAll();
            // Never let a send race ahead of attachment ownership/linking. If an upload ID
            // was stale, removed, or already claimed, fail explicitly instead of answering
            // as though the file had been received.
            if ($attIds && count($curAtts) < count($attIds)) {
                $failAtt = 'Satu atau lebih lampiran belum siap digunakan. Tunggu sampai status lampiran selesai lalu kirim lagi.';
                json_out(array('ok' => false, 'error' => $failAtt, 'kind' => 'attachment_not_ready'), 409);
            }
        }
        $images = array(); $newDocs = array();
        foreach ($curAtts as $a) { if ($a['kind'] === 'image' && !$a['generated']) $images[] = $a; elseif ($a['kind'] === 'doc') $newDocs[] = $a; }
        $images = array_slice($images, 0, MAX_IMAGES);
        /* ====== Mulai stream SEGERA agar status tahap nyata tampil (bukan palsu) ====== */
        session_write_close();
        while (ob_get_level()) ob_end_flush();
        @ini_set('zlib.output_compression', '0');
        header('Content-Type: text/event-stream; charset=utf-8');
        header('Cache-Control: no-cache'); header('X-Accel-Buffering: no');
        header('Connection: keep-alive'); // PERBAIKAN (ANTI-CUT): cegah proxy/server menutup koneksi idle
        set_time_limit(0); ob_implicit_flush(true);
        $emit = function (array $d) use ($requestId) { $d['rid'] = $requestId; echo sse($d); flush(); };
        $status = function (string $key, array $vars = array()) use ($emit) { $emit(array('t' => 'status', 'key' => $key) + $vars); };
        /* Heartbeat timer untuk mencegah timeout selama context assembly */
        $lastPing = microtime(true);
        $ping = function () use (&$lastPing, $emit) {
            $now = microtime(true);
            /* PERBAIKAN (ANTI-CUT): 10s → 5s; keep-alive lebih agresif agar LiteSpeed/proxy
               tidak menganggap stream idle lalu memutusnya. */
            if (($now - $lastPing) >= 5.0) {
                $emit(array('t' => 'ping'));
                if (ob_get_level() > 0) @ob_flush();
                @flush();
                $lastPing = $now;
            }
        };
        $buf = ''; $saved = false; $completed = false; $engKey = 'auto';
        register_shutdown_function(function () use (&$buf, &$saved, $convId) {
            if (!$saved && $buf !== '') {
                try { db()->prepare("INSERT INTO messages (conversation_id,role,content,meta) VALUES (?,?,?,?)")
                    ->execute(array($convId, 'assistant', $buf, json_encode(array('partial' => true)))); } catch (Throwable $e) {}
            }
        });
        $fail = function (string $msg, string $kind = 'error') use ($emit, &$saved, $T0, $convId) {
            app_log('send fail conv=' . $convId . ' kind=' . $kind . ' msg=' . mb_substr($msg, 0, 200));
            $emit(array('t' => 'error', 'error' => $msg, 'kind' => $kind)); exit;
        };
        /* PERBAIKAN (DB): socket MariaDB dapat diputus server (wait_timeout) saat PHP sibuk
           menunggu panggilan jaringan lama (vision/imagegen/search/retrieval). Helper ini
           memastikan koneksi hidup kembali sebelum DB dipakai lagi. */
        $dbEnsure = function () use (&$pdo) {
            try { $pdo->query('SELECT 1'); }
            catch (Throwable $e) { db_close(); $pdo = db(); }
        };
        $caps = caps_build();
        $engWant = (string)($in['engine'] ?? 'auto');
        // User modes are Auto/Thinking/Fast. Legacy keys remain accepted but map to the new semantic mode.
        if ($engWant === 'reason') $engWant = 'thinking';
        if ($engWant === 'vision') $engWant = 'auto';
        $emit(array('t' => 'start', 'conv' => $convId, 'mid' => $userMsgId, 'project' => $project ? (int)$project['id'] : null));
        /* Status: mulai assembly konteks (mencegah timeout diam-diam) */
        $status('assembly_start', array('msg' => 'Menyiapkan konteks dan analisis...'));
        $ping();
        $prevImgs = chat_prev_images($convId, $uid, 3);
        $prevImgs = array_values(array_filter($prevImgs, function ($p) use ($images) { foreach ($images as $i) if ((int)$i['id'] === (int)$p['id']) return false; return true; }));
        $tools = array();
        /* ---------------- Rute: pembuatan / pengeditan gambar ---------------- */
        $imgIntent = $forceImg ? ($images || $prevImgs ? 'edit' : 'generate') : imggen_intent($modelText, count($images) > 0, count($prevImgs) > 0);
        $imgPrompt = $modelText;
        if ($imgIntent === '' && !$images && !$tf && $caps['image_gen']) {
            $dbEnsure();   // PERBAIKAN (DB): socket bisa sudah putus ('gone away') setelah tahap upload/vision
            $rs = $pdo->prepare('SELECT role,content FROM messages WHERE conversation_id=? AND id<? AND active=1 ORDER BY id DESC LIMIT 8'); $rs->execute(array($convId, $userMsgId));
            $fu = imggen_followup($modelText, array_reverse($rs->fetchAll()));
            if ($fu !== null) { $imgIntent = 'generate'; $imgPrompt = $fu; }
        }
        if ($forceImg && !$images && $prevImgs && !preg_match('/\b(hilangkan|hapus|ganti|ubah|edit|jadikan|tambahkan|remove|change|replace)\b/iu', $modelText)) $imgIntent = 'generate';
        if ($imgIntent !== '' && !$tf) {
            $needEdit = $imgIntent === 'edit';
            if (($needEdit && !$caps['image_edit']) || (!$needEdit && !$caps['image_gen'])) {
                if ($forceImg) $fail($needEdit ? 'Pengeditan gambar belum dikonfigurasi pada WanSQ ini.' : 'Pembuatan gambar belum dikonfigurasi pada WanSQ ini.', 'capability');
                $imgIntent = '';   // niat terdeteksi otomatis tapi kapabilitas OFF → biarkan model menjawab jujur
            }
        }
        if ($imgIntent !== '' && !$tf) {
            $src = null;
            if ($imgIntent === 'edit') { $ref = $images ? $images[0] : $prevImgs[count($prevImgs) - 1]; $src = stored_to_fs((string)$ref['stored_path']); if (!is_file($src)) $fail('Gambar sumber tidak ditemukan di storage.', 'file'); }
            $status($imgIntent === 'edit' ? 'editing_image' : 'creating_image');
            $r = imggen_run($imgPrompt, $src);
            if (!$r['ok'] || $r['bytes'] === '') { app_log('imggen fail: ' . $r['err']); require_once __DIR__ . '/../includes/workspace.php'; ws_job_record($uid, 'image_generate', mb_substr($imgPrompt, 0, 100), false, (string)$r['err'], $convId); $fail('Gagal ' . ($imgIntent === 'edit' ? 'mengedit' : 'membuat') . ' gambar: ' . $r['err'], 'imagegen'); }
            $dbEnsure(); // PERBAIKAN (DB): socket mungkin mati selama imggen_run berjalan
            $cap = ($user['ui_lang'] ?? 'id') === 'en' ? 'Here is the result.' : 'Berikut hasilnya.';
            $pdo->prepare('INSERT INTO messages (conversation_id,role,content,meta) VALUES (?,?,?,?)')->execute(array($convId, 'assistant', $cap, json_encode(array('image' => true, 'kind' => $imgIntent, 'route' => 'image'))));
            $mid = (int)$pdo->lastInsertId();
            $aid = imggen_store($uid, $convId, $mid, $r['bytes'], $r['mime'], 'wansq-' . date('Ymd-His') . '.png');
            $saved = true;
            require_once __DIR__ . '/../includes/workspace.php'; ws_job_record($uid, 'image_' . ($imgIntent === 'edit' ? 'edit' : 'generate'), mb_substr($imgPrompt, 0, 100), true, null, $convId, 'attachment:' . $aid);
            $pdo->prepare('UPDATE conversations SET archived=0, updated_at=NOW(), intent=?, tools_used=? WHERE id=?')->execute(array('image', 'image', $convId));
            $emit(array('t' => 'image', 'id' => $aid, 'mid' => $mid, 'caption' => $cap));
            $tm['total_ms'] = ms_since($T0); $tm['image_ms'] = $r['ms'];
            app_log(sprintf('send rid=%s cid=%s conv=%d route=image intent=%s total=%dms', $requestId, $cid, $convId, $imgIntent, $tm['total_ms']));
            if ($conv['title'] === 'Percakapan Baru') { $title = chat_title($modelText, $cap); $pdo->prepare('UPDATE conversations SET title=?, topic=? WHERE id=?')->execute(array($title, $title, $convId)); $emit(array('t' => 'title', 'title' => $title)); }
            $emit(array('t' => 'done', 'conv' => $convId, 'mid' => $mid, 'route' => 'image', 'timings' => $tm)); exit;
        }
        /* ---------------- Rute teks / vision / dokumen ---------------- */
        $fastPath = orch_fast_path($modelText, $engWant) && !$images && !$newDocs && !$tf;
        $eng = resolve_engine($fastPath ? 'fast' : $engWant, count($images) > 0);
        $route = 'chat'; $attachCtx = ''; $sources = array(); $docNames = array(); $visionUsed = false; $docsUsed = false;
        $lastUserContent = $modelText;
        $tm['prep_ms'] = ms_since($T0);
        // 1) Gambar (lapisan persepsi → reasoning)
        $hasDocScope = (bool)doc_scope($uid, $convId, $project ? (int)$project['id'] : null);
        $ping();
        if ($images) {
            if (!$caps['vision']) $fail('Analisis gambar sedang tidak tersedia (model vision tidak terkonfigurasi).', 'capability');
            $visionUsed = true; $tools[] = 'vision';
            if (vision_is_direct($modelText) && !$hasDocScope) {
                $route = 'vision_direct'; $eng = resolve_engine($engWant === 'fast' ? 'fast' : 'thinking', true);
                list($parts, $missing) = vision_image_parts($images);
                if (!$parts) $fail('Gambar terlampir tidak dapat dibaca dari storage. Unggah ulang gambarnya.', 'file');
                $lastUserContent = array_merge(array(array('type' => 'text', 'text' => $modelText !== '' ? $modelText : vision_direct_prompt())), $parts);
                $attachCtx = vision_direct_prompt();
            } else {
                $route = 'vision_reason';
                $cached = array(); foreach ($images as $im) if (!empty($im['vision_summary'])) $cached[md5($im['vision_summary'])] = $im['vision_summary'];
                if ($regen && count($cached) > 0 && count($cached) === 1) { $perc = array('ok' => true, 'text' => reset($cached), 'ms' => 0); }
                else { $status('analyzing_image'); $perc = vision_perceive($images, $modelText); $tm['perceive_ms'] = $perc['ms']; $ping(); }
                if (!$perc['ok']) $fail('Gambar tidak dapat dianalisis saat ini (' . mb_substr((string)$perc['err'], 0, 140) . '). Coba lagi sebentar lagi.', 'vision');
                $attachCtx = "Hasil lapisan persepsi (Vision/OCR) untuk " . count($images) . " gambar terlampir — gunakan sebagai fakta visual, lakukan penalaran di atasnya, dan katakan bila ada bagian yang tidak terbaca:\n" . $perc['text'];
                $dbEnsure(); // PERBAIKAN (DB): WAJIB — vision_perceive bisa >60 detik, socket lama mungkin sudah mati
                foreach ($images as $im) { $pdo->prepare('UPDATE attachments SET vision_summary=? WHERE id=? AND (vision_summary IS NULL OR vision_summary = "")')->execute(array(mb_substr($perc['text'], 0, 60000), $im['id'])); $ping(); }
                $eng = resolve_engine($fastPath ? 'fast' : $engWant, false);
            }
        } elseif ($prevImgs && !$newDocs) {
            // Lanjutan tanpa gambar baru: pakai ringkasan persepsi tersimpan; re-inspeksi bila pertanyaan menyangkut detail visual
            $sum = array(); foreach ($prevImgs as $p) if (!empty($p['vision_summary'])) $sum[md5($p['vision_summary'])] = $p['vision_summary'];
            $reLook = $caps['vision'] && !$tf && preg_match('/\b(gambar|foto|grafik|diagram|chart|screenshot|tangkapan|image|picture|figure|tabel di gambar|sumbu|legenda|warna|tulisan|teks di|bagian (atas|bawah|kiri|kanan))\b/iu', $modelText);
            if ($reLook) {
                $visionUsed = true; $tools[] = 'vision'; $status('analyzing_image');
                $perc = vision_perceive(array_slice($prevImgs, -2), $modelText); $tm['perceive_ms'] = $perc['ms']; $ping();
                if ($perc['ok']) { $attachCtx = "Hasil inspeksi ulang gambar sebelumnya (lapisan persepsi), terfokus pada pertanyaan terbaru:\n" . $perc['text']; $route = 'vision_reason'; }
            }
            if ($attachCtx === '' && $sum) $attachCtx = "Ringkasan persepsi gambar dari lampiran sebelumnya pada percakapan ini:\n" . implode("\n---\n", array_slice($sum, -2));
        }
        $ping();
        // Model representatif untuk estimasi anggaran token, dihitung SETELAH engine final
        // ditentukan (blok vision di atas dapat mengganti $eng) — dipakai untuk retrieval dokumen
        // dan context builder final di bawah, supaya anggaran benar-benar mencerminkan model yang
        // akan menerima request (lihat includes/tokens.php).
        $budgetModel = llm_chain($eng['role'])[0] ?? null;
        $docBudget = tok_budget_for_model($budgetModel, $eng['max_tokens']);
        $docCharBudget = min(DOC_CONTEXT_CHARS, max(4000, (int)(($docBudget['input_budget'] * 0.35) / 0.30)));
        // 2) Dokumen (RAG persisten: lampiran percakapan + pengetahuan project)
        if ($hasDocScope && !$tf) {
            $dbEnsure(); // PERBAIKAN (DB): pastikan socket hidup setelah tahap vision/re-inspeksi sebelumnya
            $cue = $newDocs || (bool)preg_match('/\b(dokumen|file|berkas|pdf|docx|halaman|hal\.|bab|tabel|bagian|paragraf|lampiran|tadi|tersebut|slide|isi|document|page|table|section|attachment|uploaded|ringkas|rangkum|summari[sz]e)\b/iu', $modelText);
            // Pertanyaan lanjutan pendek ("itu", "jelaskan lebih detail") setelah jawaban berbasis dokumen tetap memakai dokumen.
            $carry = false;
            if (!$cue && mb_strlen($modelText) <= 60) {
                $lm = $pdo->prepare("SELECT meta FROM messages WHERE conversation_id=? AND role='assistant' AND active=1 AND id<? ORDER BY id DESC LIMIT 1"); $lm->execute(array($convId, $userMsgId));
                $lmeta = json_decode((string)$lm->fetchColumn(), true);
                if (is_array($lmeta)) foreach ((array)($lmeta['sources'] ?? array()) as $sr) if (($sr['type'] ?? '') === 'doc') { $cue = true; $carry = true; break; }
            }
            // Current/new attachments have priority. Historical documents require explicit intent or a
            // strong relevance match; there is no random/head fallback.
            if ($cue) {
                $status('retrieving_documents', array('msg' => 'Mencari bagian relevan dari dokumen...'));
                $ping();
            }
            $rd = $cue ? doc_retrieve($uid, $convId, $project ? (int)$project['id'] : null, $modelText, $docCharBudget, (bool)$newDocs, array_map(function ($d) { return (int)$d['id']; }, $newDocs))
                : array('ctx'=>'','sources'=>array(),'docs'=>array(),'mode'=>'none','chunks'=>0,'ms'=>0,'relevance'=>0);
            $ping();
            if ($carry && $rd['ctx'] === '') {
                $status('retrieving_documents_summary');
                $rd = doc_retrieve($uid, $convId, $project ? (int)$project['id'] : null, $modelText . ' ringkasan isi dokumen', $docCharBudget, true);
                $ping();
            }
            $tm['retrieval_ms'] = $rd['ms'];
            if ($rd['ctx'] !== '' && !empty($rd['sources'])) {
                $status('reading_document');
                $docsUsed = true; $tools[] = 'docs'; $sources = array_merge($sources, $rd['sources']);
                foreach ($rd['docs'] as $d) $docNames[] = $d['original_name'];
                $newNote = $newDocs ? "LAMPIRAN BARU pada pesan ini: " . implode(', ', array_map(function ($d) { return $d['original_name']; }, $newDocs)) . ". Pertanyaan pengguna merujuk pada lampiran baru ini; abaikan topik/gambar dari percakapan sebelumnya kecuali pengguna menyebutkannya.\n" : '';
                $attachCtx .= ($attachCtx !== '' ? "\n" : '') . $newNote . "Konteks dokumen (potongan relevan; sumber halaman ditandai). Jawab berdasarkan isi ini dan sebutkan sumbernya:\n" . $rd['ctx'];
                if ($rd['mode'] === 'overview') $attachCtx .= "\n(Catatan: potongan diambil merata dari dokumen untuk gambaran umum; sampaikan bila bagian tertentu tidak tercakup.)";
            }
        }
        $ping();
        // 3) Tools: kalkulator & web
        $toolCtx = ''; $tt = microtime(true); $calcOnly = false;
        $calcs = $tf ? array() : math_candidates($modelText);
        if ($calcs) { $status('calculating'); $tools[] = 'calc';
            foreach ($calcs as $cc) { $toolCtx .= 'calculator: ' . $cc[0] . ' = ' . fmt_num($cc[1]) . "\n"; $ping(); }
            $calcOnly = preg_match('/^[\s\d\.\+\-\*\/\^\%\(\)a-z,×÷√=?]+$/i', $modelText) === 1; }
        if (!$tf && detect_search_need($modelText, !empty($in['web']))) {
            $status('searching_web'); $tools[] = 'web';
            $web = web_search($modelText); $ws = array();
            foreach ($web as $r) { $ws[] = array('type' => 'web', 'title' => $r['title'], 'url' => $r['url']); $toolCtx .= "web: {$r['title']} — {$r['snippet']} ({$r['url']})\n"; $ping(); }
            if ($ws) { $sources = array_merge($sources, $ws); $toolCtx .= "Instruksi: gunakan hasil web bila relevan, kutip sumber dengan URL, tandai informasi yang belum terverifikasi.\n"; }
            else $toolCtx .= "web: pencarian tidak mengembalikan hasil; jangan mengarang sumber.\n";
        }
        if ($toolCtx !== '') $tm['tool_ms'] = ms_since($tt);
        $ping();
        // 4) Konteks (prioritisasi) & generasi
        $status('building_context', array('msg' => 'Menyusun konteks percakapan...'));
        $ping();
        $dbEnsure(); // PERBAIKAN (DB): setelah web_search/tool lambat, socket bisa saja sudah diputus
        $st = $pdo->prepare('SELECT id,role,content FROM messages WHERE conversation_id=? AND active=1 ORDER BY id ASC'); $st->execute(array($convId));
        $hist = $st->fetchAll();
        $ping();
        $cx = ctx_build(array('uid' => $uid, 'conv' => $conv, 'project' => $project, 'text' => $modelText, 'rel_text' => $tf ? '' : ($text !== '' ? $text : $modelText),
            'hist' => $hist, 'exclude_id' => $userMsgId, 'attach_ctx' => $attachCtx, 'tool_ctx' => $toolCtx,
            'style' => $regen ? chat_style_instruction($style) : '', 'lang_pref' => $langPref, 'caps' => $caps, 'attachment_focus' => !empty($curAtts) && mb_strlen($modelText) <= 80,
            'budget_model' => $budgetModel, 'want_output' => $eng['max_tokens']));
        $ping();
        $msgs = $cx['messages'];
        $msgs[] = array('role' => 'user', 'content' => $lastUserContent);
        if (count($sources)) $emit(array('t' => 'sources', 'items' => $sources));
        /* CRITICAL: Emit assembly_complete BEFORE provider call to signal context assembly done */
        $status('assembly_complete', array('msg' => 'Menghubungi LLM...', 'stats' => $cx['stats']));
        $ping();
        $status('generating');
        // Do not keep an idle MariaDB socket open while the provider may stream for minutes.
        // Reconnect is performed on demand during the persistence phase below.
        db_close();
        $partialFlag = false; $finish = null;
        $gr = array();
        $responseMB = 0;  // Track response size to prevent buffer overflow
        /* =====================================================================
         * PERBAIKAN (PROVIDER): RETRY OTOMATIS DENGAN BACKOFF
         * Bila provider mengembalikan error transient (rate limit / timeout /
         * network) DAN belum ada token yang terkirim ke klien (buf kosong),
         * sistem otomatis mencoba ulang hingga SEND_AUTO_RETRY kali dengan
         * jeda meningkat (2s, 4s). Pengguna tidak perlu klik "Coba lagi".
         * Retry TIDAK dilakukan jika sudah ada teks tampil (mencegah duplikat).
         * ===================================================================== */
        $maxAttempts = defined('SEND_AUTO_RETRY') ? (int)SEND_AUTO_RETRY : 2;
        if ($maxAttempts < 1) $maxAttempts = 1;
        if ($maxAttempts > 3) $maxAttempts = 3;
        $retryableKinds = array('rate', 'timeout', 'network');
        $attempt = 0; $streamErr = null;
        do {
            $attempt++;
            if ($attempt > 1) {
                $wait = 2 * ($attempt - 1);
                $status('retrying', array('msg' => 'Provider sibuk / rate-limit tercapai. Mencoba ulang otomatis (' . $attempt . '/' . $maxAttempts . ') dalam ' . $wait . ' detik...'));
                sleep($wait);
                $buf = '';
                $responseMB = 0;
                $gr = array();
                $ping();
            }
            $streamErr = null;
            try {
                /* PERBAIKAN (AKURASI): temperature 0.6 → 0.5 agar jawaban Qwen lebih
                   faktual & konsisten, tanpa mengorbankan gaya penjelasan. */
                llm_stream($eng['role'], array('messages' => $msgs, 'max_completion_tokens' => $eng['max_tokens'], 'temperature' => 0.5, 'top_p' => 0.95),
                    function (string $d) use (&$buf, $emit, &$responseMB) {
                        $buf .= $d;
                        $responseMB += strlen($d);
                        // Jika response sudah > 2MB, ini tanda-tanda buffer overflow risk di proxy
                        if ($responseMB > 2097152) { app_log('send response very large: ' . $responseMB . ' bytes'); }
                        $emit(array('t' => 'delta', 'c' => $d));
                    },
                    function (string $k) use ($status) { if ($k === 'fallback') $status('fallback'); }, $gr);
            } catch (Throwable $e) {
                /* PERBAIKAN (ANTI-CUT): jika stream provider melempar exception DI TENGAH
                   generasi (curl drop, HTTP/2 reset), jangan biarkan proses mati mentah.
                   Tandai sebagai stream cut; bagian yang sudah terkirim tetap disimpan. */
                $streamErr = $e;
                if (empty($gr['kind'])) $gr['kind'] = 'network';
                $gr['err'] = trim((string)($gr['err'] ?? '') . ' | stream exception: ' . $e->getMessage());
                app_log('send stream exception conv=' . $convId . ' attempt=' . $attempt . ' buf=' . strlen($buf) . ' err=' . mb_substr($e->getMessage(), 0, 180));
            }
        } while ($attempt < $maxAttempts && trim($buf) === '' && in_array((string)($gr['kind'] ?? ''), $retryableKinds, true));
        $tm['first_token_ms'] = $gr['first_token_ms'] ?? null;
        $tm['total_ms'] = ms_since($T0);
        $tm['connect_ms'] = $gr['connect_ms'] ?? null;
        $tm['attempts'] = $attempt;
        app_log(sprintf('send rid=%s cid=%s conv=%d route=%s engine=%s model=%s tools=%s ctx=%s prep=%dms perceive=%s retr=%s tool=%s first=%s total=%dms attempt=%d cut=%d http=%s err=%s',
            $requestId, $cid, $convId, $route, $eng['key'], (string)$gr['model'], implode('+', $tools), json_encode($cx['stats']), $tm['prep_ms'], var_export($tm['perceive_ms'], true),
            var_export($tm['retrieval_ms'], true), var_export($tm['tool_ms'], true), var_export($tm['first_token_ms'], true), $tm['total_ms'], $attempt, ($streamErr !== null || !empty($gr['partial'])) ? 1 : 0,
            var_export($gr['http'], true), mb_substr((string)$gr['err'], 0, 120)));
        if (trim($buf) === '') {
            $k = (string)$gr['kind'];
            $tm_context = (int)($tm['prep_ms'] + ($tm['perceive_ms'] ?? 0) + ($tm['retrieval_ms'] ?? 0) + ($tm['tool_ms'] ?? 0));
            $hints = array(
                'auth' => 'Kunci API tidak valid/kedaluwarsa.',
                'notfound' => 'Tidak ada model aktif yang memenuhi capability untuk task ini. Periksa api/health.php?full=1 dan daftar model live provider.',
                'rate' => 'Kuota/rate limit provider tercapai setelah ' . $attempt . 'x percobaan otomatis — tunggu ±30 detik lalu coba lagi.',
                'toolarge' => 'Konteks percakapan/dokumen melebihi batas model setelah disusutkan (ctx=' . (int)($cx['stats']['tokens'] ?? 0) . ' token, anggaran=' . (int)($cx['stats']['budget'] ?? 0) . '). Coba mulai percakapan baru atau ajukan pertanyaan lebih spesifik.',
                'budget' => 'Saldo/kredit provider (OpenRouter) tidak cukup untuk panjang jawaban. Sistem sudah mencoba menurunkan batas token otomatis; isi ulang saldo di openrouter.ai/settings/credits lalu coba lagi.',
                'request_too_large' => 'Ukuran request (mis. lampiran gambar) melebihi batas provider. Kurangi jumlah/ukuran gambar pada pesan ini.',
                'badrequest' => 'Provider menolak format request (bad request).',
                'timeout' => ($tm_context > 20000 ? 'Penyiapan konteks terlalu lama (dokumen/gambar/sejarah), provider timeout. Coba pertanyaan lebih spesifik.' : 'Provider tidak merespons dalam batas waktu setelah ' . $attempt . 'x percobaan — provider sedang sibuk. Tunggu sebentar lalu coba lagi.'),
                'network' => 'Koneksi jaringan terputus setelah ' . $attempt . 'x percobaan. Periksa konektivitas internet Anda.',
            );
            $hint = $hints[$k] ?? 'Provider tidak merespons.';
            $rawDetail = trim((string)$gr['err']);
            if ($rawDetail !== '' && !in_array($k, array('toolarge'), true)) $hint .= ' (' . mb_substr($rawDetail, 0, 160) . ')';
            $fail('WanSQ tidak menerima jawaban dari engine. ' . $hint, $k ?: 'provider');
        }
        // Quality control ringan
        if (substr_count($buf, '```') % 2 === 1) $buf .= "\n```";
        /* PERBAIKAN (ANTI-CUT): deteksi stream yang putus DI TENGAH jawaban (sudah ada teks
           tapi provider/hosting memutus koneksi). Alih-alih error mentah, finalisasi sebagai
           jawaban terpotong + tawarkan tombol "Lanjutkan jawaban". */
        $midStreamCut = ($streamErr !== null) || !empty($gr['partial']);
        $meta = array('route' => $route, 'engine' => $eng['key'], 'model' => $gr['model'], 'usage' => $gr['usage'], 'timings' => $tm, 'attempts' => $attempt,
            'context' => array('docs_used' => $docsUsed, 'chunks' => (int)($rd['chunks'] ?? 0), 'relevance' => (float)($rd['relevance'] ?? 0)));
        if ($sources) $meta['sources'] = $sources;
        if (($gr['finish'] ?? null) === 'length' || $midStreamCut) { $meta['truncated'] = true; if ($midStreamCut) $meta['stream_cut'] = true; }
        if (!empty($gr['partial'])) { $meta['partial'] = true; $partialFlag = true; }
        // Persist after generation from a fresh/reconnected PDO socket. All writes here are
        // idempotent: a lost connection can be retried once without duplicating the answer.
        $assistantKey = $cid !== '' ? $cid : (string)$userMsgId;
        $assistantCid = substr('a-' . $assistantKey, 0, 40);
        $jsonMeta = json_encode($meta, JSON_UNESCAPED_UNICODE);
        $mid = db_retry(function(PDO $db) use ($convId, $assistantCid, $buf, $jsonMeta) {
            $st = $db->prepare("SELECT id FROM messages WHERE conversation_id=? AND cid=? AND role='assistant' LIMIT 1");
            $st->execute(array($convId, $assistantCid));
            $id = (int)($st->fetchColumn() ?: 0);
            if (!$id) {
                $db->prepare('INSERT INTO messages (conversation_id,role,content,meta,cid) VALUES (?,?,?,?,?)')
                    ->execute(array($convId, 'assistant', $buf, $jsonMeta, $assistantCid));
                $id = (int)$db->lastInsertId();
            }
            return $id;
        }, 'assistant_save');
        $saved = true;
        // Persist a compact provenance graph once the assistant message is durable.
        try {
            $ps = db()->prepare('SELECT COUNT(*) FROM provenance WHERE user_id=? AND message_id=?');
            $ps->execute([$uid,$mid]);
            if ((int)$ps->fetchColumn() === 0) {
                foreach ($curAtts as $a) {
                    ws_provenance_add($uid,$convId,$mid,'document',(string)$a['id'],(string)$a['original_name'],
                        !empty($a['pages']) ? 'pages='.(int)$a['pages'] : null,null,
                        ['attachment_id'=>(int)$a['id'],'kind'=>(string)$a['kind']]);
                }
                foreach ($sources as $src) {
                    if (($src['type'] ?? '') === 'web') {
                        ws_provenance_add($uid,$convId,$mid,'web',(string)($src['url'] ?? ''),(string)($src['title'] ?? 'Web source'),
                            null,(string)($src['url'] ?? ''),[]);
                    } elseif (($src['type'] ?? '') === 'document') {
                        ws_provenance_add($uid,$convId,$mid,'document',(string)($src['id'] ?? ''),(string)($src['title'] ?? 'Document'),
                            isset($src['page']) ? 'page='.(int)$src['page'] : null,null,$src);
                    }
                }
            }
        } catch (Throwable $e) { app_log('provenance save skipped rid=' . $requestId . ' err=' . mb_substr($e->getMessage(),0,160)); }
        db_retry(function(PDO $db) use ($gr, $eng, $route, $docsUsed, $tools, $convId) {
            $intent = $route === 'chat' ? ($docsUsed ? 'document' : (in_array('web', $tools, true) ? 'research' : 'chat')) : 'vision';
            $db->prepare('UPDATE conversations SET model=?, engine=?, archived=0, updated_at=NOW(), intent=?, tools_used=? WHERE id=?')
                ->execute(array($gr['model'], $eng['key'], $intent, implode(',', array_unique($tools)) ?: null, $convId));
        }, 'conversation_meta');
        // The answer is now durable. Never turn a successful generation into an error later.
        $completed = true;
        $emit(array('t' => 'done', 'conv' => $convId, 'mid' => $mid, 'route' => $route, 'model' => $gr['model'], 'truncated' => !empty($meta['truncated']), 'partial' => $partialFlag,
            'timings' => $tm, 'ctx' => $cx['stats'], 'engine' => $eng['key']));
        if (!empty($meta['truncated'])) $emit(array('t' => 'followups', 'mid' => $mid, 'items' => array(array('label' => 'Lanjutkan jawaban', 'prompt' => 'Lanjutkan jawaban sebelumnya dari bagian yang terpotong, mulai tepat dari kalimat terakhir.'))));
        // Optional title/follow-up work is best-effort. It cannot invalidate the saved answer.
        try {
            if ($conv['title'] === 'Percakapan Baru') {
                $title = chat_title($modelText, $buf);
                if ($title !== '') {
                    db_retry(function(PDO $db) use ($title, $convId) {
                        $db->prepare('UPDATE conversations SET title=?, topic=? WHERE id=?')->execute(array($title, $title, $convId));
                    }, 'conversation_title');
                    $emit(array('t' => 'title', 'title' => $title));
                }
            }
        } catch (Throwable $e) { app_log('optional title failed rid=' . $requestId . ' err=' . mb_substr($e->getMessage(), 0, 180)); }
        try { conv_summary_update($convId, $uid); } catch (Throwable $e) { app_log('optional summary failed rid=' . $requestId . ' err=' . mb_substr($e->getMessage(), 0, 180)); }
        if (empty($meta['truncated']) && !(function_exists('llm_budget_pressure') && llm_budget_pressure())) {   // hemat kredit: saran lanjutan ditunda saat saldo menipis
            try {
                $fu = chat_followups($text !== '' ? $text : $modelText, $buf, array('calc_only' => $calcOnly, 'fast' => $fastPath, 'partial' => $partialFlag,
                    'docs' => $docNames, 'vision' => $visionUsed, 'web' => in_array('web', $tools, true)));
                if ($fu) {
                    $meta['followups'] = $fu;
                    db_retry(function(PDO $db) use ($meta, $mid) {
                        $db->prepare('UPDATE messages SET meta=? WHERE id=?')->execute(array(json_encode($meta, JSON_UNESCAPED_UNICODE), $mid));
                    }, 'followups_meta');
                    $emit(array('t' => 'followups', 'mid' => $mid, 'items' => $fu));
                }
            } catch (Throwable $e) { app_log('optional followups failed rid=' . $requestId . ' err=' . mb_substr($e->getMessage(), 0, 180)); }
        }
        exit;
    }
    default:
        json_out(array('ok' => false, 'error' => 'Aksi tidak dikenal'), 404);
}
} catch (Throwable $ex) {
    app_log('chat ' . $act . ' fatal: ' . $ex->getMessage() . ' @' . basename($ex->getFile()) . ':' . $ex->getLine());
    if (isset($completed) && $completed) exit;
    $kind = db_is_connection_error($ex) ? 'database_connection_lost' : 'internal';
    $friendly = $kind === 'database_connection_lost'
        ? 'Koneksi database terputus saat menyimpan proses. Coba buka ulang percakapan dan ulangi jika diperlukan.'
        : 'WanSQ mengalami gangguan internal saat memproses permintaan. Coba lagi.';
    if (headers_sent()) { echo sse(array('t' => 'error', 'error' => $friendly, 'kind' => $kind)); flush(); exit; }
    json_out(array('ok' => false, 'error' => $friendly, 'kind' => $kind), 500);
}