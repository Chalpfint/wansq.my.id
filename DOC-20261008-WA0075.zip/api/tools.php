<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/tools_lib.php';
session_boot();
require_api_login();
csrf_check();
$act = (string)($_GET['action'] ?? '');
$in = json_in();

switch ($act) {
case 'calc':
    $v = safe_calc((string)($in['expr'] ?? ''));
    json_out(['ok' => $v !== null, 'result' => $v !== null ? fmt_num($v) : null]);
case 'search':
    json_out(['ok' => true, 'results' => web_search((string)($in['q'] ?? ''))]);
case 'run':
    $lang = (string)($in['lang'] ?? ''); $code = (string)($in['code'] ?? '');
    if (!in_array($lang, ['python', 'javascript', 'php'], true)) json_out(['ok' => false], 422);
    $r = run_code_piston($lang, $code);
    if ($r === null) json_out(['ok' => false, 'error' => 'Eksekusi server belum dikonfigurasi (PISTON_API_URL kosong). JS tetap dapat dijalankan lokal via tombol Run sandbox.'], 501);
    json_out(['ok' => true, 'result' => $r]);
default: json_out(['ok' => false], 404);
}