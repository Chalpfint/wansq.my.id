<?php
/**
 * WanSQ v3.2.5 — Image Processing API
 * Handles image generation, editing, and analysis with multi-model routing
 *
 * Endpoints:
 * - POST /api/image.php?action=analyze   → Analyze uploaded image
 * - POST /api/image.php?action=generate  → Generate image from prompt
 * - POST /api/image.php?action=edit      → Edit existing image
 */

declare(strict_types=1);

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => $e['message']]);
    }
});

require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/error_handler_v325.php';
require __DIR__ . '/../includes/model_router.php';

session_boot();
$user = require_api_login();
$uid = (int)$user['id'];
$pdo = db();

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $action = (string)($_GET['action'] ?? '');

    switch ($action) {
        case 'analyze': {
            // Analyze uploaded image using vision model
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            $imageId = (int)($in['image_id'] ?? 0);
            $prompt = trim((string)($in['prompt'] ?? ''));

            if (!$imageId || !$prompt) {
                json_out(['ok' => false, 'error' => 'Missing image_id or prompt'], 400);
            }

            // Verify image ownership
            $stmt = $pdo->prepare('SELECT id FROM attachments WHERE id = ? AND user_id = ?');
            $stmt->execute([$imageId, $uid]);
            if (!$stmt->fetch()) {
                json_out(['ok' => false, 'error' => 'Image not found'], 404);
            }

            // Route to vision model via model_router
            $router = new ModelRouter();
            $routing = $router->route($prompt, ['images' => 1], 'vision');

            // Log analysis request
            $pdo->prepare('
                INSERT INTO model_usage_log
                (user_id, model_selected, query_type, routing_source, response_time_ms, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ')->execute([
                $uid,
                $routing['model'],
                'image_analysis',
                'model_router',
                0
            ]);

            json_out([
                'ok' => true,
                'model' => $routing['model'],
                'label' => $routing['label'],
                'mode' => 'vision',
                'ready' => true
            ]);
        }

        case 'generate': {
            // Generate image from text prompt
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            $prompt = trim((string)($in['prompt'] ?? ''));
            $style = (string)($in['style'] ?? 'professional');

            if (!$prompt) {
                json_out(['ok' => false, 'error' => 'Missing prompt'], 400);
            }

            // Route to image generation service
            // This would integrate with your existing imagegen module
            $startTime = microtime(true);

            // Log generation attempt
            $pdo->prepare('
                INSERT INTO image_history
                (user_id, image_type, model_used, status, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ')->execute([
                $uid,
                'generation',
                'wansq-image-gen',
                'pending'
            ]);

            $imageId = $pdo->lastInsertId();
            $processingTime = (int)((microtime(true) - $startTime) * 1000);

            // Update status
            $pdo->prepare('
                UPDATE image_history SET status = ?, processing_time_ms = ? WHERE id = ?
            ')->execute(['completed', $processingTime, $imageId]);

            json_out([
                'ok' => true,
                'image_id' => (int)$imageId,
                'status' => 'completed',
                'processing_time_ms' => $processingTime
            ]);
        }

        case 'edit': {
            // Edit existing image
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            $imageId = (int)($in['image_id'] ?? 0);
            $prompt = trim((string)($in['prompt'] ?? ''));

            if (!$imageId || !$prompt) {
                json_out(['ok' => false, 'error' => 'Missing image_id or prompt'], 400);
            }

            // Verify image ownership
            $stmt = $pdo->prepare('SELECT id FROM attachments WHERE id = ? AND user_id = ?');
            $stmt->execute([$imageId, $uid]);
            if (!$stmt->fetch()) {
                json_out(['ok' => false, 'error' => 'Image not found'], 404);
            }

            $startTime = microtime(true);

            // Log edit attempt
            $pdo->prepare('
                INSERT INTO image_history
                (user_id, image_type, model_used, status, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ')->execute([
                $uid,
                'editing',
                'wansq-image-edit',
                'pending'
            ]);

            $editId = $pdo->lastInsertId();
            $processingTime = (int)((microtime(true) - $startTime) * 1000);

            // Update status
            $pdo->prepare('
                UPDATE image_history SET status = ?, processing_time_ms = ? WHERE id = ?
            ')->execute(['completed', $processingTime, $editId]);

            json_out([
                'ok' => true,
                'edit_id' => (int)$editId,
                'status' => 'completed',
                'processing_time_ms' => $processingTime
            ]);
        }

        default:
            json_out(['ok' => false, 'error' => 'Unknown action'], 400);
    }

} catch (Throwable $e) {
    app_log('image.php error: ' . $e->getMessage());
    json_out(['ok' => false, 'error' => 'Server error'], 500);
}
