<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/groq.php';
require __DIR__ . '/../includes/chat_lib.php';
session_boot();
$user = require_api_login();
$uid = (int)$user['id']; $pdo = db();
$act = (string)($_GET['action'] ?? '');
csrf_check();

function own_att(int $id, int $uid): ?array {
    $st = db()->prepare('SELECT * FROM attachments WHERE id=? AND user_id=? AND removed=0'); $st->execute([$id, $uid]);
    $r = $st->fetch(); return $r ?: null;
}
switch ($act) {
case 'preview': {
    $a = own_att((int)($_GET['id'] ?? 0), $uid);
    if (!$a) json_out(['ok' => false, 'error' => 'Lampiran tidak ditemukan'], 404);
    $out = ['ok' => true, 'id' => (int)$a['id'], 'kind' => $a['kind'], 'name' => $a['original_name'], 'size' => (int)$a['size'], 'status' => $a['status'], 'pages' => (int)$a['pages'], 'ocr_pages' => (int)$a['ocr_pages']];
    if ($a['kind'] === 'doc') {
        $st = $pdo->prepare('SELECT COUNT(*) FROM doc_chunks WHERE attachment_id=?'); $st->execute([$a['id']]); $out['chunks'] = (int)$st->fetchColumn();
        $st = $pdo->prepare('SELECT page_start,content FROM doc_chunks WHERE attachment_id=? ORDER BY idx ASC LIMIT 4'); $st->execute([$a['id']]);
        $txt = ''; foreach ($st->fetchAll() as $c) $txt .= '[' . ($a['mime'] === 'application/pdf' ? 'hal. ' : 'bagian ') . $c['page_start'] . "]\n" . $c['content'] . "\n\n";
        $out['preview'] = clip($txt, 3500);
    } else { $out['url'] = base_url('/api/file.php?id=' . (int)$a['id']); $out['summary'] = $a['vision_summary'] ? clip((string)$a['vision_summary'], 2500) : ''; }
    json_out($out);
}
case 'remove': {
    $in = json_in(); $a = own_att((int)($in['id'] ?? 0), $uid);
    if (!$a) json_out(['ok' => false, 'error' => 'Lampiran tidak ditemukan'], 404);
    $pdo->prepare('UPDATE attachments SET removed=1 WHERE id=?')->execute([$a['id']]);
    $pdo->prepare('DELETE FROM doc_chunks WHERE attachment_id=?')->execute([$a['id']]);     // referensi tidak dipakai lagi
    $f = stored_to_fs((string)$a['stored_path']); if (is_file($f)) @unlink($f);
    json_out(['ok' => true]);
}
case 'list': {
    $pid = (int)($_GET['project'] ?? 0);
    if (!$pid || !chat_own_project($pid, $uid)) json_out(['ok' => false, 'error' => 'Project tidak ditemukan'], 404);
    $st = $pdo->prepare('SELECT id,kind,original_name,mime,size,status,pages,created_at FROM attachments WHERE user_id=? AND project_id=? AND removed=0 ORDER BY id DESC'); $st->execute([$uid, $pid]);
    json_out(['ok' => true, 'files' => $st->fetchAll()]);
}
default: json_out(['ok' => false], 404);
}
