<?php
declare(strict_types=1);
/** Kontrol tautan publik read-only (hanya pemilik): status / create / disable / regenerate / update. */
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/chat_lib.php';
session_boot();
$user = require_api_login();
$uid = (int)$user['id']; $pdo = db();
$act = (string)($_GET['action'] ?? '');
csrf_check();
if (!SHARE_ENABLED) json_out(['ok' => false, 'error' => 'Fitur berbagi dinonaktifkan'], 403);
$in = ($_SERVER['REQUEST_METHOD'] === 'POST') ? json_in() : [];
$cid = (int)($in['id'] ?? $_GET['id'] ?? 0);
$conv = chat_own_conv($cid, $uid);
if (!$conv) json_out(['ok' => false, 'error' => 'Percakapan tidak ditemukan'], 404);

function snap_max(int $cid): int { $st = db()->prepare('SELECT COALESCE(MAX(id),0) FROM messages WHERE conversation_id=? AND active=1'); $st->execute([$cid]); return (int)$st->fetchColumn(); }
function share_row(int $cid): ?array { $st = db()->prepare('SELECT * FROM shares WHERE conversation_id=?'); $st->execute([$cid]); $r = $st->fetch(); return $r ?: null; }
function share_out(?array $s): array {
    if (!$s) return ['ok' => true, 'share' => null];
    return ['ok' => true, 'share' => ['enabled' => (int)$s['enabled'], 'url' => $s['enabled'] ? share_url($s['token']) : null, 'views' => (int)$s['views'], 'updated_at' => $s['updated_at']]];
}
$s = share_row($cid);
switch ($act) {
case 'status': json_out(share_out($s));
case 'create':
    if (!$s) {
        if (snap_max($cid) === 0) json_out(['ok' => false, 'error' => 'Percakapan masih kosong'], 422);
        $pdo->prepare('INSERT INTO shares (conversation_id,user_id,token,enabled,max_message_id) VALUES (?,?,?,1,?)')->execute([$cid, $uid, bin2hex(random_bytes(20)), snap_max($cid)]);
    } elseif (!$s['enabled']) {
        $pdo->prepare('UPDATE shares SET enabled=1, revoked_at=NULL, token=?, max_message_id=?, views=0 WHERE id=?')->execute([bin2hex(random_bytes(20)), snap_max($cid), $s['id']]);
    }
    json_out(share_out(share_row($cid)));
case 'disable':
    if ($s) $pdo->prepare('UPDATE shares SET enabled=0, revoked_at=NOW() WHERE id=?')->execute([$s['id']]);
    json_out(share_out(share_row($cid)));
case 'regenerate':   // token lama langsung tidak berlaku
    if (!$s) json_out(['ok' => false, 'error' => 'Belum ada tautan'], 422);
    $pdo->prepare('UPDATE shares SET token=?, enabled=1, revoked_at=NULL, max_message_id=?, views=0 WHERE id=?')->execute([bin2hex(random_bytes(20)), snap_max($cid), $s['id']]);
    json_out(share_out(share_row($cid)));
case 'update':       // perbarui snapshot (pesan baru ikut terlihat) tanpa mengganti token
    if (!$s || !$s['enabled']) json_out(['ok' => false, 'error' => 'Tautan tidak aktif'], 422);
    $pdo->prepare('UPDATE shares SET max_message_id=? WHERE id=?')->execute([snap_max($cid), $s['id']]);
    json_out(share_out(share_row($cid)));
default: json_out(['ok' => false], 404);
}
