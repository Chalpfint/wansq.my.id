<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/memory.php';
session_boot();
$user = require_api_login();
$uid = (int)$user['id']; $pdo = db();
$act = (string)($_GET['action'] ?? '');
csrf_check();
$in = json_in();

switch ($act) {
case 'update':
    $name  = trim((string)($in['full_name'] ?? ''));
    $uname = trim((string)($in['username'] ?? ''));
    if ($uname !== '' && !preg_match('/^[a-zA-Z0-9_.]{3,30}$/', $uname))
        json_out(['ok' => false, 'error' => 'Username 3–30 karakter: huruf, angka, _ .'], 422);
    if ($uname !== '') {
        $st = $pdo->prepare('SELECT id FROM users WHERE username=? AND id<>?'); $st->execute([$uname, $uid]);
        if ($st->fetch()) json_out(['ok' => false, 'error' => 'Username sudah dipakai'], 409);
    }
    $pdo->prepare('UPDATE users SET full_name=?, username=? WHERE id=?')
        ->execute([mb_substr($name, 0, 120), $uname !== '' ? $uname : $user['username'], $uid]);
    json_out(['ok' => true, 'full_name' => mb_substr($name, 0, 120), 'username' => $uname !== '' ? $uname : $user['username']]);

case 'password':
    $new = (string)($in['new'] ?? '');
    if (strlen($new) < 8) json_out(['ok' => false, 'error' => 'Password minimal 8 karakter'], 422);
    if ($user['password_hash'] && !password_verify((string)($in['old'] ?? ''), $user['password_hash']))
        json_out(['ok' => false, 'error' => 'Password lama salah'], 403);
    $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
    json_out(['ok' => true]);

case 'theme':
    $t = (string)($in['theme'] ?? 'system');
    if (!in_array($t, ['light', 'dark', 'system'], true)) json_out(['ok' => false], 422);
    $pdo->prepare('UPDATE users SET theme=? WHERE id=?')->execute([$t, $uid]);
    json_out(['ok' => true]);

case 'prefs':
    $ui = (string)($in['ui_lang'] ?? ($user['ui_lang'] ?? 'id')); $rp = (string)($in['reply_lang'] ?? ($user['reply_lang'] ?? 'auto'));
    if (!in_array($ui, ['id', 'en'], true) || !in_array($rp, ['auto', 'id', 'en'], true)) json_out(['ok' => false, 'error' => 'Nilai tidak valid'], 422);
    $pdo->prepare('UPDATE users SET ui_lang=?, reply_lang=? WHERE id=?')->execute([$ui, $rp, $uid]);
    json_out(['ok' => true, 'ui_lang' => $ui, 'reply_lang' => $rp]);

case 'instructions':
    $ci = trim((string)($in['custom_instructions'] ?? ''));
    $ci = mb_substr($ci, 0, 1500);
    try { $pdo->prepare('UPDATE users SET custom_instructions=? WHERE id=?')->execute([$ci !== '' ? $ci : null, $uid]); }
    catch (Throwable $e) { app_log('instructions save: ' . $e->getMessage()); json_out(['ok' => false, 'error' => 'Kolom custom_instructions belum ada. Jalankan sql/wansq_upgrade_v4.1.4.sql lalu coba lagi.'], 503); }
    json_out(['ok' => true]);

case 'avatar_reset':
    $pdo->prepare("UPDATE users SET avatar_local='' WHERE id=?")->execute([$uid]);
    json_out(['ok' => true, 'avatar' => $user['avatar_google'] ?: base_url('/assets/img/avatar-default.svg')]);

case 'memories':
    $st = $pdo->prepare('SELECT id,content,created_at FROM memories WHERE user_id=? ORDER BY id DESC'); $st->execute([$uid]);
    json_out(['ok' => true, 'memories' => $st->fetchAll()]);

case 'memory_delete':
    $pdo->prepare('DELETE FROM memories WHERE id=? AND user_id=?')->execute([(int)($in['id'] ?? 0), $uid]);
    json_out(['ok' => true]);

case 'memory_clear':
    $pdo->prepare('DELETE FROM memories WHERE user_id=?')->execute([$uid]);
    json_out(['ok' => true]);

case 'remember':
    $c = trim((string)($in['content'] ?? ''));
    if ($c === '') json_out(['ok' => false], 422);
    save_memory($uid, $c);
    json_out(['ok' => true]);

default: json_out(['ok' => false], 404);
}