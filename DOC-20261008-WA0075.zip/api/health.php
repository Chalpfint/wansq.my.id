<?php
declare(strict_types=1);
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require __DIR__ . '/../includes/auth.php';
require __DIR__ . '/../includes/models.php';
require __DIR__ . '/../includes/caps.php';
session_boot();
if (!current_user()) json_out(['ok'=>false,'error'=>'Sesi berakhir. Silakan login kembali.'],401);
session_touch();
session_write_close();

$out = ['ok' => true, 'db' => false, 'db_ms' => null, 'groq' => false, 'groq_ms' => null, 'groq_error' => null,
        'schema' => null, 'chat_model' => null, 'vision_model' => null, 'active_models' => array(), 'capabilities' => array()];

$t = microtime(true);
try { db()->query('SELECT 1'); $out['db'] = true; } catch (Throwable $e) { /* banner DB */ }
$out['db_ms'] = ms_since($t);
$out['schema'] = schema_ready();

$t = microtime(true);
$live = llm_live_models(!empty($_GET['force']));
if (!$live) {   // cache kosong & jaringan gagal → ambil alasan galat yang jujur
    $r = groq_get('/models', 8);
    $out['groq_error'] = isset($r['error']['message']) ? (string)$r['error']['message'] : ('HTTP ' . ($r['_http'] ?? 0) . ' — provider tidak merespons / API key tidak valid');
} else $out['groq'] = true;
$out['groq_ms'] = ms_since($t);
if ($out['groq']) {
    $out['chat_model'] = count(llm_chain('chat')) > 0;
    $out['vision_model'] = count(llm_chain('vision')) > 0;
    $out['active_models'] = array('chat' => llm_chain('chat')[0] ?? null, 'vision' => llm_chain('vision')[0] ?? null, 'fast' => llm_chain('fast')[0] ?? null);
    foreach ($out['active_models'] as $role => $model) if ($model) $out['capabilities'][$role] = llm_capabilities($model); 
}
$out['caps'] = caps_build();

if (isset($_GET['full'])) {
    $out['diag'] = [
        'php' => PHP_VERSION, 'gd' => function_exists('imagecreatefromstring'), 'zip' => class_exists('ZipArchive'),
        'mbstring' => extension_loaded('mbstring'), 'iconv' => extension_loaded('iconv'), 'curl' => function_exists('curl_init'),
        'uploads_writable' => is_writable(UPLOAD_DIR), 'storage_writable' => is_writable(STORAGE_DIR),
        'att_dir_writable' => (is_dir(STORAGE_DIR . '/att') ? is_writable(STORAGE_DIR . '/att') : @mkdir(STORAGE_DIR . '/att', 0775, true)),
        'upload_max_filesize' => ini_get('upload_max_filesize'), 'post_max_size' => ini_get('post_max_size'), 'memory_limit' => ini_get('memory_limit'), 'max_execution_time' => ini_get('max_execution_time'), 'max_input_time' => ini_get('max_input_time'), 'max_file_uploads' => ini_get('max_file_uploads'), 'configured_limits' => ['original_upload' => ORIGINAL_UPLOAD_LIMIT, 'image_inference' => INFERENCE_IMAGE_LIMIT, 'provider_image' => PROVIDER_IMAGE_LIMIT, 'document' => DOC_MAX_BYTES],
        'pdfparser' => is_dir(__DIR__ . '/../includes/vendor/pdfparser/src'),
        'chat_chain' => llm_chain('chat'), 'fast_chain' => llm_chain('fast'), 'vision_chain' => llm_chain('vision'),
        'dead_models' => array_keys(llm_dead()), 'live_count' => count($live),
        'version' => WANSQ_VERSION, 'schema_target' => '4.1.4',
    ];
}
json_out($out);
