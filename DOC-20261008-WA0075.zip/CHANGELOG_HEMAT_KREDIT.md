# WanSQ 3.2.4 — Perbaikan Token & Kredit (tanpa mengubah versi)

## Penyebab batas token kecil
Setiap request meminta max_tokens besar. OpenRouter menolak request (HTTP 402) bila saldo tidak
menutupi prompt + max_tokens, dengan pesan "can only afford N". Versi sebelumnya tidak membaca N,
sehingga semua fallback model gagal. Selain itu anggaran input dihitung dari jendela konteks model
(±1 juta token), sehingga prompt besar ikut menguras saldo.

## Perubahan
- Retry adaptif (llm.php): HTTP 402 → batas output diturunkan ke ~92% dari N, model sama dicoba lagi;
  batas per model berlaku 120 detik. Parameter reasoning tidak ikut terhapus saat retry.
- Mode hemat (llm_budget_pressure): saat batas kredit kecil, input dibatasi PRESSURE_INPUT_TOKENS (6000),
  reasoning diturunkan ke low, saran lanjutan dan ringkasan ditunda.
- Qwen reasoning_effort: nilai 'default' (ditolak provider) diganti low/medium.
- Router Luna (decisions) per request dinonaktifkan secara default (WANSQ_LUNA_ROUTER=false).
- FREE_FALLBACK_MODELS: fallback opsional (mis. model ':free') sebagai jaring terakhir non-vision.
- Stabilitas DB: dbEnsure() sebelum query setelah tahap upload/vision (penyebab 'gone away').
- Log: ob_flush dijaga; error yang disenyapkan operator @ tidak dicatat.

## Wajib dilakukan setelah unggah
1. JANGAN menimpa includes/config.local.php di server. File tersebut tidak ikut paket ini.
   Bila server Anda sudah memakai config.local.php, biarkan apa adanya.
2. Rotasi semua kredensial yang pernah terekspos (password DB, Google Client Secret, Groq, OpenRouter).
3. Isi ulang saldo OpenRouter. Batas panjang jawaban tetap mengikuti saldo.
