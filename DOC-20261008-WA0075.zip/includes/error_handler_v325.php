<?php
/**
 * WanSQ v3.2.5 — Enhanced Error Handler
 * Comprehensive error handling with context, logging, and recovery
 */

declare(strict_types=1);

class ErrorHandlerV325 {
    private static $errorLog = [];
    private static $errorCounts = [];

    const ERROR_RETRY_STRATEGIES = [
        'model_unavailable' => ['max_retries' => 3, 'backoff' => 'exponential'],
        'rate_limit' => ['max_retries' => 5, 'backoff' => 'exponential'],
        'timeout' => ['max_retries' => 2, 'backoff' => 'linear'],
        'network_error' => ['max_retries' => 3, 'backoff' => 'exponential'],
        'api_error' => ['max_retries' => 1, 'backoff' => 'none'],
    ];

    /**
     * Initialize error handler
     */
    public static function init(): void {
        set_error_handler([self::class, 'handlePHPError']);
        set_exception_handler([self::class, 'handleException']);
        register_shutdown_function([self::class, 'handleShutdown']);
    }

    /**
     * Handle PHP errors
     */
    public static function handlePHPError(int $errno, string $errstr, string $errfile, int $errline): bool {
        if (!(error_reporting() & $errno)) return false;   // galat yang disenyapkan operator @ tidak dicatat
        $error = [
            'type' => 'PHP Error',
            'code' => $errno,
            'message' => $errstr,
            'file' => $errfile,
            'line' => $errline,
            'timestamp' => gmdate('c'),
            'context' => self::getContext(),
        ];

        self::log($error, 'php_error');

        // Convert to exception for consistent handling
        if (in_array($errno, [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
            throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
        }

        return false;
    }

    /**
     * Handle exceptions
     */
    public static function handleException(Throwable $e): void {
        $error = [
            'type' => 'Exception',
            'class' => get_class($e),
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => array_slice($e->getTrace(), 0, 5),
            'timestamp' => gmdate('c'),
            'context' => self::getContext(),
        ];

        self::log($error, 'exception');

        // Determine recovery strategy
        $response = self::getRecoveryResponse($e);

        http_response_code($response['code']);
        header('Content-Type: application/json');
        echo json_encode($response['body'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * Handle shutdown (fatal errors)
     */
    public static function handleShutdown(): void {
        $error = error_get_last();
        if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
            $data = [
                'type' => 'Fatal Error',
                'message' => $error['message'],
                'file' => $error['file'],
                'line' => $error['line'],
                'timestamp' => gmdate('c'),
                'context' => self::getContext(),
            ];

            self::log($data, 'fatal_error');

            // Try to send response
            if (!headers_sent()) {
                http_response_code(500);
                header('Content-Type: application/json');
                echo json_encode([
                    'error' => 'Server error',
                    'code' => 'FATAL_ERROR',
                ], JSON_UNESCAPED_UNICODE);
            }
        }
    }

    /**
     * Get recovery response based on error type
     */
    private static function getRecoveryResponse(Throwable $e): array {
        $message = $e->getMessage();
        $code = (int)$e->getCode();

        // Model-related errors
        if (stripos($message, 'model') !== false || stripos($message, 'openrouter') !== false) {
            return [
                'code' => 503,
                'body' => [
                    'error' => 'Model service temporarily unavailable',
                    'code' => 'MODEL_ERROR',
                    'retry' => true,
                    'message' => 'Using fallback model...',
                ]
            ];
        }

        // Rate limit errors
        if ($code === 429 || stripos($message, 'rate limit') !== false) {
            return [
                'code' => 429,
                'body' => [
                    'error' => 'Rate limited',
                    'code' => 'RATE_LIMITED',
                    'retry' => true,
                    'retry_after' => 30,
                ]
            ];
        }

        // Timeout errors
        if ($code === 504 || stripos($message, 'timeout') !== false) {
            return [
                'code' => 504,
                'body' => [
                    'error' => 'Request timeout',
                    'code' => 'TIMEOUT',
                    'retry' => true,
                ]
            ];
        }

        // Authentication errors
        if ($code === 401 || stripos($message, 'auth') !== false) {
            return [
                'code' => 401,
                'body' => [
                    'error' => 'Authentication failed',
                    'code' => 'AUTH_ERROR',
                    'retry' => false,
                ]
            ];
        }

        // Database errors
        if (stripos($message, 'database') !== false || stripos($message, 'sql') !== false) {
            return [
                'code' => 500,
                'body' => [
                    'error' => 'Database error',
                    'code' => 'DB_ERROR',
                    'retry' => true,
                ]
            ];
        }

        // Validation errors
        if ($code === 400 || stripos($message, 'validation') !== false) {
            return [
                'code' => 400,
                'body' => [
                    'error' => $message,
                    'code' => 'VALIDATION_ERROR',
                    'retry' => false,
                ]
            ];
        }

        // Default error
        return [
            'code' => 500,
            'body' => [
                'error' => 'Internal server error',
                'code' => 'INTERNAL_ERROR',
                'retry' => false,
            ]
        ];
    }

    /**
     * Get execution context for logging
     */
    private static function getContext(): array {
        $context = [
            'user_id' => $_SESSION['user_id'] ?? null,
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'UNKNOWN',
            'uri' => $_SERVER['REQUEST_URI'] ?? 'UNKNOWN',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN',
        ];

        // Add request body if POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $body = json_decode(file_get_contents('php://input'), true);
            if ($body && is_array($body)) {
                // Don't log sensitive data
                $safe_body = $body;
                unset($safe_body['password'], $safe_body['token'], $safe_body['api_key']);
                $context['request_body'] = $safe_body;
            }
        }

        // Memory usage
        $context['memory_usage_mb'] = round(memory_get_usage(true) / 1024 / 1024, 2);
        $context['memory_peak_mb'] = round(memory_get_peak_usage(true) / 1024 / 1024, 2);

        return $context;
    }

    /**
     * Log error with context
     */
    private static function log(array $error, string $level = 'error'): void {
        $errorKey = $error['message'];
        if (!isset(self::$errorCounts[$errorKey])) {
            self::$errorCounts[$errorKey] = 0;
        }
        self::$errorCounts[$errorKey]++;

        // File-based logging
        $logFile = __DIR__ . '/../storage/logs/errors_' . date('Y-m-d') . '.log';
        $logEntry = json_encode($error, JSON_UNESCAPED_UNICODE) . "\n";

        error_log($logEntry, 3, $logFile);

        // In-memory log (for current request)
        self::$errorLog[] = $error;
    }

    /**
     * Get error logs from current request
     */
    public static function getLogs(): array {
        return self::$errorLog;
    }

    /**
     * Get error statistics
     */
    public static function getStats(): array {
        return [
            'total_errors' => count(self::$errorLog),
            'error_counts' => self::$errorCounts,
            'most_common' => array_keys(self::$errorCounts, max(self::$errorCounts)),
        ];
    }

    /**
     * Attempt retry with exponential backoff
     */
    public static function retry(callable $fn, string $errorType = 'timeout', int $maxRetries = 3): mixed {
        $strategy = self::ERROR_RETRY_STRATEGIES[$errorType] ?? ['max_retries' => 1, 'backoff' => 'none'];

        for ($attempt = 0; $attempt <= $strategy['max_retries']; $attempt++) {
            try {
                return $fn();
            } catch (Exception $e) {
                if ($attempt >= $strategy['max_retries']) {
                    throw $e;
                }

                // Calculate backoff
                $delay = match($strategy['backoff']) {
                    'exponential' => min(1000 * (2 ** $attempt), 10000),
                    'linear' => 1000 * ($attempt + 1),
                    default => 0,
                };

                if ($delay > 0) {
                    usleep($delay * 1000);
                }
            }
        }
    }

    /**
     * Safe API call with fallback
     */
    public static function safeApiCall(
        string $url,
        array $headers,
        string $method = 'GET',
        ?array $data = null,
        ?string $fallbackModel = null
    ): array {
        try {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);

            if ($method !== 'GET' && $data) {
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode >= 400) {
                throw new Exception("HTTP $httpCode", $httpCode);
            }

            return json_decode($response, true) ?? [];
        } catch (Exception $e) {
            self::log([
                'type' => 'API Error',
                'url' => $url,
                'error' => $e->getMessage(),
                'fallback_model' => $fallbackModel,
                'timestamp' => gmdate('c'),
            ], 'api_error');

            // Return fallback
            if ($fallbackModel) {
                return ['model' => $fallbackModel, 'fallback' => true];
            }

            throw $e;
        }
    }
}

// Initialize on include
ErrorHandlerV325::init();
