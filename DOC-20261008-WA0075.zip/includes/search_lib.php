<?php
declare(strict_types=1);
/**
 * WanSQ · Full-text search lintas percakapan, pesan user/AI, pinned, project, file & memory.
 * Memakai indeks FULLTEXT (InnoDB) — tidak memindai seluruh percakapan tiap ketikan; hasil dipaginasi.
 * Fallback LIKE hanya bila FULLTEXT kosong (token < 3 huruf / stopword) dan selalu dibatasi LIMIT.
 */
function search_terms(string $q): array {
    preg_match_all('/[\p{L}\p{N}]+/u', mb_strtolower($q), $m);
    return array_slice(array_values(array_unique($m[0])), 0, 8);
}
function search_like_escape(string $s): string { return str_replace(array('\\', '%', '_'), array('\\\\', '\\%', '\\_'), $s); }
function search_ft(array $terms, bool $and): string {
    $p = array();
    foreach ($terms as $t) if (mb_strlen($t) >= 3) $p[] = ($and ? '+' : '') . $t . '*';
    return implode(' ', $p);
}
/** Cuplikan HTML aman dengan sorotan <mark> di sekitar kecocokan pertama. */
function search_snippet(string $content, array $terms, int $radius = 90): string {
    $flat = trim(preg_replace('/\s+/u', ' ', preg_replace('/```[\s\S]*?```/u', ' [kode] ', $content)));
    $pos = null;
    foreach ($terms as $t) { $p = mb_stripos($flat, $t); if ($p !== false && ($pos === null || $p < $pos)) $pos = $p; }
    $start = $pos === null ? 0 : max(0, $pos - $radius);
    $seg = mb_substr($flat, $start, $radius * 2 + 40);
    $pre = $start > 0 ? '…' : ''; $post = ($start + mb_strlen($seg)) < mb_strlen($flat) ? '…' : '';
    if (!$terms) return e($pre . $seg . $post);
    $re = '/(' . implode('|', array_map(function ($t) { return preg_quote($t, '/'); }, $terms)) . ')/iu';
    $parts = preg_split($re, $seg, -1, PREG_SPLIT_DELIM_CAPTURE);
    $out = '';
    foreach ($parts as $i => $p) $out .= ($i % 2) ? '<mark>' . e($p) . '</mark>' : e($p);
    return e($pre) . $out . e($post);
}

function search_conv_meta(array $ids, int $uid): array {
    if (!$ids) return array();
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $st = db()->prepare("SELECT c.id,c.title,c.updated_at,c.archived,c.project_id,p.name pname,p.icon picon FROM conversations c
        LEFT JOIN projects p ON p.id=c.project_id WHERE c.user_id=? AND c.deleted_at IS NULL AND c.id IN ($ph)");
    $st->execute(array_merge(array($uid), $ids)); $out = array();
    foreach ($st->fetchAll() as $r) $out[(int)$r['id']] = $r;
    return $out;
}

/** Pencarian percakapan. Return: items[], total, ms. */
function search_chats(int $uid, string $q, int $offset = 0, int $limit = 20, ?int $projectId = null, ?int $archived = null): array {
    $t0 = microtime(true); $pdo = db(); $terms = search_terms($q);
    if (!$terms) return array('items' => array(), 'total' => 0, 'ms' => 0);
    $hits = array();   // conv_id => array(score, source, snippet, mid, page, n)
    $add = function (int $cid, float $score, string $src, string $snip, ?int $mid, ?int $page = null) use (&$hits) {
        if (!isset($hits[$cid])) $hits[$cid] = array('score' => $score, 'source' => $src, 'snippet' => $snip, 'mid' => $mid, 'page' => $page, 'n' => 1);
        else { $hits[$cid]['n']++; if ($score > $hits[$cid]['score']) { $n = $hits[$cid]['n']; $hits[$cid] = array('score' => $score, 'source' => $src, 'snippet' => $snip, 'mid' => $mid, 'page' => $page, 'n' => $n); } }
    };
    $pf = $projectId ? ' AND c.project_id=?' : ''; $pv = $projectId ? array($projectId) : array();

    // 1) judul (semua kata harus ada)
    $where = array(); $args = array($uid);
    foreach ($terms as $t) { $where[] = "c.title LIKE ? ESCAPE '\\\\'"; $args[] = '%' . search_like_escape($t) . '%'; }
    $st = $pdo->prepare('SELECT c.id,c.title FROM conversations c WHERE c.user_id=? AND c.deleted_at IS NULL' . $pf . ' AND ' . implode(' AND ', $where) . ' ORDER BY c.updated_at DESC LIMIT 60');
    $st->execute(array_merge(array($uid), $pv, array_slice($args, 1)));
    foreach ($st->fetchAll() as $r) $add((int)$r['id'], 1000, 'title', search_snippet((string)$r['title'], $terms), null);

    // 2) isi pesan (FULLTEXT; AND dulu, lalu OR, lalu LIKE)
    $rows = array();
    foreach (array(true, false) as $and) {
        $fq = search_ft($terms, $and); if ($fq === '') continue;
        if (!$and && count($terms) < 2) break;
        try {
            $st = $pdo->prepare('SELECT m.id mid,m.conversation_id cid,m.role,m.pinned,m.content, MATCH(m.content) AGAINST (? IN BOOLEAN MODE) sc
                FROM messages m JOIN conversations c ON c.id=m.conversation_id
                WHERE c.user_id=? AND c.deleted_at IS NULL AND m.active=1' . $pf . ' AND MATCH(m.content) AGAINST (? IN BOOLEAN MODE) ORDER BY sc DESC LIMIT 300');
            $st->execute(array_merge(array($fq, $uid), $pv, array($fq)));
            $rows = $st->fetchAll();
        } catch (Throwable $e) { app_log('search ft fail: ' . $e->getMessage()); }
        if ($rows) break;
    }
    if (!$rows) {   // fallback LIKE terbatas
        $l = search_like_escape(mb_strtolower(implode(' ', $terms)));
        $st = $pdo->prepare("SELECT m.id mid,m.conversation_id cid,m.role,m.pinned,m.content,1 sc FROM messages m JOIN conversations c ON c.id=m.conversation_id
            WHERE c.user_id=? AND c.deleted_at IS NULL AND m.active=1" . $pf . " AND m.content LIKE ? ESCAPE '\\\\' ORDER BY m.id DESC LIMIT 100");
        $st->execute(array_merge(array($uid), $pv, array('%' . $l . '%')));
        $rows = $st->fetchAll();
    }
    foreach ($rows as $r) {
        $src = $r['pinned'] ? 'pinned' : ($r['role'] === 'user' ? 'user' : 'assistant');
        $add((int)$r['cid'], (float)$r['sc'] + ($r['pinned'] ? 0.5 : 0), $src, search_snippet((string)$r['content'], $terms), (int)$r['mid']);
    }

    // 3) isi dokumen (chat yang berkaitan dengan file)
    $fq = search_ft($terms, false);
    if ($fq !== '') {
        try {
            $st = $pdo->prepare('SELECT a.conversation_id cid,a.original_name,d.page_start,d.content, MATCH(d.content) AGAINST (? IN BOOLEAN MODE) sc
                FROM doc_chunks d JOIN attachments a ON a.id=d.attachment_id JOIN conversations c ON c.id=a.conversation_id
                WHERE a.user_id=? AND a.removed=0 AND c.deleted_at IS NULL' . $pf . ' AND MATCH(d.content) AGAINST (? IN BOOLEAN MODE) ORDER BY sc DESC LIMIT 60');
            $st->execute(array_merge(array($fq, $uid), $pv, array($fq)));
            foreach ($st->fetchAll() as $r) if ($r['cid']) $add((int)$r['cid'], (float)$r['sc'] * 0.6, 'file', '📄 ' . e((string)$r['original_name']) . ' — ' . search_snippet((string)$r['content'], $terms, 70), null, (int)$r['page_start']);
        } catch (Throwable $e) { app_log('search doc ft fail: ' . $e->getMessage()); }
    }

    $meta = search_conv_meta(array_keys($hits), $uid);
    $items = array();
    foreach ($hits as $cid => $h) {
        if (!isset($meta[$cid])) continue; $m = $meta[$cid];
        if ($archived !== null && (int)$m['archived'] !== $archived) continue;
        $items[] = array('id' => $cid, 'title' => $m['title'], 'updated_at' => $m['updated_at'], 'archived' => (int)$m['archived'],
            'project' => $m['project_id'] ? array('id' => (int)$m['project_id'], 'name' => $m['pname'], 'icon' => $m['picon']) : null,
            'source' => $h['source'], 'snippet' => $h['snippet'], 'message_id' => $h['mid'], 'page' => $h['page'], 'matches' => $h['n'], '_s' => $h['score']);
    }
    usort($items, function ($a, $b) { return [$b['_s'], $b['updated_at']] <=> [$a['_s'], $a['updated_at']]; });
    $total = count($items);
    $items = array_slice($items, $offset, $limit);
    foreach ($items as &$it) unset($it['_s']); unset($it);
    return array('items' => $items, 'total' => $total, 'ms' => ms_since($t0), 'terms' => $terms);
}

/** Command palette: semua kategori sekaligus (masing-masing dibatasi). */
function search_all(int $uid, string $q): array {
    $t0 = microtime(true); $terms = search_terms($q); $pdo = db();
    $out = array('chats' => array(), 'projects' => array(), 'files' => array(), 'memory' => array(), 'artifacts' => array());
    if (!$terms) return $out + array('ms' => 0);
    $out['chats'] = search_chats($uid, $q, 0, 8)['items'];
    $lk = function (string $col) use ($terms) { return implode(' AND ', array_map(function () use ($col) { return "$col LIKE ? ESCAPE '\\\\'"; }, $terms)); };
    $lv = array_map(function ($t) { return '%' . search_like_escape($t) . '%'; }, $terms);
    $st = $pdo->prepare('SELECT id,name,icon FROM projects WHERE user_id=? AND ' . $lk('name') . ' ORDER BY updated_at DESC LIMIT 6');
    $st->execute(array_merge(array($uid), $lv)); $out['projects'] = $st->fetchAll();
    $st = $pdo->prepare("SELECT a.id,a.original_name name,a.kind,a.conversation_id,a.project_id,a.pages FROM attachments a WHERE a.user_id=? AND a.removed=0 AND a.generated=0 AND " . $lk('a.original_name') . ' ORDER BY a.id DESC LIMIT 6');
    $st->execute(array_merge(array($uid), $lv)); $out['files'] = $st->fetchAll();
    $st = $pdo->prepare('SELECT id,content FROM memories WHERE user_id=? AND ' . $lk('content') . ' ORDER BY id DESC LIMIT 5');
    $st->execute(array_merge(array($uid), $lv)); foreach ($st->fetchAll() as $r) $out['memory'][] = array('id' => (int)$r['id'], 'content' => $r['content'], 'scope' => 'global');
    try {
        $st = $pdo->prepare('SELECT id,title,type,project_id,conversation_id,version,updated_at FROM artifacts WHERE user_id=? AND (' . $lk('title') . ' OR ' . $lk('content') . ') ORDER BY updated_at DESC LIMIT 8');
        $st->execute(array_merge(array($uid), $lv, $lv));
        foreach ($st->fetchAll() as $r) $out['artifacts'][] = array('id'=>(int)$r['id'],'title'=>$r['title'],'type'=>$r['type'],'project_id'=>$r['project_id'] ? (int)$r['project_id'] : null,'conversation_id'=>$r['conversation_id'] ? (int)$r['conversation_id'] : null,'version'=>(int)$r['version'],'updated_at'=>$r['updated_at']);
    } catch (Throwable $e) { /* v4.1.4 migration may not yet have been applied */ }
    $st = $pdo->prepare('SELECT pm.id,pm.content,p.name FROM project_memories pm JOIN projects p ON p.id=pm.project_id WHERE pm.user_id=? AND ' . $lk('pm.content') . ' ORDER BY pm.id DESC LIMIT 5');
    $st->execute(array_merge(array($uid), $lv)); foreach ($st->fetchAll() as $r) $out['memory'][] = array('id' => (int)$r['id'], 'content' => $r['content'], 'scope' => 'project', 'project' => $r['name']);
    $out['ms'] = ms_since($t0); $out['terms'] = $terms;
    return $out;
}
