<?php
declare(strict_types=1);
/**
 * WanSQ · Document intelligence: ekstraksi per halaman (PDF/DOCX/teks), chunking, indeks FULLTEXT, retrieval (RAG).
 * Catatan jujur: Groq tidak menyediakan endpoint embedding, jadi retrieval memakai FULLTEXT (BM25-like) + skor kata kunci
 * + pemetaan halaman + sampling untuk pertanyaan "ringkas/isi". Bila kelak ada provider embedding, cukup ganti doc_rank().
 */
require_once __DIR__ . '/pdf_lib.php';

function doc_load_pdfparser(): bool {
    static $ok = null;
    if ($ok !== null) return $ok;
    $base = __DIR__ . '/vendor/pdfparser/src/';
    if (!is_dir($base)) return $ok = false;
    spl_autoload_register(function ($cls) use ($base) {
        if (strpos($cls, 'Smalot\\PdfParser\\') !== 0) return;
        $f = $base . str_replace('\\', '/', $cls) . '.php';
        if (is_file($f)) require $f;
    });
    return $ok = true;
}

function doc_clean(string $t): string {
    if (!mb_check_encoding($t, 'UTF-8')) $t = mb_convert_encoding($t, 'UTF-8', 'UTF-8,ISO-8859-1,Windows-1252');
    $t = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x{FFFD}]/u', '', $t) ?? $t;
    $t = preg_replace('/[ \t\x{00A0}]+/u', ' ', $t) ?? $t;
    $t = preg_replace('/ ?\n ?/', "\n", $t) ?? $t;
    $t = preg_replace('/\n{3,}/', "\n\n", $t) ?? $t;
    return trim($t);
}
/** Teks dianggap terbaca bila cukup panjang dan sebagian besar berupa huruf/angka/spasi. */
function doc_text_ok(string $t, int $min = 25): bool {
    $len = mb_strlen($t);
    if ($len < $min) return false;
    preg_match_all('/[\p{L}\p{N}\s.,;:()\-\'"%\/]/u', $t, $m);
    return (count($m[0]) / max(1, $len)) >= 0.7;
}

/** PDF → ['ok','count','pages'=>[n=>text],'text_pages'=>int,'missing'=>[n..],'engine','err','ms'] */
function doc_pdf_pages(string $path): array {
    $t0 = microtime(true);
    $out = array('ok' => false, 'count' => 0, 'pages' => array(), 'text_pages' => 0, 'missing' => array(), 'engine' => 'none', 'err' => null, 'ms' => 0);
    @ini_set('memory_limit', '512M'); @set_time_limit(120);
    $count = doc_pdf_page_count($path);
    if (doc_load_pdfparser()) {
        try {
            $cfg = new \Smalot\PdfParser\Config();
            $cfg->setRetainImageContent(false);
            $parser = new \Smalot\PdfParser\Parser(array(), $cfg);
            $pdf = $parser->parseFile($path);
            $pgs = $pdf->getPages();
            $n = 0;
            foreach ($pgs as $pg) {
                $n++;
                if ($n > DOC_MAX_PAGES) break;
                try { $out['pages'][$n] = doc_clean((string)$pg->getText()); } catch (Throwable $e) { $out['pages'][$n] = ''; }
            }
            $out['count'] = max($count, $n); $out['engine'] = 'pdfparser'; $out['ok'] = $n > 0;
        } catch (Throwable $e) { $out['err'] = $e->getMessage(); }
    }
    if (!$out['ok'] || !array_filter($out['pages'], 'doc_text_ok')) {
        // fallback ekstraktor sederhana (satu blok, tanpa halaman)
        $legacy = doc_clean(pdf_extract_text($path, 200000));
        if (doc_text_ok($legacy, 40) && !array_filter($out['pages'], 'doc_text_ok')) {
            $out['pages'] = array(1 => $legacy); $out['engine'] = 'legacy'; $out['ok'] = true;
            $out['count'] = max($count, 1);
        }
    }
    $total = max($out['count'], $count);
    if ($total === 0 && $out['pages']) $total = count($out['pages']);
    $out['count'] = min($total, DOC_MAX_PAGES);
    foreach ($out['pages'] as $n => $t) if (doc_text_ok($t)) $out['text_pages']++;
    if ($out['engine'] === 'legacy') { $out['missing'] = array(); }
    else for ($i = 1; $i <= $out['count']; $i++) if (!isset($out['pages'][$i]) || !doc_text_ok($out['pages'][$i])) $out['missing'][] = $i;
    $out['ms'] = ms_since($t0);
    return $out;
}
/** Hitung jumlah halaman dengan pola /Type /Page (cepat, tanpa parse penuh). */
function doc_pdf_page_count(string $path): int {
    $d = @file_get_contents($path, false, null, 0, 30 * 1024 * 1024);
    if ($d === false) return 0;
    if (preg_match_all('~/Type\s*/Pages\b[^>]*?/Count\s+(\d+)~s', $d, $m) && $m[1]) return max(array_map('intval', $m[1]));
    return (int)preg_match_all('~/Type\s*/Page\b(?!s)~', $d);
}

/** Teks panjang (docx/txt/csv/…) → "bagian" berukuran ±3500 karakter. */
function doc_text_sections(string $t, int $size = 3500): array {
    $t = doc_clean($t); $out = array(); $n = 1;
    while (mb_strlen($t) > 0) {
        if (mb_strlen($t) <= $size) { $out[$n] = $t; break; }
        $c = mb_substr($t, 0, $size);
        $cut = max((int)mb_strrpos($c, "\n\n"), (int)mb_strrpos($c, "\n"), (int)mb_strrpos($c, '. '));
        if ($cut < $size * 0.5) $cut = $size;
        $out[$n++] = trim(mb_substr($t, 0, $cut)); $t = ltrim(mb_substr($t, $cut));
        if ($n > DOC_MAX_PAGES) break;
    }
    return $out;
}

/** Pecah halaman-halaman menjadi chunk (±$size karakter) yang sadar halaman. */
function doc_make_chunks(array $pages, int $size = 1100): array {
    $segs = array();
    foreach ($pages as $n => $t) {
        $t = trim((string)$t); if ($t === '') continue;
        if (mb_strlen($t) <= $size) { $segs[] = array((int)$n, $t); continue; }
        $buf = '';
        foreach (preg_split('/(?<=[.!?])\s+|\n+/u', $t) as $sn) {
            if (mb_strlen($buf) + mb_strlen($sn) + 1 > $size && $buf !== '') { $segs[] = array((int)$n, trim($buf)); $buf = mb_substr($buf, -120) . ' '; }
            while (mb_strlen($sn) > $size) { $segs[] = array((int)$n, mb_substr($sn, 0, $size)); $sn = mb_substr($sn, $size); }
            $buf .= $sn . ' ';
        }
        if (trim($buf) !== '') $segs[] = array((int)$n, trim($buf));
    }
    $chunks = array(); $cur = null;
    foreach ($segs as $s) {
        if ($cur && mb_strlen($cur['c']) + mb_strlen($s[1]) + 2 <= $size && $s[0] - $cur['pe'] <= 1) {
            $cur['c'] .= "\n" . $s[1]; $cur['pe'] = $s[0];
        } else {
            if ($cur) $chunks[] = $cur;
            $cur = array('ps' => $s[0], 'pe' => $s[0], 'c' => $s[1]);
        }
    }
    if ($cur) $chunks[] = $cur;
    return $chunks;
}
function doc_store_chunks(int $attId, int $uid, array $chunks, string $source = 'text'): int {
    if (!$chunks) return 0;
    $pdo = db(); $st = $pdo->prepare('INSERT INTO doc_chunks (attachment_id,user_id,page_start,page_end,idx,source,content) VALUES (?,?,?,?,?,?,?)');
    $pdo->beginTransaction();
    try {
        $i = (int)$pdo->query('SELECT COALESCE(MAX(idx),0) FROM doc_chunks WHERE attachment_id=' . (int)$attId)->fetchColumn();
        foreach ($chunks as $c) $st->execute(array($attId, $uid, $c['ps'], $c['pe'], ++$i, $source, $c['c']));
        $pdo->commit();
    } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
    return count($chunks);
}
function doc_unit(array $att): string {
    if (($att['mime'] ?? '') === 'application/pdf') return 'hal.';
    return strtolower(pathinfo((string)($att['original_name'] ?? ''), PATHINFO_EXTENSION)) === 'pptx' ? 'slide' : 'bagian';
}
function doc_pages_label(array $pages, string $unit = 'hal.'): string {
    $pages = array_values(array_unique(array_map('intval', $pages))); sort($pages);
    $r = array(); $s = null; $p = null;
    foreach ($pages as $x) {
        if ($s === null) { $s = $p = $x; continue; }
        if ($x === $p + 1) { $p = $x; continue; }
        $r[] = $s === $p ? (string)$s : $s . '–' . $p; $s = $p = $x;
    }
    if ($s !== null) $r[] = $s === $p ? (string)$s : $s . '–' . $p;
    return $unit . ' ' . implode(', ', $r);
}

/* ---------------- Retrieval ---------------- */
function doc_scope(int $uid, int $convId, ?int $projectId): array {
    $sql = "SELECT id,original_name,mime,status,pages,ocr_pages,conversation_id,project_id FROM attachments
            WHERE user_id=? AND kind='doc' AND removed=0 AND (conversation_id=?" . ($projectId ? ' OR project_id=?' : '') . ') ORDER BY id DESC LIMIT 12';
    $st = db()->prepare($sql);
    $st->execute($projectId ? array($uid, $convId, $projectId) : array($uid, $convId));
    return $st->fetchAll();
}
function doc_query_intent(string $q): array {
    $pages = null;
    if (preg_match('/\b(?:hal(?:aman)?\.?|page|pg\.?|slide)\s*(?:ke-?)?\s*(\d{1,4})(?:\s*(?:-|–|sampai|hingga|to|s\/d)\s*(\d{1,4}))?/iu', $q, $m)) {
        $a = (int)$m[1]; $b = isset($m[2]) && $m[2] !== '' ? (int)$m[2] : $a;
        if ($b < $a) { $t = $a; $a = $b; $b = $t; }
        $pages = array($a, min($b, $a + 15));
    }
    $explicit = (bool)preg_match('/\b(file ini|file tersebut|dokumen ini|dokumen tersebut|dokumen tadi|dokumen sebelumnya|pdf ini|pdf tersebut|pdf tadi|materi ini|materi tadi|lampiran ini|lampiran tadi|halaman|hal\.|page|pg\.|slide|isi dokumen|isi file|ringkas(?:lah)?(?: dokumen| file| pdf)?|rangk(?:um|uman)(?: dokumen| file| pdf)?|kesimpulan(?: dari)? (?:dokumen|file|pdf)|tabel (?:pada|dalam) (?:dokumen|file|pdf)|berdasarkan (?:dokumen|file|pdf)|dari (?:dokumen|file|pdf) (?:tadi|ini|tersebut)|from (?:this|the) (?:document|file|pdf)|summari[sz]e (?:this|the) (?:document|file|pdf))\b/iu', $q);
    $ov = (bool)preg_match('/\b(isi|isinya|ringkas|ringkasan|rangkum|rangkuman|inti|gagasan utama|ide pokok|kesimpulan|tentang apa|summary|summari[sz]e|overview|main idea|apa ini|jelaskan dokumen|bahas dokumen|dokumen ini|file ini)\b/iu', $q);
    return array('pages' => $pages, 'overview' => $ov, 'explicit' => $explicit);
}
function doc_ft_query(array $terms): string {
    $p = array();
    foreach (array_slice($terms, 0, 10) as $t) $p[] = preg_replace('/[+\-<>()~*"@]/u', '', $t) . '*';
    return implode(' ', array_filter($p, function ($x) { return strlen($x) > 1; }));
}

/**
 * Ambil konteks dokumen yang relevan. Return: ctx(string), sources(array), docs(array), mode, chunks(int), ms(int).
 */
function doc_retrieve(int $uid, int $convId, ?int $projectId, string $query, int $budget, bool $forceRelevant = false, array $onlyIds = array()): array {
    $t0 = microtime(true); $pdo = db();
    $res = array('ctx' => '', 'sources' => array(), 'docs' => array(), 'mode' => 'none', 'chunks' => 0, 'ms' => 0, 'relevance' => 0.0);
    $docs = doc_scope($uid, $convId, $projectId);
    // Lampiran baru pada pesan ini mendapat prioritas penuh: dokumen lama tidak boleh berebut anggaran konteks.
    if ($onlyIds) { $only = array_flip(array_map('intval', $onlyIds)); $docs = array_values(array_filter($docs, function ($d) use ($only) { return isset($only[(int)$d['id']]); })); }
    if (!$docs) return $res;
    $ids = array_map(function ($d) { return (int)$d['id']; }, $docs);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $intent = doc_query_intent($query);
    $terms = keywordize($query);
    $explicit = $forceRelevant || !empty($intent['explicit']) || !empty($intent['pages']) || (!empty($intent['overview']) && preg_match('/\\b(dokumen|file|pdf|materi|lampiran|document|file|pdf)\\b/iu', $query));
    $picked = array(); $mode = 'search'; $bestScore = 0.0;

    // Explicit document questions may use page/overview retrieval. Otherwise only a strong
    // lexical match is allowed; there is deliberately NO "head" fallback for unrelated questions.
    if ($intent['pages']) {
        $mode = 'pages';
        $st = $pdo->prepare("SELECT id,attachment_id,page_start,page_end,idx,content FROM doc_chunks WHERE attachment_id IN ($ph) AND page_end>=? AND page_start<=? ORDER BY attachment_id,idx LIMIT 60");
        $st->execute(array_merge($ids, array($intent['pages'][0], $intent['pages'][1])));
        $picked = $st->fetchAll(); $bestScore = $picked ? 1.0 : 0.0;
    } elseif ($intent['overview'] && $explicit) {
        $mode = 'overview';
        $st = $pdo->prepare("SELECT id,attachment_id,page_start,page_end,idx,content FROM doc_chunks WHERE attachment_id IN ($ph) ORDER BY attachment_id,idx");
        $st->execute($ids); $all = $st->fetchAll(); $by = array();
        foreach ($all as $c) $by[(int)$c['attachment_id']][] = $c;
        $per = max(1500, (int)($budget / max(1, count($by))));
        foreach ($by as $list) {
            if (!$list) continue;
            $avg = max(300, (int)(array_sum(array_map(function ($c) { return mb_strlen($c['content']); }, $list)) / count($list)));
            $n = max(1, min(count($list), (int)floor($per / $avg)));
            if ($n >= count($list)) { $picked = array_merge($picked, $list); continue; }
            $step = (count($list) - 1) / max(1, $n - 1);
            for ($i = 0; $i < $n; $i++) $picked[] = $list[(int)round($i * $step)];
        }
        $bestScore = $picked ? 1.0 : 0.0;
    } else {
        $fq = doc_ft_query($terms);
        if ($fq !== '') {
            try {
                $st = $pdo->prepare("SELECT id,attachment_id,page_start,page_end,idx,content, MATCH(content) AGAINST (? IN BOOLEAN MODE) AS sc
                    FROM doc_chunks WHERE attachment_id IN ($ph) AND MATCH(content) AGAINST (? IN BOOLEAN MODE) ORDER BY sc DESC LIMIT 40");
                $st->execute(array_merge(array($fq), $ids, array($fq)));
                $picked = $st->fetchAll();
                if ($picked) $bestScore = (float)$picked[0]['sc'];
            } catch (Throwable $e) { app_log('doc ft fail: ' . $e->getMessage()); }
        }
        if (count($picked) < 3 && $terms) {
            $st = $pdo->prepare("SELECT id,attachment_id,page_start,page_end,idx,content FROM doc_chunks WHERE attachment_id IN ($ph) ORDER BY id LIMIT 4000");
            $st->execute($ids); $sc = array();
            foreach ($st->fetchAll() as $c) {
                $low = mb_strtolower($c['content']); $score = 0; $hits = 0;
                foreach ($terms as $t) if (mb_strlen($t) >= 3 && mb_strpos($low, $t) !== false) { $score += 1; $hits++; }
                if ($score > 0) { $c['sc'] = $score; $c['_hits'] = $hits; $sc[] = $c; }
            }
            usort($sc, function ($a, $b) { return ($b['sc'] <=> $a['sc']) ?: ($b['_hits'] <=> $a['_hits']); });
            if ($sc) {
                $picked = array_slice($sc, 0, 12);
                $bestScore = max($bestScore, (float)$picked[0]['sc']);
            }
        }
    }

    // For non-explicit document questions require a genuinely strong lexical overlap.
    if (!$explicit && $mode !== 'pages' && $mode !== 'overview') {
        $queryTerms = array_values(array_filter($terms, function ($t) { return mb_strlen($t) >= 4; }));
        $top = array_slice($picked, 0, 8); $maxHits = 0; $maxRatio = 0.0;
        foreach ($top as $c) {
            $low = mb_strtolower((string)$c['content']); $hits = 0;
            foreach ($queryTerms as $t) if (mb_strpos($low, $t) !== false) $hits++;
            $maxHits = max($maxHits, $hits);
            $maxRatio = max($maxRatio, $queryTerms ? $hits / count($queryTerms) : 0.0);
        }
        // Threshold deliberately conservative: at least 2 meaningful terms and 35% overlap,
        // or a very strong 1-term exact match of a long query token.
        $strong = ($maxHits >= 2 && $maxRatio >= 0.35) || ($maxHits >= 1 && $queryTerms && max(array_map('mb_strlen', $queryTerms)) >= 10);
        if (!$strong) { $picked = array(); $bestScore = 0.0; $mode = 'none'; }
    }
    if (!$picked) { $res['ms'] = ms_since($t0); return $res; }

    $sel = array(); $used = 0;
    foreach ($picked as $c) {
        $l = mb_strlen($c['content']);
        if ($used + $l > $budget && $sel) continue;
        $sel[] = $c; $used += $l;
    }
    usort($sel, function ($a, $b) { return [$a['attachment_id'], $a['idx']] <=> [$b['attachment_id'], $b['idx']]; });
    $byDoc = array(); foreach ($sel as $c) $byDoc[(int)$c['attachment_id']][] = $c;
    $ctx = '';
    foreach ($docs as $i => $d) {
        $unit = doc_unit($d); $id = (int)$d['id'];
        if (empty($byDoc[$id])) continue; // source list = only documents actually used in final context
        $head = '=== Dokumen: ' . $d['original_name'] . ($d['pages'] ? ' (' . $d['pages'] . ' ' . ($unit === 'hal.' ? 'halaman' : ($unit === 'slide' ? 'slide' : 'bagian')) . ')' : '') . ' ===';
        $ctx .= $head . "\n"; $pgs = array();
        foreach ($byDoc[$id] as $c) {
            $lbl = ($c['page_start'] == $c['page_end']) ? $c['page_start'] : $c['page_start'] . '–' . $c['page_end'];
            $ctx .= '(' . $unit . ' ' . $lbl . ') ' . $c['content'] . "\n";
            for ($pg = (int)$c['page_start']; $pg <= (int)$c['page_end']; $pg++) $pgs[] = $pg;
        }
        $res['sources'][] = array('type' => 'doc', 'title' => $d['original_name'], 'pages' => doc_pages_label($pgs, $unit), 'att' => $id);
        $res['docs'][] = $d;
    }
    $res['ctx'] = $ctx; $res['mode'] = $mode; $res['chunks'] = count($sel); $res['relevance'] = $bestScore; $res['ms'] = ms_since($t0);
    return $res;
}

