<?php
declare(strict_types=1);
/**
 * WanSQ · Image generation & editing (capability terpisah dari Vision).
 * Provider dikonfigurasi lewat IMAGE_PROVIDER (lihat config.local.example.php). Tanpa konfigurasi → kapabilitas OFF
 * dan UI tidak menampilkan tombol aktif. Catatan: modul ini belum dapat diuji terhadap provider sungguhan di lingkungan build.
 */
function imggen_provider(): string {
    $p = strtolower(trim((string)IMAGE_PROVIDER));
    if ($p === 'off' || $p === 'none' || $p === 'disabled') return '';
    if ($p === '' && defined('OPENROUTER_API_KEY') && OPENROUTER_API_KEY !== '') return 'openrouter';
    return $p;
}
/** Nilai konfigurasi tidak valid (mis. teks placeholder "gpt-image-1 / dall-e-3") diabaikan agar tidak merusak panggilan. */
function imggen_model(string $default): string {
    $m = trim((string)IMAGE_MODEL);
    return ($m !== '' && preg_match('~^[A-Za-z0-9][A-Za-z0-9._:/@-]{1,100}$~', $m)) ? $m : $default;
}
function imggen_base(): string {
    $b = trim((string)IMAGE_BASE);
    return preg_match('~^https://[A-Za-z0-9.-]+(:\d+)?(/[A-Za-z0-9._~/-]*)?$~', $b) ? rtrim($b, '/') : 'https://api.openai.com/v1';
}
function imggen_caps(): array {
    $p = imggen_provider(); $hasKey = IMAGE_API_KEY !== '';
    $gen = ($p === 'pollinations') || ($p === 'openrouter') || (in_array($p, array('gemini', 'openai'), true) && $hasKey);
    $edit = ($p === 'openrouter') || (in_array($p, array('gemini', 'openai'), true) && $hasKey);
    return array('gen' => $gen, 'edit' => $edit, 'provider_set' => $p !== '');
}
function imggen_http(string $url, array $opt): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, $opt + array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 120, CURLOPT_CONNECTTIMEOUT => 10));
    $raw = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $ct = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE); $err = curl_error($ch); curl_close($ch);
    return array($raw === false ? '' : (string)$raw, $http, $ct, $err);
}
/** @return array ok, bytes, mime, err, ms */
function imggen_run(string $prompt, ?string $editPath = null): array {
    $t0 = microtime(true); $caps = imggen_caps();
    $fail = function (string $e) use ($t0) { return array('ok' => false, 'bytes' => '', 'mime' => '', 'err' => $e, 'ms' => ms_since($t0)); };
    if ($editPath !== null && !$caps['edit']) return $fail('Pengeditan gambar belum dikonfigurasi');
    if ($editPath === null && !$caps['gen']) return $fail('Pembuatan gambar belum dikonfigurasi');
    $p = imggen_provider();
    try {
        if ($p === 'openrouter') {
            $model = imggen_model('google/gemini-2.5-flash-image');
            $content = array(array('type' => 'text', 'text' => $prompt));
            if ($editPath !== null) {
                $m = (new finfo(FILEINFO_MIME_TYPE))->file($editPath) ?: 'image/png';
                $content[] = array('type' => 'image_url', 'image_url' => array('url' => 'data:' . $m . ';base64,' . base64_encode((string)file_get_contents($editPath))));
            }
            $hdr = groq_headers(false);
            list($raw, $http, , $cerr) = imggen_http(rtrim(groq_base(), '/') . '/chat/completions', array(CURLOPT_POST => 1, CURLOPT_HTTPHEADER => $hdr,
                CURLOPT_POSTFIELDS => json_encode(array('model' => $model, 'modalities' => array('image', 'text'), 'messages' => array(array('role' => 'user', 'content' => $content))), JSON_UNESCAPED_UNICODE)));
            $j = json_decode($raw, true);
            if (!is_array($j)) return $fail($cerr ?: 'Respons provider gambar tidak valid');
            if (isset($j['error'])) return $fail(is_array($j['error']) ? (string)($j['error']['message'] ?? 'Error provider gambar') : (string)$j['error']);
            foreach (($j['choices'][0]['message']['images'] ?? array()) as $im) {
                $u = (string)($im['image_url']['url'] ?? ($im['url'] ?? ''));
                if (preg_match('~^data:(image/[a-z0-9.+-]+);base64,(.+)$~is', $u, $mm)) {
                    $bytes = base64_decode($mm[2], true);
                    if ($bytes !== false && $bytes !== '') return array('ok' => true, 'bytes' => $bytes, 'mime' => strtolower($mm[1]), 'err' => null, 'ms' => ms_since($t0));
                }
            }
            return $fail('Model tidak mengembalikan gambar (mungkin diblokir kebijakan konten atau model tidak mendukung gambar). Ubah deskripsi lalu coba lagi.');
        }
        if ($p === 'gemini') {
            $model = imggen_model('gemini-2.5-flash-image');
            $parts = array(array('text' => $prompt));
            if ($editPath !== null) $parts[] = array('inline_data' => array('mime_type' => (new finfo(FILEINFO_MIME_TYPE))->file($editPath) ?: 'image/jpeg', 'data' => base64_encode((string)file_get_contents($editPath))));
            list($raw, $http, , $cerr) = imggen_http('https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent', array(
                CURLOPT_POST => 1, CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'x-goog-api-key: ' . IMAGE_API_KEY),
                CURLOPT_POSTFIELDS => json_encode(array('contents' => array(array('parts' => $parts)), 'generationConfig' => array('responseModalities' => array('TEXT', 'IMAGE'))))));
            $j = json_decode($raw, true);
            if (!is_array($j)) return $fail($cerr ?: 'Respons provider gambar tidak valid');
            if (isset($j['error'])) return $fail((string)($j['error']['message'] ?? 'Error provider gambar'));
            foreach (($j['candidates'][0]['content']['parts'] ?? array()) as $pt) {
                $d = $pt['inlineData'] ?? ($pt['inline_data'] ?? null);
                if ($d && !empty($d['data'])) return array('ok' => true, 'bytes' => base64_decode((string)$d['data']), 'mime' => (string)($d['mimeType'] ?? $d['mime_type'] ?? 'image/png'), 'err' => null, 'ms' => ms_since($t0));
            }
            return $fail('Provider tidak mengembalikan gambar (mungkin diblokir kebijakan konten). Ubah deskripsi lalu coba lagi.');
        }
        if ($p === 'openai') {
            $base = imggen_base(); $model = imggen_model('gpt-image-1');
            if ($editPath !== null) {
                list($raw, $http, , $cerr) = imggen_http($base . '/images/edits', array(CURLOPT_POST => 1,
                    CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . IMAGE_API_KEY),
                    CURLOPT_POSTFIELDS => array('model' => $model, 'prompt' => $prompt, 'image' => new CURLFile($editPath, (new finfo(FILEINFO_MIME_TYPE))->file($editPath) ?: 'image/png', 'image.png'))));
            } else {
                list($raw, $http, , $cerr) = imggen_http($base . '/images/generations', array(CURLOPT_POST => 1,
                    CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . IMAGE_API_KEY, 'Content-Type: application/json'),
                    CURLOPT_POSTFIELDS => json_encode(array('model' => $model, 'prompt' => $prompt, 'n' => 1, 'size' => '1024x1024'))));
            }
            $j = json_decode($raw, true);
            if (!is_array($j)) return $fail($cerr ?: 'Respons provider gambar tidak valid');
            if (isset($j['error'])) return $fail(is_array($j['error']) ? (string)($j['error']['message'] ?? 'Error provider gambar') : (string)$j['error']);
            $d = $j['data'][0] ?? array();
            if (!empty($d['b64_json'])) return array('ok' => true, 'bytes' => base64_decode((string)$d['b64_json']), 'mime' => 'image/png', 'err' => null, 'ms' => ms_since($t0));
            if (!empty($d['url']) && preg_match('~^https://~', (string)$d['url'])) {
                list($img, $h2, $ct) = imggen_http((string)$d['url'], array());
                if ($h2 === 200 && $img !== '') return array('ok' => true, 'bytes' => $img, 'mime' => $ct ?: 'image/png', 'err' => null, 'ms' => ms_since($t0));
            }
            return $fail('Provider tidak mengembalikan gambar');
        }
        if ($p === 'pollinations') {
            list($img, $h, $ct, $cerr) = imggen_http('https://image.pollinations.ai/prompt/' . rawurlencode(mb_substr($prompt, 0, 900)) . '?width=1024&height=1024&nologo=true', array(CURLOPT_FOLLOWLOCATION => 1));
            if ($h === 200 && strpos($ct, 'image/') === 0) return array('ok' => true, 'bytes' => $img, 'mime' => $ct, 'err' => null, 'ms' => ms_since($t0));
            return $fail($cerr ?: ('Layanan gambar gratis tidak tersedia (HTTP ' . $h . ')'));
        }
    } catch (Throwable $e) { return $fail($e->getMessage()); }
    return $fail('Provider gambar tidak dikenal');
}
/** Simpan bytes gambar ke storage privat + baris attachments. Return id lampiran. */
function imggen_store(int $uid, int $convId, int $msgId, string $bytes, string $mime, string $name): int {
    $ext = strpos($mime, 'jpeg') !== false ? 'jpg' : (strpos($mime, 'webp') !== false ? 'webp' : 'png');
    $day = date('Y/m'); $dir = STORAGE_DIR . '/att/' . $day; if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $file = bin2hex(random_bytes(10)) . '.' . $ext; file_put_contents($dir . '/' . $file, $bytes);
    db()->prepare("INSERT INTO attachments (user_id,message_id,conversation_id,kind,original_name,stored_path,mime,size,status,generated) VALUES (?,?,?,'image',?,?,?,?,'ready',1)")
        ->execute(array($uid, $msgId, $convId, $name, 'att/' . $day . '/' . $file, $mime, strlen($bytes)));
    return (int)db()->lastInsertId();
}
/** Niat pembuatan/pengeditan gambar dari bahasa alami (heuristik ketat agar tidak salah rute). */
function imggen_intent(string $t, bool $hasImage, bool $hasPrev = false): string {
    $t = mb_strtolower(trim($t));
    if (($hasImage || $hasPrev) && preg_match('/\b(hilangkan|hapus|buang|ganti|ubah|edit|jadikan|tambahkan|remove|change|make it|turn (it|this) into|replace)\b.{0,60}\b(background|latar|warna|gaya|style|pencahayaan|lighting|objek|gambar|foto|image|photo)\b/u', $t)) return 'edit';
    if ($hasImage) return '';
    if (preg_match('/^(tolong\s+)?(buat(kan)?|bikin(kan)?|generate|create|draw|gambar(kan)?|lukis(kan)?|ilustrasi(kan)?|desain(kan)?)\b.{0,80}\b(gambar|ilustrasi|poster|logo|infografik|lukisan|foto|image|illustration|picture|infographic|wallpaper|ikon|icon)\b/u', $t)) return 'generate';
    if (preg_match('/^(gambar(kan)?|lukis(kan)?|ilustrasi(kan)?|draw|paint)\s+\S+/u', $t) && mb_strlen($t) < 200 && !preg_match('/\b(jelaskan|apa|mengapa|bagaimana|analisis)\b/u', $t)) return 'generate';
    return '';
}

/**
 * Lanjutan permintaan gambar ("tidak bisakah kamu yang membuatnya?", "coba lagi", "buatkan saja").
 * Return prompt gabungan bila pesan ini melanjutkan permintaan gambar sebelumnya, atau null.
 * $recent = daftar pesan terbaru (role, content, meta) urut lama→baru, TANPA pesan saat ini.
 */
function imggen_followup(string $t, array $recent): ?string {
    $t = mb_strtolower(trim($t));
    if ($t === '' || mb_strlen($t) > 140) return null;
    $cont = preg_match('/^(kalau begitu\s+|ya\s+|oke\s+|ok\s+|tolong\s+|dong\s+)*((tidak|nggak|gak|ga|bisa)\s*(bisa(kah)?\s+)?)?(kamu|anda|lu|kau)?\s*(yang\s+)?(saja\s+|aja\s+)?(buat(kan)?|bikin(kan)?|generate|gambar(kan)?|lukis(kan)?)(\s*(nya|saja|aja|dong|ya|sendiri|langsung))*\s*[?!.\/]*$/u', $t)
        || preg_match('/(tidak|nggak|gak|ga)\s*bisa(kah)?\s+(kamu\s+)?(yang\s+)?(membuat|buat|bikin|menggambar|melukis)(kan)?(nya)?/u', $t)
        || preg_match('/^(bisa(kah)?\s+)?(kamu\s+)?(yang\s+)?(membuat|menggambar|melukis)(kan)?nya/u', $t)
        || preg_match('/^(can|could) you (just )?(make|create|draw|generate)( it| that| one)?( for me)?\??$/u', $t)
        || preg_match('/^(make|generate|create|draw) it( yourself)?\??$/u', $t)
        || preg_match('/^(coba lagi|ulangi|buat lagi|bikin lagi|versi lain|yang lain|variasi lain|try again|another one|again)[\s?!.]*$/u', $t);
    if (!$cont) return null;
    // cari permintaan gambar terakhir (user) dalam 6 pesan terakhir
    for ($i = count($recent) - 1, $n = 0; $i >= 0 && $n < 6; $i--, $n++) {
        $m = $recent[$i];
        if (($m['role'] ?? '') !== 'user') continue;
        $c = trim((string)($m['content'] ?? ''));
        if ($c === '') continue;
        if (imggen_intent($c, false) === 'generate') return $c;
        if (preg_match('/\b(gambar|ilustrasi|poster|logo|lukisan|foto|image|picture|illustration|wallpaper|ikon|icon)\b/u', mb_strtolower($c)) && mb_strlen($c) < 400) return $c;
        // pesan user terakhir tanpa kata gambar: hanya dipakai bila asisten sebelumnya menyebut tidak bisa membuat gambar / menawarkan prompt
        $next = $recent[$i + 1] ?? null;
        if ($next && ($next['role'] ?? '') === 'assistant' && preg_match('/\b(gambar|image|prompt)\b/u', mb_strtolower((string)$next['content'])) && mb_strlen($c) < 300) return $c;
        return null;
    }
    return null;
}
