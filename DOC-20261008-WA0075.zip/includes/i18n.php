<?php
declare(strict_types=1);
/** WanSQ · Localization. Kamus di assets/lang/{id,en}.json (satu sumber untuk PHP & JS). */
function i18n_dict(string $lang): array {
    static $cache = array();
    if (!in_array($lang, array('id', 'en'), true)) $lang = 'id';
    if (!isset($cache[$lang])) {
        $j = json_decode((string)@file_get_contents(__DIR__ . '/../assets/lang/' . $lang . '.json'), true);
        $cache[$lang] = is_array($j) ? $j : array();
    }
    return $cache[$lang];
}
function i18n_lang(?array $user): string {
    $l = (string)($user['ui_lang'] ?? 'id');
    return in_array($l, array('id', 'en'), true) ? $l : 'id';
}
function tr(string $key, ?string $lang = null): string {
    $lang = $lang ?: ($GLOBALS['WAN_LANG'] ?? 'id');
    $d = i18n_dict($lang);
    if (isset($d[$key]) && is_string($d[$key])) return $d[$key];
    $d = i18n_dict('id');
    return isset($d[$key]) && is_string($d[$key]) ? $d[$key] : $key;
}
function trh(string $key): string { return htmlspecialchars(tr($key), ENT_QUOTES, 'UTF-8'); }
