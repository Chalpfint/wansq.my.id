<?php
declare(strict_types=1);
/** Capability map (server-side). UI hanya mengaktifkan fitur yang benar-benar tersedia. */
require_once __DIR__ . '/imagegen.php';
function caps_build(): array {
    $ig = imggen_caps();
    return array(
        'vision'     => llm_available('vision', false),
        'ocr'        => llm_available('vision', false),
        'image_gen'  => $ig['gen'],
        'image_edit' => $ig['edit'],
        'web'        => TAVILY_API_KEY !== '' ? 'tavily' : 'basic',
        'code_remote'=> PISTON_API_URL !== '',
        'share'      => (bool)SHARE_ENABLED,
        'followups'  => (bool)FOLLOWUPS_ENABLED,
        'max_attach' => MAX_ATTACH, 'max_images' => MAX_IMAGES,
        'ocr_max_pages' => OCR_MAX_PAGES,
        'model_matrix' => array(
            'chat' => llm_chain('chat'),
            'vision' => llm_chain('vision'),
            'fast' => llm_chain('fast'),
        ),
        'active_models' => array(
            'chat' => llm_chain('chat')[0] ?? null,
            'vision' => llm_chain('vision')[0] ?? null,
            'fast' => llm_chain('fast')[0] ?? null,
        ),
    );
}
