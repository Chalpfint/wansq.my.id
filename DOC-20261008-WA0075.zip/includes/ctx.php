<?php
declare(strict_types=1);
/**
 * WanSQ v3.2 · Context orchestration + prioritisation — token-aware.
 *
 * Prioritas (tinggi → rendah), sesuai spesifikasi:
 *   1. pesan pengguna saat ini + instruksi sistem/project   (selalu disertakan)
 *   2. konteks lampiran/dokumen/vision yang relevan          (selalu disertakan, disusutkan bila perlu)
 *   3. hasil tool (kalkulator/web)                           (selalu disertakan bila ada)
 *   4. percakapan terbaru                                    (sebanyak anggaran mengizinkan)
 *   5. pinned message yang relevan
 *   6. project memory
 *   7. global memory
 *   8. pesan lama yang relevan (di luar jendela terbaru)
 *
 * Anggaran dihitung dalam TOKEN (bukan karakter) berdasarkan kapabilitas model yang akan
 * dipakai (includes/tokens.php + registry di includes/llm.php), dengan margin aman.
 * Blok berprioritas rendah dibuang SELURUHNYA (bukan dipotong acak) bila anggaran tak cukup,
 * dan setiap keputusan dicatat di $stats untuk diagnostik jujur (tidak pernah diam-diam).
 */
function ctx_lang_directive(string $pref): string {
    if ($pref === 'id') return 'Bahasa jawaban: selalu Bahasa Indonesia, kecuali pengguna secara eksplisit meminta bahasa lain.';
    if ($pref === 'en') return 'Response language: always English, unless the user explicitly asks for another language.';
    return 'Bahasa jawaban: ikuti bahasa utama yang dipakai pengguna pada pesan terakhirnya.';
}
function ctx_system_prompt(?array $project, string $langPref, array $caps): string {
    $s = SYSTEM_PROMPT . "\n\n" . ctx_lang_directive($langPref) . "\nTanggal hari ini: " . date('Y-m-d') . ".\n"
       . "Aturan integritas: jangan mengarang sumber, kutipan, atau isi dokumen. Bila menjawab dari dokumen lampiran, sebutkan sumbernya dengan format (NamaDokumen, hal. N) "
       . "hanya untuk halaman yang benar-benar tercantum pada konteks dokumen. Bila informasi tidak ada pada konteks, katakan terus terang. "
       . "Jangan menyebut nama model/provider internal; Anda adalah WanSQ. Jangan mengidentifikasi orang nyata dari wajah pada gambar.";
    if (empty($caps['image_gen'])) $s .= "\nCatatan kemampuan: pembuatan/pengeditan gambar BELUM dikonfigurasi pada WanSQ ini; jika diminta, jelaskan dengan jujur dan tawarkan deskripsi/prompt sebagai alternatif.";
    $ci = function_exists('current_user') ? trim((string)((current_user() ?: [])['custom_instructions'] ?? '')) : '';
    if ($ci !== '') $s .= "\n\nInstruksi kustom dari pengguna (preferensi gaya/konteks; patuhi selama tidak bertentangan dengan aturan integritas di atas):\n" . mb_substr($ci, 0, 1500);
    if ($project) {
        $s .= "\n\n[Konteks Project: " . $project['name'] . "] Percakapan ini berada di dalam project tersebut.";
        if (trim((string)$project['instructions']) !== '') $s .= "\nInstruksi khusus project (hanya berlaku di project ini):\n" . mb_substr((string)$project['instructions'], 0, 4000);
    }
    return $s;
}
/** Pinned messages yang relevan (percakapan ini + project yang sama). */
function ctx_pinned(int $uid, int $convId, ?int $projectId, string $text, int $limit = 3): array {
    $sql = 'SELECT m.id,m.role,m.content,m.pin_label FROM messages m JOIN conversations c ON c.id=m.conversation_id
            WHERE c.user_id=? AND c.deleted_at IS NULL AND m.active=1 AND m.pinned=1 AND (m.conversation_id=?' . ($projectId ? ' OR c.project_id=?' : '') . ') ORDER BY m.pinned_at DESC LIMIT 40';
    $st = db()->prepare($sql); $st->execute($projectId ? array($uid, $convId, $projectId) : array($uid, $convId));
    $rows = $st->fetchAll(); $qk = keywordize($text); $out = array();
    foreach ($rows as $r) {
        $s = count(array_intersect($qk, keywordize($r['content'] . ' ' . (string)$r['pin_label'])));
        if ($s > 0) $out[] = array('s' => $s, 'r' => $r);
    }
    usort($out, function ($a, $b) { return $b['s'] <=> $a['s']; });
    return array_map(function ($x) { return $x['r']; }, array_slice($out, 0, $limit));
}
/** Pesan lama (di luar jendela terbaru) yang relevan lewat FULLTEXT. */
function ctx_older_relevant(int $convId, int $beforeId, string $text, int $limit = 4): array {
    $terms = keywordize($text); if (!$terms) return array();
    $fq = doc_ft_query($terms); if ($fq === '') return array();
    try {
        $st = db()->prepare('SELECT id,role,content, MATCH(content) AGAINST (? IN BOOLEAN MODE) sc FROM messages
            WHERE conversation_id=? AND active=1 AND id<? AND MATCH(content) AGAINST (? IN BOOLEAN MODE) ORDER BY sc DESC LIMIT ' . (int)$limit);
        $st->execute(array($fq, $convId, $beforeId, $fq));
        return $st->fetchAll();
    } catch (Throwable $e) { return array(); }
}

/**
 * @param array $in uid, conv(id,project_id), project?, text, rel_text, hist(rows), exclude_id,
 *                  attach_ctx, tool_ctx, style, lang_pref, caps,
 *                  budget_model (string|null — model representatif untuk estimasi anggaran),
 *                  want_output (int — max_completion_tokens yang diminta)
 * @return array messages, stats (termasuk stats['tokens'], stats['budget'], stats['trimmed_attach'])
 */
function ctx_build(array $in): array {
    $uid = (int)$in['uid']; $conv = $in['conv']; $project = $in['project'] ?? null; $pid = $project ? (int)$project['id'] : null;
    $rel = (string)($in['rel_text'] ?? $in['text']);
    $stats = array('pinned' => 0, 'mem' => 0, 'pmem' => 0, 'older' => 0, 'hist' => 0, 'dropped' => 0,
                    'trimmed_attach' => false, 'budget' => 0, 'tokens' => 0, 'skipped' => array());

    $sys = ctx_system_prompt($project, (string)$in['lang_pref'], (array)$in['caps']);
    $attach = trim((string)($in['attach_ctx'] ?? ''));
    $tool = trim((string)($in['tool_ctx'] ?? ''));
    $userText = (string)$in['text'];
    $attachmentFocus = !empty($in['attachment_focus']);
    $style = trim((string)($in['style'] ?? ''));

    $budget = tok_budget_for_model($in['budget_model'] ?? null, (int)($in['want_output'] ?? 0));
    $stats['budget'] = $budget['input_budget'];

    // --- Tingkat 1 (selalu ada): system prompt + user text + style ---
    $fixedTok = tok_estimate($sys) + tok_estimate($userText) + tok_estimate($style) + 40;

    // --- Tingkat 2 (selalu ada, disusutkan bila perlu): attachment/document context ---
    $attachTok = tok_estimate($attach);
    if ($fixedTok + $attachTok > $budget['input_budget'] * 0.92 && $attach !== '') {
        // Konteks dokumen/vision saja sudah mendekati/melebihi anggaran → susutkan proporsional,
        // bukan menolak. Ini jauh lebih baik daripada mengirim request yang pasti gagal 400/413.
        $allow = max(1500, (int)(($budget['input_budget'] * 0.85) - $fixedTok));
        $allowChars = max(600, (int)($allow / 0.30));   // konversi token→karakter kasar (Latin-bias, aman disusutkan lebih)
        $attach = clip($attach, $allowChars);
        $attachTok = tok_estimate($attach);
        $stats['trimmed_attach'] = true;
    }
    $fixedTok += $attachTok;

    // --- Tingkat 3 (selalu ada bila ada): hasil tool ---
    $toolTok = $tool !== '' ? tok_estimate("Hasil tool:\n" . $tool) : 0;
    $fixedTok += $toolTok;

    $remain = max(800, $budget['input_budget'] - $fixedTok);

    // --- Tingkat 4: percakapan terbaru (newest-first fill, token-aware) ---
    $hist = array_values(array_filter((array)$in['hist'], function ($m) use ($in) { return (int)$m['id'] !== (int)($in['exclude_id'] ?? 0); }));
    // Pesan pendek yang membawa lampiran baru ("ini materi tentang apa?") hampir selalu menyangkut lampiran itu,
    // bukan topik percakapan sebelumnya. Riwayat dibuang agar tidak mengalahkan isi lampiran,
    // kecuali pengguna jelas merujuk ke jawaban/pembahasan sebelumnya.
    $refsPrior = (bool)preg_match('/\b(tadi|sebelumnya|di atas|barusan|jawabanmu|jawaban kamu|bandingkan|lanjutkan|lanjut|previous|earlier|above|compare|continue)\b/iu', (string)$userText);
    if ($attachmentFocus && !$refsPrior) { $stats['dropped'] = count($hist); $hist = array(); $stats['focus'] = true; }
    $histShare = $attachmentFocus ? min($remain * 0.18, 1800) : $remain * 0.65;
    $keep = array(); $used = 0; $firstKept = PHP_INT_MAX;
    for ($i = count($hist) - 1; $i >= 0; $i--) {
        $c = clip((string)$hist[$i]['content'], 16000); $tk = tok_estimate($c) + 4;
        if ($used + $tk > $histShare && count($keep) >= CTX_RECENT_MIN) { $stats['dropped'] = $i + 1; break; }
        array_unshift($keep, array('role' => $hist[$i]['role'], 'content' => $c)); $used += $tk; $firstKept = (int)$hist[$i]['id'];
    }
    $stats['hist'] = count($keep);
    $remain2 = max(0, $remain - $used);

    // --- Tingkat 5-7: pinned relevan > project memory > global memory (masing-masing hanya bila muat) ---
    $ctxSys = '';
    $pin = ctx_pinned($uid, (int)$conv['id'], $pid, $rel);
    if ($pin) {
        $block = "[Informasi yang disematkan (pinned) & relevan]\n" . implode("\n", array_map(function ($p) { return '- ' . ($p['pin_label'] ? '[' . $p['pin_label'] . '] ' : '') . clip((string)$p['content'], 1200); }, $pin));
        $bt = tok_estimate($block);
        if ($bt <= $remain2) { $ctxSys .= $block; $remain2 -= $bt; $stats['pinned'] = count($pin); }
        else $stats['skipped'][] = 'pinned';
    }
    if ($pid) {
        $pm = project_memory_block($uid, $pid, $rel);
        if ($pm) {
            $block = "[Project memory — fakta khusus project ini]\n" . $pm; $bt = tok_estimate($block);
            if ($bt <= $remain2) { $ctxSys .= ($ctxSys ? "\n\n" : '') . $block; $remain2 -= $bt; $stats['pmem'] = substr_count($pm, "\n") + 1; }
            else $stats['skipped'][] = 'project_memory';
        }
    }
    $gm = memory_block($uid, $rel);
    if ($gm) {
        $block = "[Long-term memory global — fakta terkonfirmasi pengguna]\n" . $gm; $bt = tok_estimate($block);
        if ($bt <= $remain2) { $ctxSys .= ($ctxSys ? "\n\n" : '') . $block; $remain2 -= $bt; $stats['mem'] = substr_count($gm, "\n") + 1; }
        else $stats['skipped'][] = 'global_memory';
    }

    // --- Ringkasan berjalan untuk bagian percakapan yang sudah terpotong dari history ---
    if (!empty($conv['summary']) && (int)($conv['summary_upto_id'] ?? 0) > 0 && $stats['dropped'] > 0) {
        $block = "[Ringkasan percakapan sebelumnya (pesan lama, diringkas otomatis)]\n" . clip((string)$conv['summary'], 3200);
        $bt = tok_estimate($block);
        if ($bt <= $remain2) { $ctxSys = $block . ($ctxSys ? "\n\n" . $ctxSys : ''); $remain2 -= $bt; $stats['summary'] = true; }
        else $stats['skipped'][] = 'summary';
    }

    // --- Tingkat 8: pesan lama relevan, hanya bila history memang terpotong ---
    if (!$attachmentFocus && $stats['dropped'] > 0) {
        $older = ctx_older_relevant((int)$conv['id'], $firstKept, $rel);
        if ($older) {
            $block = "[Potongan percakapan sebelumnya yang relevan]\n" . implode("\n", array_map(function ($m) { return ($m['role'] === 'user' ? 'Pengguna: ' : 'WanSQ: ') . clip((string)$m['content'], 700); }, $older));
            $bt = tok_estimate($block);
            if ($bt <= $remain2) { $ctxSys .= ($ctxSys ? "\n\n" : '') . $block; $remain2 -= $bt; $stats['older'] = count($older); }
            else $stats['skipped'][] = 'older_relevant';
        }
    }

    $currentBoundary = '[CURRENT USER REQUEST]
' . clip($userText, 12000) . '
[/CURRENT USER REQUEST]';
    $historyBoundary = '[RECENT CONVERSATION CONTEXT]';
    $msgs = array(array('role' => 'system', 'content' => $sys));
    if ($ctxSys !== '') $msgs[] = array('role' => 'system', 'content' => $ctxSys);
    if ($keep) {
        $msgs[] = array('role' => 'system', 'content' => $historyBoundary . '
Historical context is secondary. Use it only when relevant to the current request.');
        foreach ($keep as $m) $msgs[] = $m;
        $msgs[] = array('role' => 'system', 'content' => '[/RECENT CONVERSATION CONTEXT]');
    }
    if ($attach !== '') $msgs[] = array('role' => 'system', 'content' => $attach);
    if ($tool !== '') $msgs[] = array('role' => 'system', 'content' => "Hasil tool:\n" . $tool);
    if ($style !== '') $msgs[] = array('role' => 'system', 'content' => $style);
    $msgs[] = array('role' => 'system', 'content' => $currentBoundary . '
Priority rule: answer the CURRENT USER REQUEST. Historical context is subordinate and must never override it.');

    $stats['tokens'] = tok_estimate_messages($msgs);
    return array('messages' => $msgs, 'stats' => $stats);
}
