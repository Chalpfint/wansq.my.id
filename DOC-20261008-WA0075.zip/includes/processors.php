<?php
declare(strict_types=1);
/**
 * WanSQ 3.2.4 · Registri prosesor dokumen.
 * Setiap prosesor mengubah file menjadi "halaman" teks (urut baca) + profil data opsional.
 * Return: ['ok'=>bool,'pages'=>[n=>text],'engine'=>string,'profile'=>string,'unit'=>string,'error'=>string]
 */
function proc_code_exts(): array {
    return array('py','js','mjs','ts','tsx','jsx','php','java','kt','c','h','cpp','hpp','cs','go','rs','rb','swift','sql','css','scss','sh','bat','ps1','r','lua','dart','vue','ini','toml','env','conf','cfg');
}
function proc_supported_exts(): array {
    return array_merge(array('pdf','docx','xlsx','pptx','txt','md','csv','tsv','json','log','xml','yaml','yml','html','htm','rtf'), proc_code_exts());
}
function proc_accept_attr(): string { return implode(',', array_map(function ($e) { return '.' . $e; }, proc_supported_exts())); }
function proc_kind(string $ext): string {
    if (in_array($ext, array('xlsx','csv','tsv'), true)) return 'table';
    if ($ext === 'pptx') return 'slides';
    if (in_array($ext, proc_code_exts(), true)) return 'code';
    return 'text';
}

/** Hindari zip-bomb: batasi ukuran entri tak terkompresi. */
function proc_zip_read(ZipArchive $z, string $name, int $max = 12000000): string {
    $st = $z->statName($name);
    if (!$st || (int)$st['size'] > $max) return '';
    return (string)$z->getFromName($name);
}
function proc_xml_text(string $xml): string {
    $xml = preg_replace('~</a:p>|</w:p>|<a:br/>~', "\n", $xml);
    return trim(html_entity_decode(strip_tags((string)$xml), ENT_QUOTES | ENT_XML1, 'UTF-8'));
}

/** Parser CSV/TSV sederhana namun menghormati kutip. */
function proc_parse_delimited(string $txt, string $delim, int $maxRows = 20000): array {
    $rows = array(); $fh = fopen('php://temp', 'r+'); fwrite($fh, $txt); rewind($fh);
    while (($r = fgetcsv($fh, 0, $delim, '"', '\\')) !== false) {
        if ($r === array(null)) continue;
        $rows[] = array_map(function ($c) { return trim((string)$c); }, $r);
        if (count($rows) >= $maxRows) break;
    }
    fclose($fh);
    return $rows;
}
function proc_is_num(string $v): bool {
    $v = trim(str_replace(array(' ', "\xc2\xa0"), '', $v)); if ($v === '') return false;
    $v = preg_replace('/^[Rp$€£]+|%$/u', '', $v);
    if (preg_match('/^-?\d{1,3}(\.\d{3})+(,\d+)?$/', $v)) return true;      // 1.234.567,89
    if (preg_match('/^-?\d{1,3}(,\d{3})+(\.\d+)?$/', $v)) return true;      // 1,234,567.89
    return is_numeric($v);
}
function proc_to_num(string $v): float {
    $v = preg_replace('/^[Rp$€£]+|%$/u', '', str_replace(array(' ', "\xc2\xa0"), '', trim($v)));
    if (preg_match('/^-?\d{1,3}(\.\d{3})+(,\d+)?$/', $v)) $v = str_replace(',', '.', str_replace('.', '', $v));
    else $v = str_replace(',', '', $v);
    return (float)$v;
}
/** Profil data: ukuran, tipe kolom, null, statistik angka, nilai teratas. */
function proc_profile(array $rows, string $label): string {
    if (count($rows) < 2) return '';
    $head = $rows[0]; $data = array_slice($rows, 1); $n = count($data); $cols = count($head);
    $out = "PROFIL DATA — $label\nBaris data: $n · Kolom: $cols\n";
    for ($c = 0; $c < $cols; $c++) {
        $name = $head[$c] !== '' ? $head[$c] : 'kolom_' . ($c + 1);
        $vals = array(); $nulls = 0;
        foreach ($data as $r) { $v = trim((string)($r[$c] ?? '')); if ($v === '') $nulls++; else $vals[] = $v; }
        $nn = count($vals);
        if ($nn === 0) { $out .= "- $name: kosong semua\n"; continue; }
        $numCount = 0; foreach ($vals as $v) if (proc_is_num($v)) $numCount++;
        if ($numCount / $nn >= 0.9) {
            $nums = array(); foreach ($vals as $v) if (proc_is_num($v)) $nums[] = proc_to_num($v);
            sort($nums); $cnt = count($nums); $mean = array_sum($nums) / $cnt;
            $med = $cnt % 2 ? $nums[intdiv($cnt, 2)] : ($nums[$cnt / 2 - 1] + $nums[$cnt / 2]) / 2;
            $out .= sprintf("- %s: angka · terisi %d · kosong %d · min %s · maks %s · rata-rata %s · median %s · jumlah %s\n", $name, $nn, $nulls,
                round($nums[0], 4), round($nums[$cnt - 1], 4), round($mean, 4), round($med, 4), round(array_sum($nums), 4));
        } else {
            $freq = array_count_values($vals); arsort($freq); $top = array_slice($freq, 0, 5, true); $parts = array();
            foreach ($top as $k => $v) $parts[] = mb_substr((string)$k, 0, 30) . ' (' . $v . ')';
            $isDate = 0; foreach (array_slice($vals, 0, 50) as $v) if (preg_match('~^\d{4}-\d{2}-\d{2}|^\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}~', $v)) $isDate++;
            $type = $isDate >= min(50, $nn) * 0.8 ? 'tanggal' : 'teks';
            $out .= sprintf("- %s: %s · terisi %d · kosong %d · unik %d · teratas: %s\n", $name, $type, $nn, $nulls, count($freq), implode('; ', $parts));
        }
    }
    return $out;
}
function proc_rows_text(array $rows, int $maxChars = 600000): string {
    $t = ''; foreach ($rows as $r) { $t .= implode(" | ", $r) . "\n"; if (strlen($t) > $maxChars) { $t .= "[… dipotong]\n"; break; } }
    return $t;
}

function proc_xlsx(string $path): array {
    if (!class_exists('ZipArchive')) return array('ok' => false, 'error' => 'Ekstensi Zip PHP tidak aktif');
    $z = new ZipArchive(); if ($z->open($path) !== true) return array('ok' => false, 'error' => 'XLSX tidak dapat dibuka');
    try {
        $shared = array();
        $ss = proc_zip_read($z, 'xl/sharedStrings.xml');
        if ($ss !== '') { $x = @simplexml_load_string($ss); if ($x) foreach ($x->si as $si) { $t = ''; foreach ($si->xpath('.//*[local-name()="t"]') as $tn) $t .= (string)$tn; $shared[] = $t; } }
        $wb = @simplexml_load_string(proc_zip_read($z, 'xl/workbook.xml')); $names = array();
        if ($wb) { $wb->registerXPathNamespace('m', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'); foreach ($wb->xpath('//m:sheets/m:sheet') as $s) $names[] = (string)$s['name']; }
        $pages = array(); $profiles = array(); $si = 0;
        for ($i = 1; $i <= 40; $i++) {
            $xml = proc_zip_read($z, "xl/worksheets/sheet$i.xml"); if ($xml === '') { if ($i > 1 && $si >= count($names)) break; continue; }
            $x = @simplexml_load_string($xml); if (!$x) continue;
            $rows = array(); $x->registerXPathNamespace('m', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
            foreach ($x->xpath('//m:sheetData/m:row') as $row) {
                $r = array(); $maxc = 0;
                foreach ($row->c as $c) {
                    $ref = (string)$c['r']; $col = 0; if (preg_match('/^([A-Z]+)/', $ref, $m)) { foreach (str_split($m[1]) as $ch) $col = $col * 26 + (ord($ch) - 64); $col--; }
                    $t = (string)$c['t']; $v = (string)$c->v;
                    if ($t === 's') $v = $shared[(int)$v] ?? ''; elseif ($t === 'inlineStr') $v = (string)$c->is->t; elseif ($t === 'b') $v = $v === '1' ? 'TRUE' : 'FALSE';
                    $r[$col] = str_replace(array("\t", "\r", "\n"), ' ', trim($v)); $maxc = max($maxc, $col);
                }
                if (!$r) continue; $line = array(); for ($k = 0; $k <= $maxc; $k++) $line[] = $r[$k] ?? ''; $rows[] = $line;
                if (count($rows) >= 20000) break;
            }
            $label = $names[$si] ?? ('Sheet' . $i); $si++;
            if (!$rows) continue;
            $profiles[] = proc_profile($rows, 'sheet "' . $label . '"');
            $txt = "## Sheet: $label\n" . proc_rows_text($rows);
            foreach (doc_text_sections($txt) as $part) $pages[count($pages) + 1] = $part;
        }
        $z->close();
        if (!$pages) return array('ok' => false, 'error' => 'XLSX kosong atau tidak terbaca');
        return array('ok' => true, 'pages' => $pages, 'engine' => 'xlsx', 'profile' => trim(implode("\n\n", array_filter($profiles))), 'unit' => 'bagian');
    } catch (Throwable $e) { @$z->close(); return array('ok' => false, 'error' => 'XLSX gagal diproses'); }
}
function proc_pptx(string $path): array {
    if (!class_exists('ZipArchive')) return array('ok' => false, 'error' => 'Ekstensi Zip PHP tidak aktif');
    $z = new ZipArchive(); if ($z->open($path) !== true) return array('ok' => false, 'error' => 'PPTX tidak dapat dibuka');
    $slides = array();
    for ($i = 0; $i < $z->numFiles; $i++) { $n = (string)$z->getNameIndex($i); if (preg_match('~^ppt/slides/slide(\d+)\.xml$~', $n, $m)) $slides[(int)$m[1]] = $n; }
    ksort($slides); $pages = array();
    foreach ($slides as $num => $name) {
        $t = proc_xml_text(proc_zip_read($z, $name));
        $notes = proc_zip_read($z, "ppt/notesSlides/notesSlide$num.xml"); $nt = $notes !== '' ? proc_xml_text($notes) : '';
        $body = "Slide $num:\n" . $t . ($nt !== '' ? "\n[Catatan pembicara] " . $nt : '');
        if (trim($t . $nt) !== '') $pages[$num] = $body;
    }
    $z->close();
    if (!$pages) return array('ok' => false, 'error' => 'PPTX tidak berisi teks yang dapat dibaca');
    return array('ok' => true, 'pages' => $pages, 'engine' => 'pptx', 'profile' => '', 'unit' => 'slide');
}
function proc_html_text(string $h): string {
    $h = preg_replace('~<(script|style|noscript|svg|head)\b[^>]*>.*?</\1>~is', ' ', $h);
    $h = preg_replace('~<(br|/p|/div|/li|/tr|/h[1-6])\b[^>]*>~i', "\n", (string)$h);
    $t = html_entity_decode(strip_tags((string)$h), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return trim(preg_replace("/[ \t]+/", ' ', preg_replace("/\n{3,}/", "\n\n", $t)));
}
/** Titik masuk. $ext huruf kecil tanpa titik. */
function proc_extract(string $path, string $ext): array {
    $max = 2 * 1024 * 1024;
    switch ($ext) {
        case 'xlsx': return proc_xlsx($path);
        case 'pptx': return proc_pptx($path);
        case 'csv': case 'tsv':
            $raw = (string)file_get_contents($path, false, null, 0, $max);
            if (strncmp($raw, "\xEF\xBB\xBF", 3) === 0) $raw = substr($raw, 3);
            if (!mb_check_encoding($raw, 'UTF-8')) $raw = mb_convert_encoding($raw, 'UTF-8', 'Windows-1252');
            $delim = $ext === 'tsv' ? "\t" : ',';
            if ($ext === 'csv') { $first = (string)strtok($raw, "\n"); if (substr_count($first, ';') > substr_count($first, ',')) $delim = ';'; }
            $rows = proc_parse_delimited($raw, $delim);
            if (!$rows) return array('ok' => false, 'error' => 'File tabel kosong');
            $pages = doc_text_sections(proc_rows_text($rows));
            return array('ok' => true, 'pages' => $pages, 'engine' => $ext, 'profile' => proc_profile($rows, 'file ' . $ext), 'unit' => 'bagian');
        case 'html': case 'htm':
            $t = proc_html_text((string)file_get_contents($path, false, null, 0, $max));
            return $t === '' ? array('ok' => false, 'error' => 'HTML tidak berisi teks') : array('ok' => true, 'pages' => doc_text_sections($t), 'engine' => 'html', 'profile' => '', 'unit' => 'bagian');
        case 'rtf':
            $t = (string)file_get_contents($path, false, null, 0, $max);
            $t = preg_replace('~\\\\par[d]?~', "\n", $t); $t = preg_replace('~\{\\\\\*[^{}]*\}|\\\\[a-z]+-?\d* ?|[{}]~i', '', (string)$t);
            return trim($t) === '' ? array('ok' => false, 'error' => 'RTF kosong') : array('ok' => true, 'pages' => doc_text_sections($t), 'engine' => 'rtf', 'profile' => '', 'unit' => 'bagian');
        default:
            $t = (string)file_get_contents($path, false, null, 0, $max);
            if (!mb_check_encoding($t, 'UTF-8')) $t = mb_convert_encoding($t, 'UTF-8', 'Windows-1252');
            if (strpos(substr($t, 0, 4000), "\0") !== false) return array('ok' => false, 'error' => 'File biner tidak didukung');
            $pages = doc_text_sections($t);
            return $pages ? array('ok' => true, 'pages' => $pages, 'engine' => in_array($ext, proc_code_exts(), true) ? 'code' : 'text', 'profile' => '', 'unit' => 'bagian') : array('ok' => false, 'error' => 'File teks kosong');
    }
}
