<?php
declare(strict_types=1);
/**
 * WanSQ 3.2.4 · Ringkasan percakapan berjalan (rolling summary).
 * Pesan lama yang tidak lagi muat di konteks diringkas secara inkremental dan disimpan di conversations.summary.
 * Best-effort: kegagalan tidak pernah memengaruhi jawaban yang sudah tersimpan.
 */
function summary_enabled(): bool { return !defined('ROLLING_SUMMARY') || (bool)ROLLING_SUMMARY; }

/** Return true bila ringkasan diperbarui. */
function conv_summary_update(int $convId, int $uid): bool {
    if (!summary_enabled()) return false;
    if (function_exists('llm_budget_pressure') && llm_budget_pressure()) return false;     // hemat kredit: ringkasan dikerjakan nanti
    $pdo = db();
    $st = $pdo->prepare('SELECT summary, summary_upto_id FROM conversations WHERE id=? AND user_id=?'); $st->execute(array($convId, $uid));
    $c = $st->fetch(); if (!$c) return false;
    $keepRecent = defined('SUMMARY_KEEP_RECENT') ? (int)SUMMARY_KEEP_RECENT : 12;
    $trigger    = defined('SUMMARY_TRIGGER') ? (int)SUMMARY_TRIGGER : 24;
    $st = $pdo->prepare('SELECT id,role,content FROM messages WHERE conversation_id=? AND active=1 ORDER BY id ASC'); $st->execute(array($convId));
    $all = $st->fetchAll(); $n = count($all);
    if ($n < $trigger) return false;
    $cut = (int)$all[$n - $keepRecent - 1]['id'];                 // pesan dengan id <= $cut diringkas
    $upto = (int)$c['summary_upto_id'];
    $fresh = array_values(array_filter($all, function ($m) use ($upto, $cut) { return (int)$m['id'] > $upto && (int)$m['id'] <= $cut; }));
    if (count($fresh) < 6) return false;
    $lines = array(); $budget = 14000;
    foreach ($fresh as $m) {
        $t = trim(preg_replace('/\s+/u', ' ', (string)$m['content'])); if ($t === '') continue;
        $line = ($m['role'] === 'user' ? 'Pengguna: ' : 'WanSQ: ') . mb_substr($t, 0, 900);
        $budget -= mb_strlen($line); if ($budget < 0) break; $lines[] = $line;
    }
    $prev = trim((string)$c['summary']);
    $prompt = "Perbarui ringkasan percakapan berikut. Pertahankan fakta, keputusan, preferensi, nama, angka, file yang dibahas, dan pertanyaan yang belum terjawab. "
        . "Tulis dalam bahasa percakapan, maksimal 220 kata, poin-poin singkat, tanpa pembuka/penutup.\n\n"
        . ($prev !== '' ? "RINGKASAN SAAT INI:\n$prev\n\n" : '') . "PESAN BARU YANG PERLU DIMASUKKAN:\n" . implode("\n", $lines);
    $r = llm_call('fast', array('messages' => array(array('role' => 'user', 'content' => $prompt)), 'max_completion_tokens' => 600, 'temperature' => 0.2), 40);
    $txt = trim((string)($r['text'] ?? ''));
    if (!$r['ok'] || mb_strlen($txt) < 20) { app_log('summary skip conv=' . $convId . ' err=' . mb_substr((string)$r['err'], 0, 120)); return false; }
    db_retry(function (PDO $db) use ($txt, $cut, $convId, $uid) {
        $db->prepare('UPDATE conversations SET summary=?, summary_upto_id=?, summary_updated_at=NOW() WHERE id=? AND user_id=?')->execute(array(mb_substr($txt, 0, 4000), $cut, $convId, $uid));
    }, 'conversation_summary');
    app_log('summary updated conv=' . $convId . ' upto=' . $cut . ' msgs=' . count($fresh));
    return true;
}
