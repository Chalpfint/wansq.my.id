<?php
/**
 * WanSQ v3.2.4 Performance Optimizations
 * Add to includes/config.php or create includes/performance.php
 */

declare(strict_types=1);

// ===== DATABASE OPTIMIZATION =====

/**
 * Prepared statement cache to avoid re-parsing
 */
class OptimizedPDOWrapper {
    private static $stmtCache = [];
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Prepare with caching - reuse prepared statements
     */
    public function prepare(string $sql, array $options = []) {
        $key = md5($sql);
        if (!isset(self::$stmtCache[$key])) {
            self::$stmtCache[$key] = $this->pdo->prepare($sql, $options);
        }
        return self::$stmtCache[$key];
    }

    /**
     * N+1 Query Prevention: Load related data in single query
     */
    public function prepareIn(string $sql, array $values): PDOStatement {
        if (empty($values)) {
            // Empty list - return empty result
            return $this->pdo->prepare("SELECT * FROM (SELECT 1) WHERE 0");
        }
        $placeholders = implode(',', array_fill(0, count($values), '?'));
        $finalSql = str_replace('?', "($placeholders)", $sql);
        $stmt = $this->prepare($finalSql);
        // Flatten values for execute
        $flat = [];
        foreach ($values as $v) {
            if (is_array($v)) {
                $flat = array_merge($flat, $v);
            } else {
                $flat[] = $v;
            }
        }
        $stmt->execute($flat);
        return $stmt;
    }
}

// ===== RESPONSE OPTIMIZATION =====

/**
 * Start output buffering with compression
 */
function enable_response_compression() {
    if (!headers_sent() && extension_loaded('zlib')) {
        ob_start('ob_gzhandler');
    }
}

/**
 * Set caching headers for responses
 */
function set_cache_headers(string $cacheControl = 'private, max-age=0'): void {
    if (!headers_sent()) {
        header("Cache-Control: $cacheControl");
        header('Vary: Accept-Encoding');
    }
}

/**
 * Send SSE event with optimized payload
 */
function send_sse(array $data, bool $compress = true): void {
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    // Limit chunk size for network efficiency
    if (strlen($json) > 4096) {
        $json = substr($json, 0, 4096);
    }

    echo "data: $json\n\n";

    // Flush every 10KB to prevent buffer bloat
    if (ob_get_length() > 10240) {
        ob_flush();
        flush();
    }
}

// ===== QUERY OPTIMIZATION PATTERNS =====

/**
 * Get multiple documents without N+1 queries
 */
function get_documents_optimized(PDO $pdo, array $ids): array {
    if (empty($ids)) return [];

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare(
        "SELECT doc_id, chunk_num, content, tokens, hash
         FROM doc_chunks
         WHERE doc_id IN ($placeholders)
         ORDER BY doc_id ASC, chunk_num ASC"
    );
    $st->execute($ids);

    // Group by document
    $documents = [];
    foreach ($st->fetchAll() as $row) {
        $documents[$row['doc_id']][] = $row;
    }
    return $documents;
}

/**
 * Get user data with minimal queries
 */
function get_user_profile_optimized(PDO $pdo, int $userId): ?array {
    $st = $pdo->prepare(
        "SELECT u.id, u.email, u.name, u.avatar, u.tier, u.created_at,
                COUNT(DISTINCT c.id) as chat_count,
                COUNT(DISTINCT a.id) as attachment_count
         FROM users u
         LEFT JOIN conversations c ON c.user_id = u.id AND c.deleted_at IS NULL
         LEFT JOIN attachments a ON a.user_id = u.id AND a.deleted_at IS NULL
         WHERE u.id = ?
         GROUP BY u.id"
    );
    $st->execute([$userId]);
    return $st->fetch() ?: null;
}

// ===== MEMORY OPTIMIZATION =====

/**
 * Stream large file processing instead of loading all at once
 */
function process_document_streaming(string $filePath, callable $processor): void {
    $chunkSize = 8192; // 8KB chunks
    $fp = fopen($filePath, 'rb');

    while (!feof($fp)) {
        $chunk = fread($fp, $chunkSize);
        if ($chunk === false) break;

        $processor($chunk);

        // Free memory periodically
        if (mt_rand(1, 100) === 1) {
            gc_collect_cycles();
        }
    }

    fclose($fp);
}

// ===== API RESPONSE OPTIMIZATION =====

/**
 * Cache frequently-requested data
 */
class SimpleResponseCache {
    private static $cache = [];
    private static $ttl = [];

    public static function get(string $key) {
        if (isset(self::$cache[$key])) {
            if (time() < self::$ttl[$key]) {
                return self::$cache[$key];
            }
            unset(self::$cache[$key], self::$ttl[$key]);
        }
        return null;
    }

    public static function set(string $key, $value, int $ttl = 300): void {
        self::$cache[$key] = $value;
        self::$ttl[$key] = time() + $ttl;
    }

    public static function clear(): void {
        self::$cache = [];
        self::$ttl = [];
    }
}

// ===== ERROR HANDLING OPTIMIZATION =====

/**
 * Log error with context for faster debugging
 */
function log_error_with_context(Exception $e, array $context = []): void {
    $errorData = [
        'timestamp' => gmdate('c'),
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => array_slice($e->getTrace(), 0, 3),
        'context' => $context,
        'memory_usage' => memory_get_usage(true) / 1024 / 1024 . ' MB',
    ];

    error_log(json_encode($errorData, JSON_UNESCAPED_UNICODE));
}

// ===== LAZY LOADING CONFIGURATION =====

/**
 * Define which libraries to lazy-load
 */
define('LAZY_LOAD_CONFIG', [
    'pyodide' => [
        'trigger' => 'data-requires="pyodide"',
        'src' => '/assets/vendor/pyodide/pyodide.js',
        'size' => 9.7,  // MB
    ],
    'mathjax' => [
        'trigger' => 'data-math',
        'src' => 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js',
        'size' => 1.2,
    ],
    'pdfjs' => [
        'trigger' => 'data-requires="pdfjs"',
        'src' => '/assets/vendor/pdfjs/pdf.min.js',
        'size' => 1.1,
    ],
]);

// ===== MONITORING =====

/**
 * Track performance metrics
 */
class PerformanceMonitor {
    private static $metrics = [];
    private static $startTime;

    public static function start(): void {
        self::$startTime = microtime(true);
    }

    public static function mark(string $name): void {
        self::$metrics[$name] = (microtime(true) - self::$startTime) * 1000;
    }

    public static function getMetrics(): array {
        return self::$metrics;
    }

    public static function logToHeader(): void {
        if (!headers_sent()) {
            header('X-Response-Time: ' . round(end(self::$metrics) ?? 0, 2) . 'ms');
        }
    }
}

// ===== INITIALIZATION =====

// Enable compression early
enable_response_compression();

// Start monitoring
PerformanceMonitor::start();

// Set cache headers (will be overridden per-endpoint)
set_cache_headers();
