<?php
/**
 * WanSQ 3.2.4 local configuration template.
 * Copy to includes/config.local.php or use environment variables.
 * NEVER publish the local file or place production secrets in the release ZIP.
 */
return [
    'BASE_URL' => '',
    'DB_HOST' => 'localhost',
    'DB_PORT' => '3306',
    'DB_NAME' => '',
    'DB_USER' => '',
    'DB_PASS' => '',
    'GOOGLE_CLIENT_ID' => '',
    'GOOGLE_CLIENT_SECRET' => '',
    'OPENROUTER_BASE' => 'https://openrouter.ai/api/v1',
    'OPENROUTER_API_KEY' => '',
    'OPENROUTER_REFERER' => '',
    'OPENROUTER_TITLE' => 'WanSQ',
    'GROQ_BASE' => 'https://api.groq.com/openai/v1',
    'GROQ_API_KEY' => '',
    'MODEL_CHAT' => 'openai/gpt-oss-120b',
    'MODEL_VISION' => 'qwen/qwen3.8-27b',
    'MODEL_FAST' => 'openai/gpt-oss-20b',
    'MAX_OUTPUT_TOKENS' => 12288,
    'CONTEXT_CHAR_BUDGET' => 300000,
    'TAVILY_API_KEY' => '',
    'PISTON_API_URL' => '',
];
