<?php
declare(strict_types=1);
/**
 * WanSQ v3.2 · Token-aware budget engine.
 * Karakter BUKAN proxy token yang aman untuk bahasa ber-aksara padat (mis. CJK) atau kode.
 * Estimator ini sengaja konservatif (overestimate) supaya request tidak pernah melewati
 * batas provider — lebih baik membuang konteks berprioritas rendah lebih awal daripada
 * mengirim request yang pasti ditolak.
 */

/** Estimasi token dari teks: campuran heuristik per-karakter, bukan tokenizer BPE asli. */
function tok_estimate(string $s): int {
    if ($s === '') return 0;
    $len = mb_strlen($s, 'UTF-8');
    // Proporsi karakter non-ASCII (CJK/aksara lain) memakai rasio token lebih padat (~1 token/char)
    // vs Latin (~1 token / 3.6 char). Kode/simbol (banyak non-huruf) juga lebih padat; deteksi kasar via fence.
    $nonAscii = 0; $sample = mb_substr($s, 0, min($len, 4000));
    foreach (preg_split('//u', $sample, -1, PREG_SPLIT_NO_EMPTY) as $ch) if (ord($ch[0]) > 127) $nonAscii++;
    $ratioWide = $sample !== '' ? $nonAscii / max(1, mb_strlen($sample)) : 0;
    $perChar = 0.28 + (0.72 * $ratioWide);           // 0.28 tok/char (Latin) .. up to ~1.0 (CJK-heavy)
    if (substr_count($s, '```') >= 2) $perChar = max($perChar, 0.35);   // blok kode: lebih banyak token/karakter
    return (int)ceil($len * $perChar) + 4;           // +4 margin token pembungkus role/format
}
function tok_estimate_messages(array $msgs): int {
    $t = 0;
    foreach ($msgs as $m) {
        $c = $m['content'] ?? '';
        if (is_array($c)) { foreach ($c as $part) { if (($part['type'] ?? '') === 'text') $t += tok_estimate((string)($part['text'] ?? '')); elseif (($part['type'] ?? '') === 'image_url') $t += 2048; } }
        else $t += tok_estimate((string)$c);
        $t += 4;
    }
    return $t;
}

/** Anggaran token aman untuk sebuah model: context - output_reserved - margin provider. */
function tok_budget_for_model(?string $model, int $wantOutput): array {
    $ctx = 131072; $out = $wantOutput > 0 ? $wantOutput : 8192;
    if ($model) { $c = llm_capabilities($model); if (!empty($c['context'])) $ctx = (int)$c['context']; if (!empty($c['output'])) $out = min($wantOutput ?: $c['output'], (int)$c['output']); }
    $margin = max(500, (int)($ctx * 0.03));          // margin aman ~3% (estimator token bukan tokenizer asli provider)
    $input = max(2000, $ctx - $out - $margin);
    // Prompt ikut ditagihkan dari saldo: saat kredit menipis, batasi input (jendela konteks model tidak relevan).
    if (function_exists('llm_budget_pressure') && llm_budget_pressure()) $input = min($input, max(2000, (int)(defined('PRESSURE_INPUT_TOKENS') ? PRESSURE_INPUT_TOKENS : 6000)));
    return array('context' => $ctx, 'output' => $out, 'margin' => $margin, 'input_budget' => $input);
}
