<?php
declare(strict_types=1);

function google_auth_url(): string {
    $_SESSION['oauth_state'] = bin2hex(random_bytes(16));
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
        'client_id'     => GOOGLE_CLIENT_ID,
        'redirect_uri'  => GOOGLE_REDIRECT,
        'response_type' => 'code',
        'scope'         => 'openid email profile',
        'state'         => $_SESSION['oauth_state'],
        'prompt'        => 'select_account',
    ]);
}

function google_exchange(string $code): array {
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [CURLOPT_POST => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 20,
        CURLOPT_POSTFIELDS => http_build_query([
            'code' => $code, 'client_id' => GOOGLE_CLIENT_ID, 'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri' => GOOGLE_REDIRECT, 'grant_type' => 'authorization_code'])]);
    $body = (string)curl_exec($ch);
    $cerr = curl_error($ch); curl_close($ch);
    $tok = json_decode($body, true);

    if (!$tok || empty($tok['access_token'])) {
        $gerr = '';
        if (is_array($tok)) {
            $gerr = trim(($tok['error'] ?? '') . ' — ' . ($tok['error_description'] ?? ''));
        }
        $detail = $gerr !== '' ? $gerr : ($cerr !== '' ? $cerr : 'Respons kosong dari Google (periksa koneksi/SSL server).');
        throw new RuntimeException($detail . ' [redirect_uri terkirim: ' . GOOGLE_REDIRECT . ']');
    }

    $ch = curl_init('https://www.googleapis.com/oauth2/v3/userinfo');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $tok['access_token']]]);
    $info = json_decode((string)curl_exec($ch), true);
    curl_close($ch);
    if (!$info || empty($info['sub'])) throw new RuntimeException('Userinfo gagal diambil');
    return $info;
}