<?php
declare(strict_types=1);

final class WanSQDbState { public static ?PDO $pdo = null; }

function db(): PDO {
    if (WanSQDbState::$pdo instanceof PDO) return WanSQDbState::$pdo;
    try {
        WanSQDbState::$pdo = new PDO(
            'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
             PDO::ATTR_EMULATE_PREPARES => false,
             PDO::ATTR_STRINGIFY_FETCHES => false,
             PDO::ATTR_TIMEOUT => 8]
        );
        WanSQDbState::$pdo->exec("SET SESSION time_zone = '+00:00'");
    } catch (PDOException $ex) {
        WanSQDbState::$pdo = null;
        if (function_exists('app_log')) app_log('DB connect fail: ' . $ex->getMessage());
        http_response_code(500);
        exit('Koneksi database gagal. Periksa konfigurasi database WanSQ.');
    }
    return WanSQDbState::$pdo;
}

/** Release the PDO socket before a potentially long provider operation. */
function db_close(): void { WanSQDbState::$pdo = null; }

function db_reconnect(): PDO { db_close(); return db(); }

/** Cheap liveness probe. Never starts a transaction. */
function db_ping(): bool {
    try { db()->query('SELECT 1')->fetchColumn(); return true; }
    catch (Throwable $e) { if (db_is_connection_error($e)) { db_reconnect(); return true; } throw $e; }
}

/**
 * Execute an idempotent DB operation with one reconnect retry for stale/lost PDO sockets.
 * The callback must only contain a safe-to-retry persistence operation.
 */
function db_retry(callable $operation, string $label = 'db'): mixed {
    try { return $operation(db()); }
    catch (Throwable $e) {
        if (!db_is_connection_error($e)) throw $e;
        if (function_exists('app_log')) app_log('DB reconnect retry label=' . $label . ' msg=' . mb_substr($e->getMessage(), 0, 180));
        return $operation(db_reconnect());
    }
}

function db_is_connection_error(Throwable $e): bool {
    $m = mb_strtolower($e->getMessage());
    return (bool)preg_match('/server has gone away|lost connection|no connection to the server|is dead or not responding|connection reset|broken pipe|2006|2013/', $m);
}
