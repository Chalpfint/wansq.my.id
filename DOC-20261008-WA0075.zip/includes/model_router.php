<?php
/**
 * WanSQ v3.2.5 — Intelligent Multi-Model Router
 * Routes queries to optimal model based on complexity, type, and context
 *
 * Models:
 * - Qwen3.8 27B: General Q&A (fast, accurate)
 * - Qwen3 30B A3B: Long context (reasoning)
 * - Qwen3 235B A22B: Deep analysis (best quality)
 * - Qwen2.5 VL 72B: Vision (specialized)
 * - gpt-oss-20b: Ultra-fast fallback
 * - Luna 6 Pro: Structured decisions
 */

declare(strict_types=1);

class ModelRouter {
    private $decisions;
    private $cache = [];
    private $routingMetrics = [];

    // Model definitions with capabilities & cost
    private $models = [
        'qwen3.8-27b' => [
            'name' => 'qwen/qwen3.8-27b',
            'label' => 'Qwen 3.8 27B (Fast)',
            'capabilities' => ['chat', 'reasoning', 'followup'],
            'latency_ms' => 1200,
            'cost_per_1k_tokens' => 0.001,
            'best_for' => 'general_qa',
        ],
        'qwen3-30b-a3b' => [
            'name' => 'qwen/qwen3-30b-a3b',
            'label' => 'Qwen 3 30B A3B (Reasoning)',
            'capabilities' => ['chat', 'reasoning', 'longform', 'context'],
            'latency_ms' => 1800,
            'cost_per_1k_tokens' => 0.001,
            'best_for' => 'complex_reasoning',
        ],
        'qwen3-235b-a22b' => [
            'name' => 'qwen/qwen3-235b-a22b',
            'label' => 'Qwen 3 235B A22B (Deep)',
            'capabilities' => ['chat', 'reasoning', 'longform', 'research', 'analysis'],
            'latency_ms' => 2500,
            'cost_per_1k_tokens' => 0.001,
            'best_for' => 'deep_research',
        ],
        'qwen2.5-vl-72b' => [
            'name' => 'qwen/qwen2.5-vl-72b-instruct',
            'label' => 'Qwen 2.5 VL 72B (Vision)',
            'capabilities' => ['vision', 'image_analysis', 'ocr', 'diagrams'],
            'latency_ms' => 2000,
            'cost_per_1k_tokens' => 0.001,
            'best_for' => 'image_analysis',
        ],
        'gpt-oss-20b' => [
            'name' => 'gpt-oss-20b',
            'label' => 'GPT-OSS 20B (Ultra-fast)',
            'capabilities' => ['chat', 'followup'],
            'latency_ms' => 800,
            'cost_per_1k_tokens' => 0.0001,
            'best_for' => 'quick_response',
        ],
        'luna-6-pro' => [
            'name' => 'openai/gpt-6-luna-decisions',
            'label' => 'Luna 6 Pro (Decisions)',
            'capabilities' => ['decisions', 'routing', 'classification'],
            'latency_ms' => 1500,
            'cost_per_1k_tokens' => 0.002,
            'best_for' => 'routing_decisions',
        ],
    ];

    public function __construct() {
        if (class_exists('OpenRouterDecisions') && defined('WANSQ_LUNA_ROUTER') && WANSQ_LUNA_ROUTER) {
            $this->decisions = new OpenRouterDecisions();
        }
    }

    /**
     * Route query to optimal model
     *
     * @param string $query User query
     * @param array $context Context from conversation history
     * @param string $mode Override mode (null = auto-detect)
     * @return array ['model' => string, 'label' => string, 'reason' => string]
     */
    public function route(string $query, array $context = [], ?string $mode = null): array {
        // Cache key
        $cacheKey = md5($query . json_encode($context) . ($mode ?? ''));
        if (isset($this->cache[$cacheKey])) {
            return $this->cache[$cacheKey];
        }

        // Explicit mode override
        if ($mode) {
            $result = $this->routeByMode($query, $mode);
            $this->cache[$cacheKey] = $result;
            return $result;
        }

        // Auto-detect mode using Luna 6 (if available)
        $detection = $this->detectMode($query, $context);

        // Route based on detection
        $result = $this->routeByDetection($query, $detection);

        // Cache result
        $this->cache[$cacheKey] = $result;
        $this->recordMetric('route_success', 1);

        return $result;
    }

    /**
     * Detect query mode using Luna 6 Decisions
     */
    private function detectMode(string $query, array $context): array {
        // Fast heuristic if Luna 6 unavailable
        if (!$this->decisions) {
            return $this->detectModeHeuristic($query);
        }

        try {
            // Build state for Luna 6
            $state = "User query: $query";
            if (!empty($context['summary'])) {
                $state .= "\n\nPrevious context: " . substr($context['summary'], 0, 200);
            }

            // Ask Luna 6 to classify
            $classification = $this->decisions->create($state, [
                'query_type' => [
                    'type' => 'choice',
                    'instructions' => 'What type of query is this?',
                    'criteria' => [
                        'general' => 'General Q&A, conversation',
                        'vision' => 'Image analysis, visual content',
                        'research' => 'Deep research, comprehensive analysis',
                        'followup' => 'Follow-up to previous',
                        'code' => 'Code generation or debugging',
                    ]
                ],
                'complexity' => [
                    'type' => 'score',
                    'instructions' => 'How complex is this?',
                    'criteria' => ['Simple', 'Moderate', 'Complex', 'Very Complex']
                ],
                'needs_reasoning' => [
                    'type' => 'noul',
                    'instructions' => 'Does this need deep reasoning?',
                    'criteria' => ['true' => 'Yes', 'false' => 'No']
                ],
                'is_urgent' => [
                    'type' => 'noul',
                    'instructions' => 'Is speed critical?',
                    'criteria' => ['true' => 'Yes', 'false' => 'No']
                ]
            ]);

            return [
                'type' => $classification['query_type']['choice'] ?? 'general',
                'complexity' => $classification['complexity']['score'] ?? 2,
                'needs_reasoning' => ($classification['needs_reasoning']['noul'] ?? 0.5) > 0.5,
                'is_urgent' => ($classification['is_urgent']['noul'] ?? 0) > 0.7,
                'source' => 'luna6',
            ];
        } catch (Exception $e) {
            // Fallback to heuristic
            return $this->detectModeHeuristic($query);
        }
    }

    /**
     * Heuristic detection (no API call)
     */
    private function detectModeHeuristic(string $query): array {
        $query_lower = strtolower($query);

        // Type detection
        $type = 'general';
        if (preg_match('/(image|photo|picture|diagram|chart|graph|video|visual)/i', $query)) {
            $type = 'vision';
        } elseif (preg_match('/(code|function|python|javascript|php|sql)/i', $query)) {
            $type = 'code';
        } elseif (preg_match('/(research|analyze|study|investigate|comprehensive)/i', $query)) {
            $type = 'research';
        }

        // Complexity
        $words = str_word_count($query);
        $complexity = min(3, max(0, intval($words / 15)));

        // Reasoning needed
        $needs_reasoning = (
            preg_match('/(why|how|explain|analyze|compare|evaluate|argue)/i', $query) ||
            $complexity >= 2
        );

        // Speed critical
        $is_urgent = preg_match('/(quick|fast|simple|short|brief|quickly|asap)/i', $query);

        return [
            'type' => $type,
            'complexity' => $complexity,
            'needs_reasoning' => $needs_reasoning,
            'is_urgent' => $is_urgent,
            'source' => 'heuristic',
        ];
    }

    /**
     * Route by detected mode
     */
    private function routeByDetection(string $query, array $detection): array {
        $type = $detection['type'] ?? 'general';
        $complexity = $detection['complexity'] ?? 2;
        $needs_reasoning = $detection['needs_reasoning'] ?? false;
        $is_urgent = $detection['is_urgent'] ?? false;

        // Decision tree
        if ($type === 'vision') {
            return [
                'model' => $this->models['qwen2.5-vl-72b']['name'],
                'label' => $this->models['qwen2.5-vl-72b']['label'],
                'reason' => 'Image analysis detected',
                'mode' => 'vision',
            ];
        }

        if ($type === 'research' || ($complexity >= 2 && $needs_reasoning)) {
            if ($is_urgent) {
                return [
                    'model' => $this->models['qwen3-30b-a3b']['name'],
                    'label' => $this->models['qwen3-30b-a3b']['label'],
                    'reason' => 'Research mode (fast)',
                    'mode' => 'research',
                ];
            } else {
                return [
                    'model' => $this->models['qwen3-235b-a22b']['name'],
                    'label' => $this->models['qwen3-235b-a22b']['label'],
                    'reason' => 'Deep research required',
                    'mode' => 'research',
                ];
            }
        }

        if ($is_urgent && !$needs_reasoning) {
            return [
                'model' => $this->models['gpt-oss-20b']['name'],
                'label' => $this->models['gpt-oss-20b']['label'],
                'reason' => 'Speed critical',
                'mode' => 'fast',
            ];
        }

        if ($complexity >= 2 && $needs_reasoning) {
            return [
                'model' => $this->models['qwen3-30b-a3b']['name'],
                'label' => $this->models['qwen3-30b-a3b']['label'],
                'reason' => 'Complex reasoning needed',
                'mode' => 'reasoning',
            ];
        }

        // Default: general
        return [
            'model' => $this->models['qwen3.8-27b']['name'],
            'label' => $this->models['qwen3.8-27b']['label'],
            'reason' => 'General Q&A',
            'mode' => 'general',
        ];
    }

    /**
     * Route by explicit mode
     */
    private function routeByMode(string $query, string $mode): array {
        $modes = [
            'fast' => 'gpt-oss-20b',
            'general' => 'qwen3.8-27b',
            'reasoning' => 'qwen3-30b-a3b',
            'research' => 'qwen3-235b-a22b',
            'vision' => 'qwen2.5-vl-72b',
            'decision' => 'luna-6-pro',
        ];

        if (!isset($modes[$mode])) {
            return $this->routeByDetection($query, []);
        }

        $modelKey = $modes[$mode];
        return [
            'model' => $this->models[$modelKey]['name'],
            'label' => $this->models[$modelKey]['label'],
            'reason' => "Explicit mode: $mode",
            'mode' => $mode,
        ];
    }

    /**
     * Get all available models
     */
    public function getModels(): array {
        return $this->models;
    }

    /**
     * Get model info
     */
    public function getModel(string $modelKey): ?array {
        return $this->models[$modelKey] ?? null;
    }

    /**
     * Record routing metric
     */
    private function recordMetric(string $key, int $value = 1): void {
        if (!isset($this->routingMetrics[$key])) {
            $this->routingMetrics[$key] = 0;
        }
        $this->routingMetrics[$key] += $value;
    }

    /**
     * Get routing metrics
     */
    public function getMetrics(): array {
        return $this->routingMetrics;
    }
}

// Helper function
if (!function_exists('model_router')) {
    function model_router(): ModelRouter {
        static $instance = null;
        if ($instance === null) {
            $instance = new ModelRouter();
        }
        return $instance;
    }
}
