<?php
declare(strict_types=1);
/**
 * WanSQ · Model registry & rantai fallback (role: chat | fast | vision).
 * - Kandidat berasal dari config + default terkini, difilter oleh daftar model LIVE dari provider (GET /models).
 * - Model yang gagal "notfound/decommissioned" ditandai mati 10 menit (tidak dicoba ulang tiap request).
 * - Model vision HANYA dipilih dari model yang benar-benar mampu membaca gambar.
 * - Kebijakan: failure → retry (transien) → fallback → respons (atau galat jelas), tak pernah loading selamanya.
 */
if (!defined('LLM_LIVE_TTL')) define('LLM_LIVE_TTL', 600);
if (!defined('LLM_DEAD_TTL')) define('LLM_DEAD_TTL', 600);
if (!defined('LLM_BUDGET_TTL')) define('LLM_BUDGET_TTL', 120);   // batas hasil 402 berlaku per model selama 2 menit
if (!defined('LLM_PRESSURE_CAP')) define('LLM_PRESSURE_CAP', 2048); // di bawah ini = kredit menipis (mode hemat)

/** Model yang diketahui benar-benar dipensiunkan Groq (fallback saat GET /models gagal total). */
function llm_deprecated(): array {
    return array(
        'llama3-8b-8192','llama3-70b-8192','gemma-7b-it','gemma2-9b-it',
        'mixtral-8x7b-32768','llama-3.2-11b-vision-preview','llama-3.2-90b-vision-preview',
        'qwen/qwen3-32b','qwen/qwen3.6-27b',
        'meta-llama/llama-4-scout-17b-16e-instruct','meta-llama/llama-4-maverick-17b-128e-instruct',
        'moonshotai/kimi-k2-instruct-0905'
    );
}

/**
 * Explicit capability registry. The provider's /models endpoint tells us which IDs are live,
 * while this registry tells WanSQ what each known model can actually do. Unknown models are
 * handled conservatively by family heuristics instead of being assumed multimodal.
 */
function llm_registry(): array {
    static $r = null;
    if ($r !== null) return $r;
    $r = array(
        'qwen/qwen3.8-27b' => array(
            'text'=>true,'vision'=>true,'ocr'=>true,'reasoning'=>true,'tool_use'=>true,'json'=>true,
            'context'=>1000000,'output'=>32768,'max_images'=>3,'max_file_mb'=>20
        ),
        'openai/gpt-oss-120b' => array(
            'text'=>true,'vision'=>false,'ocr'=>false,'reasoning'=>true,'tool_use'=>true,'json'=>true,
            'context'=>131072,'output'=>65536,'max_images'=>0,'max_file_mb'=>0
        ),
        'openai/gpt-oss-20b' => array(
            'text'=>true,'vision'=>false,'ocr'=>false,'reasoning'=>true,'tool_use'=>true,'json'=>true,
            'context'=>131072,'output'=>65536,'max_images'=>0,'max_file_mb'=>0
        ),
    );
    return $r;
}

function llm_capabilities(string $id): array {
    $r = llm_registry();
    if (isset($r[$id])) return $r[$id];
    $c = array('text'=>false,'vision'=>false,'ocr'=>false,'reasoning'=>false,'tool_use'=>false,'json'=>false,
               'context'=>131072,'output'=>8192,'max_images'=>0,'max_file_mb'=>0);
    $low = strtolower($id);
    if (preg_match('~(whisper|orpheus|tts|guard|safeguard|embed)~', $low)) return $c;
    $c['text'] = true;
    if (preg_match('~(qwen3\.8|qwen3-vl|qwen-vl|pixtral|gemma3|llama-4|vision|[-_]vl\b)~', $low)) {
        $c['vision'] = true; $c['ocr'] = true; $c['max_images'] = 3; $c['max_file_mb'] = 20;
    }
    if (preg_match('~(gpt-oss|qwen3|qwen-vl|qwen3-vl|kimi|deepseek|llama-3\.[13]|llama-4)~', $low)) $c['reasoning'] = true;
    if (preg_match('~(gpt-oss|qwen3\.8|qwen3|kimi|llama-3\.[13]|llama-4)~', $low)) $c['tool_use'] = true;
    $c['json'] = $c['tool_use'];
    return $c;
}
function llm_is_vision_model(string $id): bool { return !empty(llm_capabilities($id)['vision']); }
function llm_is_chat_model(string $id): bool { return !empty(llm_capabilities($id)['text']); }
function llm_supports(string $id, string $cap): bool { return !empty(llm_capabilities($id)[$cap]); }

function llm_state_path(): string {
    $d = STORAGE_DIR . '/cache'; if (!is_dir($d)) @mkdir($d, 0775, true);
    return $d . '/llm_state.json';
}
function llm_state(): array {
    $j = json_decode((string)@file_get_contents(llm_state_path()), true);
    return is_array($j) ? $j : array();
}
function llm_state_save(array $s): void { @file_put_contents(llm_state_path(), json_encode($s), LOCK_EX); }

/** Daftar id model aktif dari provider (cache 10 menit). [] bila gagal. */
function llm_live_models(bool $force = false, bool $net = true): array {
    $s = llm_state();
    if (!$force && !empty($s['live_ts']) && (time() - (int)$s['live_ts']) < LLM_LIVE_TTL && isset($s['live'])) return (array)$s['live'];
    if (!$net) return isset($s['live']) ? (array)$s['live'] : array();   // tanpa jaringan (render halaman)
    $r = groq_get('/models', 8);
    $ids = array();
    if (!empty($r['data']) && is_array($r['data'])) foreach ($r['data'] as $m) if (!empty($m['id'])) $ids[] = (string)$m['id'];
    if ($ids) { $s['live'] = $ids; $s['live_ts'] = time(); llm_state_save($s); return $ids; }
    if (isset($s['live'])) return (array)$s['live'];   // pakai cache lama bila jaringan sedang bermasalah
    return array();
}
function llm_dead(): array {
    $s = llm_state(); $out = array();
    foreach ((array)($s['dead'] ?? array()) as $m => $ts) if ((time() - (int)$ts) < LLM_DEAD_TTL) $out[$m] = (int)$ts;
    return $out;
}
function llm_mark_dead(string $model): void {
    $s = llm_state(); $d = (array)($s['dead'] ?? array()); $d[$model] = time(); $s['dead'] = $d; llm_state_save($s);
}

/** Rantai kandidat berurutan untuk sebuah role. */
function llm_chain(string $role, bool $net = true): array {
    $cfg = array(
        'chat'   => array(defined('MODEL_CHAT') ? MODEL_CHAT : '', 'openai/gpt-oss-120b', 'qwen/qwen3.8-27b', 'openai/gpt-oss-20b'),
        'fast'   => array(defined('MODEL_FAST') ? MODEL_FAST : '', 'openai/gpt-oss-20b', 'openai/gpt-oss-120b', 'qwen/qwen3.8-27b'),
        'vision' => array(defined('MODEL_VISION') ? MODEL_VISION : '', 'qwen/qwen3.8-27b'),
    );
    $required = $role === 'vision' ? 'vision' : 'text';
    $cand = array();
    foreach (($cfg[$role] ?? $cfg['chat']) as $m) {
        if ($m !== '' && !in_array($m, $cand, true) && llm_supports($m, $required)) $cand[] = $m;
    }
    $live = llm_live_models(false, $net);
    if ($live) {
        $cand = array_values(array_filter($cand, function ($m) use ($live) { return in_array($m, $live, true); }));
        foreach ($live as $m) {
            if (in_array($m, $cand, true) || in_array($m, llm_deprecated(), true)) continue;
            if ($role === 'vision' && llm_supports($m, 'vision')) $cand[] = $m;
            elseif ($role !== 'vision' && llm_supports($m, 'text') && (!$cand || count($cand) < 3)) $cand[] = $m;
        }
    } else {
        $cand = array_values(array_filter($cand, function ($m) { return !in_array($m, llm_deprecated(), true); }));
    }
    $dead = llm_dead();
    $alive = array_values(array_filter($cand, function ($m) use ($dead) { return !isset($dead[$m]); }));
    $out = $alive ? $alive : $cand;
    // Fallback opsional (mis. model ':free' OpenRouter) sebagai jaring terakhir non-vision. Kosong = nonaktif.
    if ($role !== 'vision' && defined('FREE_FALLBACK_MODELS') && FREE_FALLBACK_MODELS !== '') {
        foreach (array_map('trim', explode(',', FREE_FALLBACK_MODELS)) as $fm) {
            if ($fm !== '' && !in_array($fm, $out, true) && (!$live || in_array($fm, $live, true))) $out[] = $fm;
        }
    }
    return $out;
}

function llm_available(string $role, bool $net = false): bool { return count(llm_chain($role, $net)) > 0; }

function llm_model_max_tokens(string $model): int {
    $c = llm_capabilities($model);
    return (int)($c['output'] ?? 8192);
}
/**
 * Anggaran kredit provider (HTTP 402): "can only afford N" berarti max_tokens <= N.
 * Batas diturunkan ke ~92% dari N lalu model yang sama dicoba lagi. Bila terlalu kecil (< 256)
 * atau tidak lebih kecil dari percobaan sebelumnya, kembalikan null agar pindah ke model berikutnya.
 */
function llm_budget_next_cap(?int $afford, int $prev): ?int {
    if ($afford === null) return null;
    $cap = (int)floor($afford * 0.92) - 16;
    if ($cap < 256 || $cap >= $prev) return null;
    return $cap;
}
/** Catat batas hasil 402 per model (harga tiap model berbeda, jadi tidak global). */
function llm_budget_note(string $model, int $cap): void {
    $s = llm_state(); $b = (array)($s['budget_cap'] ?? array());
    $b[$model] = array('cap' => $cap, 'ts' => time());
    $s['budget_cap'] = $b; llm_state_save($s);
}
function llm_sticky_cap(string $model): ?int {
    $b = (array)(llm_state()['budget_cap'] ?? array());
    if (!isset($b[$model])) return null;
    if ((time() - (int)($b[$model]['ts'] ?? 0)) >= LLM_BUDGET_TTL) return null;
    return (int)$b[$model]['cap'];
}
/** True bila baru-baru ini ada batas kredit yang sangat kecil: fitur opsional (follow-up, ringkasan) ditunda. */
function llm_budget_pressure(): bool {
    $b = (array)(llm_state()['budget_cap'] ?? array());
    foreach ($b as $e) {
        if ((time() - (int)($e['ts'] ?? 0)) < LLM_BUDGET_TTL && (int)($e['cap'] ?? PHP_INT_MAX) < LLM_PRESSURE_CAP) return true;
    }
    return false;
}
/** Parameter tambahan khusus keluarga model (dilepas otomatis bila provider menolak). */
function llm_extras(string $model, string $role): array {
    $lean = llm_budget_pressure();   // kredit menipis: batasi token "berpikir" agar jawaban tidak habis di reasoning
    if (strpos($model, 'openai/gpt-oss') === 0) return array('reasoning_effort' => ($lean ? 'low' : ($role === 'chat' ? 'medium' : 'low')));
    // Qwen via OpenRouter menerima: max|xhigh|high|medium|low|minimal|none. 'default' ditolak (HTTP 400).
    if (strpos($model, 'qwen/') === 0) return array('reasoning_format' => 'hidden', 'reasoning_effort' => (($lean || $role === 'fast') ? 'low' : 'medium'));
    return array();
}
function llm_prepare(array $payload, string $model, string $role, bool $withExtras = true, ?int $cap = null): array {
    $payload['model'] = $model;
    if (isset($payload['max_completion_tokens'])) {
        $lim = $cap;
        $sticky = llm_sticky_cap($model);
        if ($sticky !== null && ($lim === null || $sticky < $lim)) $lim = $sticky;
        $v = min((int)$payload['max_completion_tokens'], llm_model_max_tokens($model));
        if ($lim !== null) $v = min($v, $lim);
        $payload['max_completion_tokens'] = max(1, $v);
    }
    if ($withExtras) foreach (llm_extras($model, $role) as $k => $v) if (!isset($payload[$k])) $payload[$k] = $v;
    return $payload;
}
function llm_log(string $role, string $model, array $r, int $ms, bool $fallback): void {
    app_log(sprintf('llm role=%s model=%s http=%s ms=%d first=%s kind=%s fallback=%d err=%s', $role, $model,
        var_export($r['http'] ?? null, true), $ms, var_export($r['first_token_ms'] ?? null, true),
        (string)($r['kind'] ?? ''), $fallback ? 1 : 0, mb_substr((string)($r['err'] ?? ''), 0, 160)));
}

/**
 * Non-stream dengan fallback. Return: ok, text, model, ms, err, kind, attempts[].
 */
function llm_call(string $role, array $payload, int $timeout = 30): array {
    $out = array('ok' => false, 'text' => '', 'model' => null, 'ms' => 0, 'err' => null, 'kind' => null, 'attempts' => array());
    $chain = llm_chain($role); $t0 = microtime(true);
    if (!$chain) { $out['err'] = 'Tidak ada model ' . $role . ' yang tersedia'; $out['kind'] = 'notfound'; return $out; }
    foreach ($chain as $i => $model) {
        $cap = null; $dropExtras = false;
        for ($try = 0; $try < 3; $try++) {
            $extras = !$dropExtras;
            $ts = microtime(true);
            $r = groq_call(llm_prepare($payload, $model, $role, $extras, $cap), $timeout);
            $ms = ms_since($ts);
            $txt = '';
            if (isset($r['choices'][0]['message']['content'])) {
                $c = $r['choices'][0]['message']['content'];
                $txt = is_string($c) ? $c : '';
                $txt = trim(preg_replace('~<think>.*?</think>~s', '', $txt));
            }
            $http = (int)($r['_http'] ?? 0);
            $err = isset($r['error']) ? (is_array($r['error']) ? (string)($r['error']['message'] ?? 'Error provider') : (string)$r['error']) : null;
            if ($err === null && $txt === '') $err = 'Model tidak mengembalikan output';
            $kind = $err !== null ? groq_err_kind($http, $err, (string)($r['_curl'] ?? '')) : null;
            $rec = array('model' => $model, 'http' => $http, 'ms' => $ms, 'err' => $err, 'kind' => $kind);
            $out['attempts'][] = $rec; llm_log($role, $model, $rec, $ms, $i > 0);
            if ($err === null) { $out['ok'] = true; $out['text'] = $txt; $out['model'] = $model; $out['ms'] = ms_since($t0); return $out; }
            $out['err'] = $err; $out['kind'] = $kind;
            if ($kind === 'budget') {                           // kredit kurang: turunkan max_tokens, model yang sama
                $prev = $cap ?? (int)($payload['max_completion_tokens'] ?? 8192);
                $nc = llm_budget_next_cap(groq_afford_from_msg((string)$err), $prev);
                if ($nc !== null) { $cap = $nc; llm_budget_note($model, $nc); continue; }
            }
            if ($kind === 'auth') { $out['ms'] = ms_since($t0); return $out; }
            if ($kind === 'badrequest' && !$dropExtras && llm_extras($model, $role)) { $dropExtras = true; continue; }   // ulangi tanpa extras
            if (in_array($kind, array('rate', 'server', 'timeout', 'network'), true) && $try === 0) { usleep(600000); continue; }
            if ($kind === 'notfound') llm_mark_dead($model);
            break;
        }
    }
    $out['ms'] = ms_since($t0);
    return $out;
}

/**
 * Stream dengan fallback. $onStatus(string) dipanggil saat pindah engine. Hasil di $res:
 * ok, model, err, kind, http, usage, finish, first_token_ms, attempts[], partial(bool), text (akumulasi).
 */
function llm_stream(string $role, array $payload, callable $onDelta, callable $onStatus, array &$res): void {
    $res = array('ok' => false, 'model' => null, 'err' => null, 'kind' => null, 'http' => null, 'usage' => null, 'finish' => null,
                 'first_token_ms' => null, 'attempts' => array(), 'partial' => false, 'text' => '', 'connect_ms' => null);
    $chain = llm_chain($role);
    if (!$chain) { $res['err'] = 'Tidak ada model ' . $role . ' yang tersedia'; $res['kind'] = 'notfound'; return; }
    foreach ($chain as $i => $model) {
        if ($i > 0) $onStatus('fallback');
        $cap = null; $dropExtras = false;
        for ($try = 0; $try < 3; $try++) {
            $extras = !$dropExtras;
            $p = llm_prepare($payload, $model, $role, $extras, $cap);
            if ($try === 2 && strpos($model, 'openai/gpt-oss') === 0) $p['reasoning_effort'] = 'low';
            $ts = microtime(true); $r = array();
            $acc = '';
            groq_stream($p, function ($d) use (&$acc, $onDelta) { $acc .= $d; $onDelta($d); }, $r);
            $ms = ms_since($ts);
            $rec = array('model' => $model, 'http' => $r['http'], 'ms' => $ms, 'err' => $r['err'], 'kind' => $r['kind'], 'first' => $r['first_token_ms']);
            $res['attempts'][] = $rec; llm_log($role, $model, $r + array('first_token_ms' => $r['first_token_ms']), $ms, $i > 0);
            $res['model'] = $model; $res['http'] = $r['http']; $res['usage'] = $r['usage']; $res['finish'] = $r['finish'];
            $res['first_token_ms'] = $r['first_token_ms']; $res['connect_ms'] = $r['connect_ms']; $res['text'] = $acc;
            if ($acc !== '') {                                   // sudah ada token: tidak boleh fallback (hindari jawaban ganda)
                $res['ok'] = true;
                if ($r['err'] !== null) { $res['partial'] = true; $res['err'] = $r['err']; $res['kind'] = $r['kind']; }
                return;
            }
            $res['err'] = $r['err']; $res['kind'] = $r['kind'];
            if ($r['err'] === null) $res['err'] = 'Model tidak mengembalikan output';
            $kind = $r['kind'] ?: 'unknown';
            if (connection_aborted()) return;
            if ($kind === 'budget') {                           // kredit kurang: turunkan max_tokens, model yang sama
                $prev = $cap ?? (int)($payload['max_completion_tokens'] ?? 8192);
                $nc = llm_budget_next_cap($r['afford'] ?? null, $prev);
                if ($nc !== null) { $cap = $nc; llm_budget_note($model, $nc); continue; }
            }
            if ($kind === 'auth') return;
            if ($kind === 'badrequest' && !$dropExtras && llm_extras($model, $role)) { $dropExtras = true; continue; }   // lepas extras
            if (($kind === 'unknown' || $kind === 'badrequest') && $try < 2 && strpos($model, 'openai/gpt-oss') === 0) continue; // reasoning menghabiskan token
            if (in_array($kind, array('rate', 'server', 'timeout', 'network'), true) && $try === 0) { usleep(700000); continue; }
            if ($kind === 'notfound') llm_mark_dead($model);
            break;
        }
    }
}
