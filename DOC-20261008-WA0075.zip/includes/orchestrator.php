<?php
declare(strict_types=1);
/**
 * Orchestrator: rute dipilih selektif — tidak semua tool dijalankan tiap pesan.
 *   sapaan/perkenalan       → fast path → LLM
 *   gambar + pertanyaan     → Vision (persepsi) → Reasoning   (atau Vision langsung untuk "deskripsikan/baca teks")
 *   dokumen/PDF             → parser/OCR → indeks → retrieval → Reasoning
 *   ekspresi matematika     → kalkulator → Reasoning
 *   "cari informasi terbaru"→ web search → Reasoning
 *   "buatkan gambar …"      → Image generation (bila kapabilitas aktif)
 * Logika rute berada di api/chat.php (tahap-tahap nyata dengan status SSE); file ini menyimpan heuristik ringan.
 */
function orch_fast_path(string $text, string $engine): bool {
    if ($engine !== 'auto') return false;
    $t = mb_strtolower(trim($text));
    if ($t === '' || mb_strlen($t) > 220) return false;
    if (preg_match('/\b(integral|turunan|derivatif|limit|matriks|persamaan|hitung|buktikan|analisis|bandingkan|mengapa|kenapa|jelaskan mendalam|program|kode|debug|sql|php|javascript|python|research|riset|terbaru|sumber)\b/iu', $t)) return false;
    return (bool)preg_match(
        '/^(halo|hai|hei|hello|hi|hey|selamat|assalam|permisi|terima kasih|thanks|perkenalkan|kenalkan diri|kamu siapa|siapa kamu|apa itu wansq|apa itu|definisi|arti |maksud |jelaskan singkat|tentang dirimu|diri anda)\b/u', $t);
}
