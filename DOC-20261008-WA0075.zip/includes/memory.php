<?php
declare(strict_types=1);
/** Memory global (per user) dan Project Memory (per project) — terpisah dan tidak tercampur. */

function memory_rank(array $rows, string $text, int $limit): array {
    $qk = keywordize($text); if (!$qk) return array();
    $scored = array();
    foreach ($rows as $m) {
        $mk = keywordize((string)$m['content']);
        $s = count(array_intersect($qk, $mk));
        if ($s > 0) $scored[] = array('s' => $s, 'c' => (string)$m['content']);
    }
    usort($scored, function ($a, $b) { return $b['s'] <=> $a['s']; });
    return array_slice($scored, 0, $limit);
}
function memory_block(int $uid, string $text): string {
    $st = db()->prepare('SELECT content FROM memories WHERE user_id = ? ORDER BY id DESC LIMIT 150');
    $st->execute([$uid]);
    $pick = memory_rank($st->fetchAll(), $text, 5);
    return $pick ? implode("\n", array_map(function ($x) { return '- ' . $x['c']; }, $pick)) : '';
}
function project_memory_block(int $uid, int $pid, string $text): string {
    $st = db()->prepare('SELECT content FROM project_memories WHERE project_id = ? AND user_id = ? ORDER BY id DESC LIMIT 150');
    $st->execute([$pid, $uid]);
    $pick = memory_rank($st->fetchAll(), $text, 6);
    return $pick ? implode("\n", array_map(function ($x) { return '- ' . $x['c']; }, $pick)) : '';
}
function save_memory(int $uid, string $content): void {
    $pdo = db();
    $content = mb_substr($content, 0, 500);
    $pdo->prepare('INSERT INTO memories (user_id, content, keywords) VALUES (?,?,?)')
        ->execute([$uid, $content, mb_substr(implode(' ', keywordize($content)), 0, 500)]);
    $id = (int)$pdo->lastInsertId();
    $pdo->prepare("INSERT INTO memory_meta (user_id,memory_type,memory_id,source,confidence,relevance,provenance) VALUES (?,?,?,?,?,?,?)")
        ->execute([$uid,'global',$id,'user',1.0,1.0,'Explicitly saved by user']);
}
function save_project_memory(int $uid, int $pid, string $content): void {
    $pdo = db();
    $content = mb_substr($content, 0, 500);
    $pdo->prepare('INSERT INTO project_memories (project_id, user_id, content, keywords) VALUES (?,?,?,?)')
        ->execute([$pid, $uid, $content, mb_substr(implode(' ', keywordize($content)), 0, 500)]);
    $id = (int)$pdo->lastInsertId();
    $pdo->prepare("INSERT INTO memory_meta (user_id,memory_type,memory_id,source,confidence,relevance,provenance) VALUES (?,?,?,?,?,?,?)")
        ->execute([$uid,'project',$id,'user',1.0,1.0,'Explicitly saved by user in project']);
}
