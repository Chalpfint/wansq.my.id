<?php
declare(strict_types=1);
/**
 * WanSQ v3.2 · Image normalization — arsitektur "Original + Derivative" (bukan destruktif).
 *
 * ORIGINAL yang diunggah pengguna disimpan APA ADANYA (byte-identik) di stored_path dan
 * itulah yang selalu ditampilkan pada preview/lightbox — termasuk gambar 16×16 atau format
 * asli apa pun yang valid. DERIVATIVE (JPEG, ternormalisasi) dibuat TERPISAH khusus untuk
 * dikirim ke model vision, dan tidak pernah menimpa original.
 *
 * Pipeline derivative: decode → koreksi orientasi EXIF → ratakan transparansi ke putih
 *   → upscale (pad, BUKAN crop/stretch) bila terlalu kecil untuk provider → downscale bila
 *   melebihi batas inferensi → encode JPEG. Setiap langkah yang benar-benar dijalankan
 *   dicatat di derivative_reason (comma-separated) untuk kejujuran diagnostik.
 */
if (!defined('IMG_INFER_MAX_DIM')) define('IMG_INFER_MAX_DIM', 1568);   // batas sisi terpanjang untuk inferensi (aman utk provider)
if (!defined('IMG_INFER_MIN_DIM')) define('IMG_INFER_MIN_DIM', 32);     // sebagian provider vision menolak gambar sangat kecil

function imgproc_gd_available(): bool { return function_exists('imagecreatefromstring'); }

/** Decode gambar dari path, otomatis lewat GD sesuai MIME. Null bila gagal/corrupt. */
function imgproc_decode(string $path, string $mime) {
    $data = @file_get_contents($path);
    if ($data === false || $data === '') return null;
    $im = @imagecreatefromstring($data);
    return $im ?: null;
}

/** Baca orientasi EXIF (1-8) untuk JPEG bila ekstensi exif tersedia. Default 1 (normal). */
function imgproc_exif_orientation(string $path, string $mime): int {
    if ($mime !== 'image/jpeg' || !function_exists('exif_read_data')) return 1;
    $ex = @exif_read_data($path);
    return (is_array($ex) && !empty($ex['Orientation'])) ? (int)$ex['Orientation'] : 1;
}
function imgproc_apply_orientation($im, int $o) {
    switch ($o) {
        case 3: return imagerotate($im, 180, 0);
        case 6: return imagerotate($im, -90, 0);
        case 8: return imagerotate($im, 90, 0);
        default: return $im;
    }
}

/**
 * Bangun derivative dari file original. Return array(ok, bytes, mime, width, height, reason).
 * $reason: comma-separated dari {orientation, flattened, upscaled, downscaled, unchanged}.
 */
function imgproc_make_derivative(string $origPath, string $mime): array {
    $fail = array('ok' => false, 'bytes' => '', 'mime' => '', 'width' => 0, 'height' => 0, 'reason' => '');
    if (!imgproc_gd_available()) return $fail;
    $im = imgproc_decode($origPath, $mime);
    if (!$im) return $fail;
    $reasons = array();

    $o = imgproc_exif_orientation($origPath, $mime);
    if ($o !== 1) { $r = imgproc_apply_orientation($im, $o); if ($r) { $im = $r; $reasons[] = 'orientation'; } }

    $w = imagesx($im); $h = imagesy($im);
    if ($w < 1 || $h < 1) { imagedestroy($im); return $fail; }

    // Ratakan transparansi ke latar putih (derivative selalu JPEG; original tetap menyimpan alpha bila ada).
    $flat = imagecreatetruecolor($w, $h);
    imagealphablending($flat, true);
    imagefill($flat, 0, 0, imagecolorallocate($flat, 255, 255, 255));
    imagecopy($flat, $im, 0, 0, 0, 0, $w, $h);
    imagedestroy($im); $im = $flat; $reasons[] = 'flattened';

    // First constrain the long side. This prevents pathological aspect ratios
    // (for example 1×5000) from being upscaled into an enormous derivative.
    if (max($w, $h) > IMG_INFER_MAX_DIM) {
        $scale = IMG_INFER_MAX_DIM / max($w, $h);
        $nw = max(1, (int)round($w * $scale)); $nh = max(1, (int)round($h * $scale));
        $dn = imagecreatetruecolor($nw, $nh);
        imagefill($dn, 0, 0, imagecolorallocate($dn, 255, 255, 255));
        imagecopyresampled($dn, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
        imagedestroy($im); $im = $dn; $w = $nw; $h = $nh; $reasons[] = 'downscaled';
    }

    // Provider minimums apply to BOTH dimensions. Prefer uniform upscaling,
    // but if that would violate the maximum long side, pad the derivative
    // canvas instead. The image content is never stretched or cropped.
    if ($w < IMG_INFER_MIN_DIM || $h < IMG_INFER_MIN_DIM) {
        $scale = max(IMG_INFER_MIN_DIM / $w, IMG_INFER_MIN_DIM / $h);
        $scaledW = max(1, (int)round($w * $scale));
        $scaledH = max(1, (int)round($h * $scale));
        if (max($scaledW, $scaledH) <= IMG_INFER_MAX_DIM) {
            $up = imagecreatetruecolor($scaledW, $scaledH);
            imagefill($up, 0, 0, imagecolorallocate($up, 255, 255, 255));
            imagecopyresampled($up, $im, 0, 0, 0, 0, $scaledW, $scaledH, $w, $h);
            imagedestroy($im); $im = $up; $w = $scaledW; $h = $scaledH; $reasons[] = 'upscaled';
        } else {
            $padW = max($w, IMG_INFER_MIN_DIM); $padH = max($h, IMG_INFER_MIN_DIM);
            $pad = imagecreatetruecolor($padW, $padH);
            imagefill($pad, 0, 0, imagecolorallocate($pad, 255, 255, 255));
            $dx = (int)floor(($padW - $w) / 2); $dy = (int)floor(($padH - $h) / 2);
            imagecopy($pad, $im, $dx, $dy, 0, 0, $w, $h);
            imagedestroy($im); $im = $pad; $w = $padW; $h = $padH; $reasons[] = 'padded';
        }
    }
    if (!$reasons) $reasons[] = 'unchanged';

    ob_start(); imagejpeg($im, null, 85); $bytes = (string)ob_get_clean(); imagedestroy($im);
    if ($bytes === '') return $fail;
    return array('ok' => true, 'bytes' => $bytes, 'mime' => 'image/jpeg', 'width' => $w, 'height' => $h, 'reason' => implode(',', $reasons));
}

/** Simpan bytes derivative ke storage privat. Return path relatif (att/derived/...) atau null. */
function imgproc_store_derivative(string $bytes, string $day): ?string {
    $dir = STORAGE_DIR . '/att/derived/' . $day;
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return null;
    $name = bin2hex(random_bytes(10)) . '.jpg';
    if (@file_put_contents($dir . '/' . $name, $bytes) === false) return null;
    return 'att/derived/' . $day . '/' . $name;
}

/** Dimensi asli file gambar (untuk metadata attachments.width/height), aman terhadap file corrupt. */
function imgproc_dimensions(string $path): array {
    $d = @getimagesize($path);
    return $d ? array((int)$d[0], (int)$d[1]) : array(0, 0);
}
