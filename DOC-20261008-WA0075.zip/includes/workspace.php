<?php
declare(strict_types=1);
/**
 * WanSQ 3.2.4 workspace services.
 * Artifacts, version history, jobs, provenance, and conversation branches are
 * deliberately additive layers around the stable chat foundation.
 */
function ws_allowed_artifact_type(string $type): bool {
    return in_array($type, ['document','markdown','code','html','table','chart','study_guide','report'], true);
}
function ws_job_create(int $uid, string $kind, string $title, array $meta = []): int {
    $pdo = db();
    $st = $pdo->prepare('INSERT INTO jobs (user_id,project_id,conversation_id,kind,status,progress,title,payload,created_at,updated_at,started_at) VALUES (?,?,?,?,?,?,?,?,NOW(),NOW(),NOW())');
    $pid = !empty($meta['project_id']) ? (int)$meta['project_id'] : null;
    $cid = !empty($meta['conversation_id']) ? (int)$meta['conversation_id'] : null;
    $payload = isset($meta['payload']) ? json_encode($meta['payload'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null;
    $st->execute([$uid,$pid,$cid,$kind,'running',0,mb_substr($title,0,160),$payload]);
    return (int)$pdo->lastInsertId();
}
function ws_job_update(int $uid, int $jobId, string $status, int $progress = 0, ?string $error = null): bool {
    $progress = max(0,min(100,$progress));
    $finished = in_array($status,['completed','failed','cancelled'],true);
    $sql = 'UPDATE jobs SET status=?, progress=?, error=?, updated_at=NOW()' . ($finished ? ',finished_at=NOW()' : '') . ' WHERE id=? AND user_id=?';
    return db()->prepare($sql)->execute([$status,$progress,$error ? mb_substr($error,0,500) : null,$jobId,$uid]);
}
/** Selesaikan pekerjaan yang dengan jelas ditinggalkan (proses mati/timeout) agar tidak 'running' selamanya. */
function ws_jobs_reap(int $uid, int $minutes = 15): int {
    $st = db()->prepare("UPDATE jobs SET status='failed', error='Tidak selesai (timeout atau proses terhenti)', finished_at=NOW() WHERE user_id=? AND status IN ('running','queued') AND COALESCE(heartbeat_at,updated_at) < (NOW() - INTERVAL ".(int)$minutes." MINUTE)");
    $st->execute([$uid]); return $st->rowCount();
}
/** Catat pekerjaan sinkron yang sudah selesai (riwayat nyata di Job Center). Best-effort. */
function ws_job_record(int $uid, string $kind, string $title, bool $ok, ?string $error = null, ?int $convId = null, ?string $ref = null): void {
    try {
        db()->prepare('INSERT INTO jobs (user_id,conversation_id,kind,status,progress,title,error,result_ref,created_at,updated_at,started_at,finished_at) VALUES (?,?,?,?,?,?,?,?,NOW(),NOW(),NOW(),NOW())')
            ->execute([$uid,$convId?:null,mb_substr($kind,0,40),$ok?'completed':'failed',$ok?100:0,mb_substr($title,0,160),$error?mb_substr($error,0,500):null,$ref]);
    } catch (Throwable $e) { /* riwayat bersifat opsional */ }
}
function ws_jobs_clear(int $uid): int {
    $st = db()->prepare("DELETE FROM jobs WHERE user_id=? AND status IN ('completed','failed','cancelled')"); $st->execute([$uid]); return $st->rowCount();
}
function ws_jobs(int $uid, int $limit = 30): array {
    try { ws_jobs_reap($uid); } catch (Throwable $e) {}
    $limit = max(1,min(100,$limit));
    $st = db()->prepare('SELECT id,project_id,conversation_id,kind,status,progress,title,error,result_ref,created_at,updated_at,started_at,finished_at FROM jobs WHERE user_id=? ORDER BY updated_at DESC LIMIT '.$limit);
    $st->execute([$uid]);
    return $st->fetchAll();
}
function ws_artifact_payload(array $a): array {
    return [
        'id'=>(int)$a['id'],'project_id'=>$a['project_id']!==null?(int)$a['project_id']:null,
        'conversation_id'=>$a['conversation_id']!==null?(int)$a['conversation_id']:null,
        'type'=>(string)$a['type'],'title'=>(string)$a['title'],'content'=>(string)$a['content'],
        'version'=>(int)$a['version'],'created_at'=>$a['created_at'],'updated_at'=>$a['updated_at']
    ];
}
function ws_artifacts(int $uid, ?int $projectId = null, int $limit = 50): array {
    $limit=max(1,min(100,$limit)); $where='user_id=?'; $args=[$uid];
    if ($projectId) { $where.=' AND project_id=?'; $args[]=$projectId; }
    $st=db()->prepare('SELECT id,project_id,conversation_id,type,title,content,version,created_at,updated_at FROM artifacts WHERE '.$where.' ORDER BY updated_at DESC LIMIT '.$limit);
    $st->execute($args); return array_map('ws_artifact_payload',$st->fetchAll());
}
function ws_artifact_get(int $uid,int $id): ?array {
    $st=db()->prepare('SELECT id,project_id,conversation_id,type,title,content,version,created_at,updated_at FROM artifacts WHERE id=? AND user_id=?');
    $st->execute([$id,$uid]); $a=$st->fetch(); return $a ? ws_artifact_payload($a) : null;
}
function ws_artifact_versions(int $uid,int $id): array {
    $st=db()->prepare('SELECT v.id,v.version_no,v.title,v.content,v.created_at FROM artifact_versions v JOIN artifacts a ON a.id=v.artifact_id WHERE v.artifact_id=? AND a.user_id=? ORDER BY v.version_no DESC');
    $st->execute([$id,$uid]); return $st->fetchAll();
}
function ws_artifact_create(int $uid,array $in): array {
    $type=(string)($in['type']??'document'); if(!ws_allowed_artifact_type($type)) throw new InvalidArgumentException('Jenis artifact tidak didukung.');
    $title=trim((string)($in['title']??'Artifact Baru')); $content=(string)($in['content']??'');
    if($title==='') $title='Artifact Baru'; if(mb_strlen($title)>160)$title=mb_substr($title,0,160);
    if(mb_strlen($content)>ARTIFACT_MAX_BYTES) throw new InvalidArgumentException('Artifact terlalu besar.');
    $pid=!empty($in['project_id'])?(int)$in['project_id']:null; $cid=!empty($in['conversation_id'])?(int)$in['conversation_id']:null;
    $pdo=db(); $pdo->beginTransaction();
    try {
        if($pid){
            $s=$pdo->prepare('SELECT id FROM projects WHERE id=? AND user_id=?');$s->execute([$pid,$uid]);if(!$s->fetch())throw new RuntimeException('Project tidak ditemukan.');
        }
        if($cid){
            $s=$pdo->prepare('SELECT id FROM conversations WHERE id=? AND user_id=? AND deleted_at IS NULL');$s->execute([$cid,$uid]);if(!$s->fetch())throw new RuntimeException('Percakapan tidak ditemukan.');
        }
        $pdo->prepare('INSERT INTO artifacts (user_id,project_id,conversation_id,type,title,content,version,created_at,updated_at) VALUES (?,?,?,?,?,?,1,NOW(),NOW())')
            ->execute([$uid,$pid,$cid,$type,$title,$content]);
        $id=(int)$pdo->lastInsertId();
        $pdo->prepare('INSERT INTO artifact_versions (artifact_id,user_id,version_no,title,content,created_at) VALUES (?,?,?,?,?,NOW())')->execute([$id,$uid,1,$title,$content]);
        $pdo->commit();
        $job=ws_job_create($uid,'artifact','Artifact created',[
            'project_id'=>$pid,'conversation_id'=>$cid,'payload'=>['artifact_id'=>$id,'version'=>1]
        ]);
        ws_job_update($uid,$job,'completed',100,null);
        return ws_artifact_get($uid,$id) ?? [];
    } catch(Throwable $e){$pdo->rollBack();throw $e;}
}
function ws_artifact_save(int $uid,array $in): array {
    $id=(int)($in['id']??0); $a=ws_artifact_get($uid,$id); if(!$a)throw new RuntimeException('Artifact tidak ditemukan.');
    $content=(string)($in['content']??$a['content']); $title=trim((string)($in['title']??$a['title']));
    if($title==='')$title=$a['title']; if(mb_strlen($content)>ARTIFACT_MAX_BYTES)throw new InvalidArgumentException('Artifact terlalu besar.');
    $next=(int)$a['version']+1; if($next>ARTIFACT_VERSION_LIMIT)throw new InvalidArgumentException('Batas versi artifact tercapai.');
    $type=(string)($in['type']??$a['type']); if(!ws_allowed_artifact_type($type))$type=(string)$a['type'];
    $pdo=db();$pdo->beginTransaction();
    try{
        $pdo->prepare('UPDATE artifacts SET type=?,title=?,content=?,version=?,updated_at=NOW() WHERE id=? AND user_id=?')->execute([$type,$title,$content,$next,$id,$uid]);
        $pdo->prepare('INSERT INTO artifact_versions (artifact_id,user_id,version_no,title,content,created_at) VALUES (?,?,?,?,?,NOW())')->execute([$id,$uid,$next,$title,$content]);
        $pdo->commit();
        $job=ws_job_create($uid,'artifact','Artifact version saved',[
            'project_id'=>$a['project_id'],'conversation_id'=>$a['conversation_id'],'payload'=>['artifact_id'=>$id,'version'=>$next]
        ]);
        ws_job_update($uid,$job,'completed',100,null);
        return ws_artifact_get($uid,$id) ?? [];
    }catch(Throwable $e){$pdo->rollBack();throw $e;}
}
function ws_artifact_restore(int $uid,int $id,int $version): array {
    $a=ws_artifact_get($uid,$id);if(!$a)throw new RuntimeException('Artifact tidak ditemukan.');
    $st=db()->prepare('SELECT title,content FROM artifact_versions WHERE artifact_id=? AND user_id=? AND version_no=?');$st->execute([$id,$uid,$version]);$v=$st->fetch();
    if(!$v)throw new RuntimeException('Versi artifact tidak ditemukan.');
    return ws_artifact_save($uid,['id'=>$id,'title'=>$v['title'],'content'=>$v['content']]);
}
function ws_provenance_add(int $uid, ?int $conversationId, ?int $messageId, string $sourceType, string $sourceId, string $title, ?string $locator=null, ?string $uri=null, array $meta=[]): void {
    if(!PROVENANCE_ENABLED)return;
    db()->prepare('INSERT INTO provenance (user_id,conversation_id,message_id,source_type,source_id,title,locator,uri,meta,created_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())')
        ->execute([$uid,$conversationId,$messageId,$sourceType,mb_substr($sourceId,0,120),mb_substr($title,0,255),$locator?mb_substr($locator,0,160):null,$uri?mb_substr($uri,0,1000):null,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
}
function ws_provenance_for_message(int $uid,int $messageId): array {
    $st=db()->prepare('SELECT id,source_type,source_id,title,locator,uri,meta,created_at FROM provenance WHERE user_id=? AND message_id=? ORDER BY id ASC');
    $st->execute([$uid,$messageId]); return $st->fetchAll();
}
