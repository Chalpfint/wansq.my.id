<?php
declare(strict_types=1);
require_once __DIR__ . '/compat.php';
/**
* WanSQ v3.2.4 configuration.
*
* KREDENSIAL PRODUKSI TIDAK BOLEH DITULIS DI FILE INI.
* Prioritas: environment variable > includes/config.local.php > default aman kosong.
* Jangan memasukkan secret production ke source release.
*/
$__local = [];
if (is_file(__DIR__ . '/config.local.php')) {
    $v = require __DIR__ . '/config.local.php';
    if (is_array($v)) $__local = $v;
}
function wansq_cfg(string $key, $default = '') {
    global $__local;
    $env = getenv($key);
    if ($env !== false && $env !== '') return $env;
    return array_key_exists($key, $__local) ? $__local[$key] : $default;
}
define('APP_NAME', 'WanSQ');
$__host = strtolower((string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
// Buang port (localhost:8080) dan bracket IPv6 sebelum menentukan apakah ini mesin dev lokal.
$__hostOnly = preg_replace('/:\d+$/', '', $__host);
$__isLocal = ($__hostOnly === 'localhost' || $__hostOnly === '127.0.0.1' || $__hostOnly === '[::1]'
    || str_starts_with($__hostOnly, '192.168.') || str_starts_with($__hostOnly, '10.') || str_ends_with($__hostOnly, '.local'));
if ($__isLocal) {
    // Sengaja TIDAK membaca config.local.php di sini: mesin dev lokal tidak boleh pernah
    // diam-diam tersambung ke kredensial produksi hanya karena config.local.php ada di disk.
    define('BASE_URL', (string)(getenv('BASE_URL') ?: '/wansq'));
    define('DB_HOST', (string)(getenv('DB_HOST') ?: '127.0.0.1'));
    define('DB_PORT', (string)(getenv('DB_PORT') ?: '3306'));
    define('DB_NAME', (string)(getenv('DB_NAME') ?: 'wansq_db'));
    define('DB_USER', (string)(getenv('DB_USER') ?: 'root'));
    define('DB_PASS', (string)(getenv('DB_PASS') ?: ''));
} else {
    // Production values MUST come from config.local.php or environment variables.
    define('BASE_URL', (string)wansq_cfg('BASE_URL', ''));
    define('DB_HOST', (string)wansq_cfg('DB_HOST', 'localhost'));
    define('DB_PORT', (string)wansq_cfg('DB_PORT', '3306'));
    define('DB_NAME', (string)wansq_cfg('DB_NAME', '')); // wajib diisi di config.local.php
    define('DB_USER', (string)wansq_cfg('DB_USER', '')); // wajib diisi di config.local.php
    define('DB_PASS', (string)wansq_cfg('DB_PASS', '')); // wajib diisi di config.local.php
}
function base_url(string $p = ''): string { return BASE_URL . $p; }
function full_url(string $p = ''): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'
        || (int)($_SERVER['SERVER_PORT'] ?? 80) === 443;
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return ($https ? 'https://' : 'http://') . $host . base_url($p);
}
define('GOOGLE_REDIRECT', full_url('/auth/google_callback.php'));
// ==========================================
// KREDENSIAL (WAJIB dari config.local.php / env vars — default kosong)
// ==========================================
define('GOOGLE_CLIENT_ID', (string)wansq_cfg('GOOGLE_CLIENT_ID', ''));
define('GOOGLE_CLIENT_SECRET', (string)wansq_cfg('GOOGLE_CLIENT_SECRET', ''));
// Groq (legacy/fallback). Bisa di-redirect ke OpenRouter lewat config.local.php
// dengan menset GROQ_BASE = https://openrouter.ai/api/v1 dan GROQ_API_KEY = key OpenRouter.
define('GROQ_API_KEY', (string)wansq_cfg('GROQ_API_KEY', ''));
define('GROQ_BASE', (string)wansq_cfg('GROQ_BASE', 'https://api.groq.com/openai/v1'));
// OpenRouter (gateway resmi untuk model Qwen)
define('OPENROUTER_BASE', (string)wansq_cfg('OPENROUTER_BASE', 'https://openrouter.ai/api/v1'));
define('OPENROUTER_API_KEY', (string)wansq_cfg('OPENROUTER_API_KEY', ''));
define('OPENROUTER_REFERER', (string)wansq_cfg('OPENROUTER_REFERER', full_url('/')));
define('OPENROUTER_TITLE', (string)wansq_cfg('OPENROUTER_TITLE', APP_NAME));
// ==========================================
// MODEL AI (ekosistem Qwen via OpenRouter — default CEPAT + BENAR)
// ==========================================
define('MODEL_CHAT', (string)wansq_cfg('MODEL_CHAT', 'qwen/qwen3-235b-a22b'));
define('MODEL_VISION', (string)wansq_cfg('MODEL_VISION', 'qwen/qwen2.5-vl-72b-instruct'));
define('MODEL_FAST', (string)wansq_cfg('MODEL_FAST', 'qwen/qwen3.8-27b'));
// Batas output. Adaptif: bila kredit provider kurang, llm.php menurunkannya sesuai "can only afford N".
define('MAX_OUTPUT_TOKENS', (int)wansq_cfg('MAX_OUTPUT_TOKENS', 16384));
// Daftar model fallback opsional (dipisah koma), mis. model ':free' OpenRouter. Kosong = nonaktif.
define('FREE_FALLBACK_MODELS', (string)wansq_cfg('FREE_FALLBACK_MODELS', ''));
// PERBAIKAN (KECEPATAN): 360000 → 120000 karakter; konteks ramping = Time-to-First-Token cepat.
define('CONTEXT_CHAR_BUDGET', (int)wansq_cfg('CONTEXT_CHAR_BUDGET', 120000));
define('TAVILY_API_KEY', (string)wansq_cfg('TAVILY_API_KEY', ''));
define('PISTON_API_URL', (string)wansq_cfg('PISTON_API_URL', ''));
// ==========================================
// FILE, UPLOAD, RATE LIMIT
// ==========================================
define('UPLOAD_DIR', __DIR__ . '/../uploads');
define('STORAGE_DIR', __DIR__ . '/../storage');
define('UPLOAD_MAX_BYTES', (int)wansq_cfg('UPLOAD_MAX_BYTES', defined('ORIGINAL_UPLOAD_LIMIT') ? ORIGINAL_UPLOAD_LIMIT : 20 * 1024 * 1024));
// PERBAIKAN: 30 → 60 request/menit agar pengguna yang bertanya beruntun tidak diblokir.
define('RATE_LIMIT_PER_MIN', (int)wansq_cfg('RATE_LIMIT_PER_MIN', 60));
// PERBAIKAN: total percobaan otomatis ke provider bila error transient (rate/timeout/network).
define('SEND_AUTO_RETRY', (int)wansq_cfg('SEND_AUTO_RETRY', 2));
require_once __DIR__ . '/config_ext.php';
// ==========================================
// PERFORMANCE & OPENROUTER DECISIONS (v3.2.4+ Optimizations)
// ==========================================
require_once __DIR__ . '/performance.php';           // Performance monitoring & query optimization
require_once __DIR__ . '/openrouter_decisions.php';  // GPT Luna 6 Decisions API
require_once __DIR__ . '/error_handler_v325.php';    // Enhanced error handling (v3.2.5)
require_once __DIR__ . '/model_router.php';          // Intelligent multi-model routing (v3.2.5)
// ==========================================
// SYSTEM PROMPT
// ==========================================
define('SYSTEM_PROMPT',
    'You are WanSQ, an independent multimodal AI assistant built on the principle of ' .
    '"Wànxiàng Qiānwèn · Shēnsī Qiúzhēn": explore the breadth of phenomena, ask meaningful ' .
    'questions, think deeply, and seek truth.' . "\n" .
    'Answer with clarity, depth, and rational rigor, addressing the essential dimensions of ' .
    'each subject professionally and logically while examining causes, mechanisms, ' .
    'consequences, context, assumptions, and underlying principles. Respond in a precise, ' .
    'analytical style inspired by scientific and academic discourse: sophisticated yet ' .
    'comprehensible, evidence-oriented, and never unnecessarily verbose.' . "\n" .
    'Act as an expert interdisciplinary tutor across sciences, mathematics, social sciences, ' .
    'humanities, and related fields, capable of explaining complex or obscure subjects through ' .
    'rigorous reasoning, identifying hidden variables, overlooked implications, alternative ' .
    'perspectives, interdisciplinary connections, limitations, and uncertainties. Distinguish ' .
    'established facts from inference, interpretation, and speculation; challenge flawed ' .
    'assumptions constructively; and pursue deeper understanding rather than superficial ' .
    'answers. Analyze each question as part of an evolving intellectual dialogue, refining the ' .
    'problem and asking meaningful follow-up questions when they materially improve the ' .
    'reasoning. Conclude in coherent paragraphs unless another format is genuinely necessary.' . "\n" .
    'Adaptivity rule: always mirror the language, requested format, and desired depth of the ' .
    'user. If the user asks for brevity, be brief; if they ask for code, provide code; if they ' .
    'ask for a table, provide a table. When tool results (search, calculator, documents) are ' .
    'supplied, use them explicitly and cite their sources.' . "\n" .
    'Mathematics: the chat UI supports MathJax LaTeX. Use standard LaTeX for mathematical ' .
    'expressions when it improves clarity: inline \( ... \) and display \[ ... \]. Do not ' .
    'put LaTeX inside code fences unless the user explicitly asks for source code. Keep code, ' .
    'inline code, URLs, and literal text untouched.'
);