<?php
declare(strict_types=1);
/** WanSQ · Helper percakapan: kepemilikan, lampiran, title, follow-up, transform. */

function chat_own_conv(int $id, int $uid, bool $any = false): ?array {
    $st = db()->prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?' . ($any ? '' : ' AND deleted_at IS NULL'));
    $st->execute(array($id, $uid));
    $r = $st->fetch();
    return $r ? $r : null;
}
function chat_own_project(int $id, int $uid): ?array {
    if ($id <= 0) return null;
    $st = db()->prepare('SELECT * FROM projects WHERE id=? AND user_id=?'); $st->execute(array($id, $uid));
    $r = $st->fetch(); return $r ? $r : null;
}
function share_url(string $token): string { return full_url('/share.php?t=' . $token); }

function chat_style_instruction(string $style): string {
    $m = array(
        'shorter'  => 'Instruksi regenerasi: tulis ulang jawaban Anda untuk pesan pengguna terakhir dengan versi LEBIH RINGKAS (sekitar separuh panjang) tanpa menghilangkan poin inti.',
        'detailed' => 'Instruksi regenerasi: tulis ulang jawaban Anda untuk pesan pengguna terakhir dengan versi LEBIH RINCI dan mendalam: mekanisme, contoh, batasan, dan implikasi.',
        'formal'   => 'Instruksi regenerasi: tulis ulang jawaban Anda untuk pesan pengguna terakhir dengan gaya LEBIH FORMAL dan akademik (istilah tepat, struktur runtut).',
    );
    return $m[$style] ?? '';
}
function chat_transform_instruction(string $kind, string $to = 'id'): string {
    $m = array(
        'summarize' => 'Ringkas jawaban di bawah menjadi versi padat tanpa kehilangan poin kunci.',
        'clarify'   => 'Perjelas jawaban di bawah: sederhanakan struktur kalimat, uraikan istilah sulit, beri satu contoh singkat bila membantu.',
        'table'     => 'Ubah isi jawaban di bawah menjadi tabel Markdown yang rapi (pilih kolom yang sesuai isi), beri satu kalimat pengantar saja.',
        'bullets'   => 'Ubah jawaban di bawah menjadi poin-poin penting (maksimal 7 poin, tiap poin satu kalimat padat).',
        'translate' => $to === 'en' ? 'Translate the answer below into natural, accurate English. Keep formatting (lists, tables, code).' : 'Terjemahkan jawaban di bawah ke Bahasa Indonesia yang alami dan akurat. Pertahankan format (daftar, tabel, kode).',
        'academic'  => 'Tulis ulang jawaban di bawah dengan gaya lebih akademik: istilah tepat, argumen runtut, tetap ringkas.',
        'simple'    => 'Tulis ulang jawaban di bawah dengan bahasa lebih sederhana untuk pemula, gunakan analogi singkat bila perlu.',
    );
    return $m[$kind] ?? '';
}

/** Lampiran gambar terbaru pada percakapan (sebelum pesan ini). */
function chat_prev_images(int $convId, int $uid, int $limit = 3): array {
    $st = db()->prepare("SELECT * FROM attachments WHERE conversation_id=? AND user_id=? AND kind='image' AND removed=0 AND message_id IS NOT NULL ORDER BY id DESC LIMIT " . (int)$limit);
    $st->execute(array($convId, $uid));
    return array_reverse($st->fetchAll());
}

function chat_title_fallback(string $userText, string $answer = ''): string {
    $t = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $userText)));
    $stop = '/\b(tolong|mohon|please|bisa|dapatkah|coba|buatkan|buat|jelaskan|terangkan|apa|apakah|bagaimana|kenapa|mengapa|saya|aku|kami|kamu|anda|untuk|yang|dengan|tentang|ini|itu|jadi|sebuah|sebagai|kepada|dari|dan|atau|the|a|an|please|can|could|make|create|explain|what|why|how|about|this|that)\b/iu';
    $clean = trim(preg_replace($stop, ' ', $t));
    $clean = trim(preg_replace('/[^\p{L}\p{N}\s+\-?]/u', ' ', $clean));
    $clean = trim(preg_replace('/\s+/u', ' ', $clean));
    $map = [
        '/\b(integral|turunan|derivatif|limit|matriks|logaritma|persamaan)\b/iu' => 'Matematika',
        '/\b(ipa|fisika|biologi|kimia)\b/iu' => 'Sains',
        '/\b(program|coding|kode|debug|php|javascript|python|sql|html|css)\b/iu' => 'Pemrograman',
        '/\b(pdf|dokumen|file|materi|makalah|laporan)\b/iu' => 'Analisis Dokumen',
        '/\b(berita|terbaru|harga|kurs|cuaca|jadwal)\b/iu' => 'Informasi Terkini',
        '/\b(gambar|ilustrasi|poster|logo|desain)\b/iu' => 'Pembuatan Gambar',
        '/\b(soal|latihan|ujian|kuis)\b/iu' => 'Latihan Belajar',
    ];
    foreach ($map as $re => $label) if (preg_match($re, $t)) {
        if (preg_match('/\b(soal|latihan|ujian|kuis)\b/iu', $t)) {
            $subject = preg_match('/\b(ipa|fisika|biologi|kimia|matematika|sejarah|bahasa indonesia|bahasa inggris)\b/iu', $t, $m) ? ucfirst($m[1]) : '';
            return trim('Soal Latihan ' . $subject);
        }
        if (preg_match('/\b(kenapa|mengapa)\b/iu', $t)) {
            $q = trim(preg_replace('/^.*?\b(kenapa|mengapa)\b/iu', '', $t));
            return mb_convert_case(mb_substr($q, 0, 42), MB_CASE_TITLE, 'UTF-8') . '?';
        }
        return $label;
    }
    $words = preg_split('/\s+/u', $clean, -1, PREG_SPLIT_NO_EMPTY);
    $words = array_slice($words, 0, 6);
    $title = trim(implode(' ', $words));
    if ($title === '') {
        $a = trim(preg_replace('/\s+/u', ' ', $answer));
        $title = mb_substr($a, 0, 42);
    }
    $title = trim(preg_replace('/[.!:;]+$/u', '', $title));
    return mb_substr($title !== '' ? mb_convert_case($title, MB_CASE_TITLE, 'UTF-8') : 'Percakapan Baru', 0, 60);
}

function chat_title(string $userText, string $answer): string {
    $r = llm_call('fast', array('temperature' => 0.15, 'max_completion_tokens' => 80, 'messages' => array(
        array('role' => 'system', 'content' => 'Buat judul topik percakapan 2–7 kata. Gunakan bahasa pengguna. Fokus pada INTENT dan TOPIK, bukan menyalin kalimat pembuka. Gunakan user request sebagai sumber utama dan jawaban assistant hanya untuk disambiguasi. Tanpa kutip, tanpa "Judul:", tanpa titik, tanpa basa-basi.'),
        array('role' => 'user', 'content' => "USER REQUEST:\n" . mb_substr($userText, 0, 700) . "\n\nASSISTANT ANSWER:\n" . mb_substr($answer, 0, 700)))), 10);
    $t = $r['ok'] ? trim(preg_split('/\R/', trim($r['text']))[0]) : '';
    $t = trim(preg_replace('/^(judul\s*[:\-]\s*)/iu', '', $t));
    $t = trim(preg_replace('/^["\'“”\s]+|["\'“”.\s]+$/u', '', $t));
    if ($t === '' || mb_strlen($t) < 2) $t = chat_title_fallback($userText, $answer);
    return mb_substr($t, 0, 60);
}

/** Saran lanjutan kontekstual. Kosong bila tidak berguna (jawaban singkat/trivial). */
function chat_followups(string $userText, string $answer, array $ctx): array {
    if (!FOLLOWUPS_ENABLED) return array();
    $alen = mb_strlen($answer);
    if ($alen < 380 || mb_strlen($userText) < 14) return array();
    if (!empty($ctx['calc_only']) || !empty($ctx['fast']) || !empty($ctx['partial']) || !empty($ctx['image'])) return array();
    $rich = !empty($ctx['docs']) || !empty($ctx['vision']) || !empty($ctx['web']) || $alen > 1200;
    $max = $rich ? 3 : 2;
    $sys = "Anda menyusun saran tindak lanjut untuk asisten AI. Beri 0 sampai $max saran yang BENAR-BENAR berguna dan spesifik terhadap isi percakapan (bukan generik). "
         . "Jika tidak ada langkah lanjutan yang bernilai, kembalikan daftar kosong. Ketik dalam bahasa yang sama dengan jawaban. "
         . 'Keluaran HANYA JSON: {"items":[{"label":"maks 4 kata (kata kerja: Bandingkan, Buat tabel, Beri contoh, Dalami …)","prompt":"kalimat permintaan lengkap dari sudut pandang pengguna, merujuk konteks spesifik"}]}. '
         . 'Dilarang: "Apakah Anda ingin tahu lebih lanjut?", "Ada pertanyaan lain?", atau saran yang tidak bergantung pada isi jawaban.';
    $usr = 'Pertanyaan pengguna: ' . mb_substr($userText, 0, 500) . "\n\nJawaban asisten:\n" . mb_substr($answer, 0, 2200)
         . (!empty($ctx['docs']) ? "\n\n(Konteks: pengguna melampirkan dokumen: " . implode(', ', array_slice((array)$ctx['docs'], 0, 3)) . ')' : '')
         . (!empty($ctx['vision']) ? "\n\n(Konteks: analisis gambar)" : '');
    $r = llm_call('fast', array('temperature' => 0.4, 'max_completion_tokens' => 600, 'messages' => array(array('role' => 'system', 'content' => $sys), array('role' => 'user', 'content' => $usr))), 12);
    if (!$r['ok']) return array();
    if (!preg_match('/\{.*\}/s', $r['text'], $m)) return array();
    $j = json_decode($m[0], true); if (!is_array($j) || empty($j['items']) || !is_array($j['items'])) return array();
    $out = array();
    foreach ($j['items'] as $it) {
        $l = trim((string)($it['label'] ?? '')); $p = trim((string)($it['prompt'] ?? ''));
        if ($l === '' || mb_strlen($p) < 12 || mb_strlen($l) > 42 || mb_strlen($p) > 260) continue;
        if (preg_match('/tahu lebih lanjut|know more|pertanyaan lain|anything else|lainnya\?/iu', $l . ' ' . $p)) continue;
        $out[] = array('label' => $l, 'prompt' => $p);
        if (count($out) >= $max) break;
    }
    return $out;
}

/** Hapus fisik berkas lampiran milik percakapan (dipakai purge permanen). */
function chat_purge_files(int $convId, int $uid): void {
    $st = db()->prepare('SELECT stored_path,kind FROM attachments WHERE conversation_id=? AND user_id=?'); $st->execute(array($convId, $uid));
    foreach ($st->fetchAll() as $a) { $f = stored_to_fs((string)$a['stored_path']); if (is_file($f)) @unlink($f); }
}
/** Hapus permanen percakapan di trash yang lewat batas TRASH_DAYS (dipanggil sesekali). */
function chat_trash_sweep(int $uid): void {
    $st = db()->prepare('SELECT id FROM conversations WHERE user_id=? AND deleted_at IS NOT NULL AND deleted_at < (NOW() - INTERVAL ' . (int)TRASH_DAYS . ' DAY)');
    $st->execute(array($uid));
    foreach ($st->fetchAll() as $r) { chat_purge_files((int)$r['id'], $uid); db()->prepare('DELETE FROM conversations WHERE id=? AND user_id=?')->execute(array($r['id'], $uid)); }
}
