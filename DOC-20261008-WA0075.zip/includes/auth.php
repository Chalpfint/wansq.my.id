<?php
declare(strict_types=1);

function session_boot(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name('wansq_sid');
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'
        || (int)($_SERVER['SERVER_PORT'] ?? 80) === 443;
    session_set_cookie_params(['lifetime' => 86400 * 7, 'path' => '/', 'domain' => '',
        'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
function session_touch(): void {
    if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['uid'])) return;
    $_SESSION['ts'] = time();
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int)($_SERVER['SERVER_PORT'] ?? 80) === 443;
    setcookie(session_name(), session_id(), ['expires' => time() + 86400 * 7, 'path' => '/',
        'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
}
function no_store(): void {
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
}
function current_user(): ?array {
    static $u = null;
    if ($u !== null) return $u ?: null;
    if (empty($_SESSION['uid'])) { $u = false; return null; }
    $st = db()->prepare('SELECT * FROM users WHERE id = ?');
    $st->execute([(int)$_SESSION['uid']]);
    $u = $st->fetch() ?: false;
    return $u ?: null;
}
function login_user(int $uid): void {
    session_regenerate_id(true);
    $_SESSION['uid'] = $uid; $_SESSION['ts'] = time();
    unset($_SESSION['csrf']);
}
function logout_user(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}
function schema_ready(): bool {
    static $ok = null;
    if ($ok !== null) return $ok;
    try {
        $pdo = db();
        $v = (string)$pdo->query("SELECT v FROM schema_meta WHERE k='schema'")->fetchColumn();
        if (version_compare($v, '4.1.4', '<')) return $ok = false;
        $tables = ['users','conversations','messages','attachments','feedback','memories','rate_limits','rate_buckets','schema_meta','projects','project_memories','doc_chunks','shares','conversation_branches','artifacts','artifact_versions','jobs','memory_meta','provenance'];
        $ph = implode(',', array_fill(0, count($tables), '?'));
        $st = $pdo->prepare("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ($ph)");
        $st->execute($tables); $found = array_fill_keys(array_map('strval', $st->fetchAll(PDO::FETCH_COLUMN)), true);
        foreach ($tables as $t) if (!isset($found[$t])) return $ok = false;
        $cols = [
          'jobs'=>['heartbeat_at','result_ref'],
          'users'=>['ui_lang','reply_lang'],
          'conversations'=>['pinned','project_id','deleted_at','topic','intent','tools_used','summary','summary_upto_id'],
          'messages'=>['active','pinned','pinned_at','pin_label','cid','superseded_at'],
          'attachments'=>['conversation_id','project_id','status','pages','ocr_pages','vision_summary','removed','sha256','original_mime','width','height','processing_stage','processor','processing_error','generated_from_id','derivative_path','derivative_reason','provider_file_id','vision_status','ocr_status','extracted_chars','last_processed_at','original_size','processed_size','original_width','original_height','processed_width','processed_height','preview_path','preview_mime','preview_size','preview_width','preview_height','preview_mode','preview_generated_at','preview_error','ai_status','ai_ready_at','processing_started_at','processing_finished_at','processing_attempts']
        ];
        foreach ($cols as $table=>$names) {
            $ph2=implode(',',array_fill(0,count($names),'?')); $args=array_merge([$table],$names);
            $st=$pdo->prepare("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME IN ($ph2)");
            $st->execute($args); $got=array_fill_keys(array_map('strval',$st->fetchAll(PDO::FETCH_COLUMN)),true);
            foreach($names as $c) if(!isset($got[$c])) return $ok=false;
        }
        return $ok=true;
    } catch (Throwable $e) { return $ok=false; }
}
function require_api_login(): array {
    $u = current_user();
    if (!$u) json_out(['ok' => false, 'error' => 'Sesi berakhir. Silakan login kembali.'], 401);
    if (!schema_ready()) json_out(['ok' => false, 'error' => 'Skema database WanSQ belum siap untuk release 3.2.4. Jalankan sql/wansq_upgrade_v4.1.4.sql di Navicat Premium Lite, lalu muat ulang.', 'code' => 'schema'], 503);
    session_touch();
    return $u;
}
function user_avatar_url(array $u): string {
    if ($u['avatar_local'] !== '') return base_url('/' . $u['avatar_local']);
    if ($u['avatar_google'] !== '') return $u['avatar_google'];
    return base_url('/assets/img/avatar-default.svg');
}