<?php
declare(strict_types=1);
/** WanSQ · Engine routing (UI) — model sesungguhnya dipilih oleh includes/llm.php */
require_once __DIR__ . '/groq.php';
require_once __DIR__ . '/llm.php';

if (!function_exists('wansq_engines')) {
function wansq_engines(): array {
    return array(
        'auto'   => array('label' => 'Auto',      'desc' => 'Orchestrator memilih route terbaik secara otomatis', 'role' => 'chat'),
        'thinking'=> array('label' => 'Thinking', 'desc' => 'Penalaran lebih dalam untuk tugas kompleks', 'role' => 'chat'),
        'fast'   => array('label' => 'Fast',    'desc' => 'Respons cepat dengan capability tetap aktif', 'role' => 'fast'),
    );
}
}
if (!function_exists('resolve_engine')) {
function resolve_engine(string $want, bool $hasImages = false): array {
    $eng = wansq_engines();
    // Backward compatibility for old localStorage / persisted requests.
    if ($want === 'reason') $want = 'thinking';
    if ($want === 'vision') $want = 'auto';
    if (!isset($eng[$want])) $want = 'auto';
    $max = array('auto' => MAX_OUTPUT_TOKENS, 'thinking' => MAX_OUTPUT_TOKENS, 'fast' => 4096);
    // Bila gambar dikirim langsung ke model (route vision_direct), role HARUS 'vision'; kalau tidak, gambar dikirim
    // ke model teks (mis. gpt-oss) yang menolaknya dan baru berhasil setelah beberapa percobaan gagal + fallback.
    $role = $hasImages ? 'vision' : $eng[$want]['role'];
    return array('key' => $want, 'label' => $eng[$want]['label'], 'role' => $role, 'max_tokens' => $max[$want]);
}
}
