<?php
declare(strict_types=1);
/**
 * WanSQ · Lapisan persepsi (Vision/OCR).
 * Vision = MEMAHAMI gambar. Hasilnya berupa informasi terstruktur untuk model reasoning
 * (bukan jawaban final), kecuali untuk permintaan murni persepsi (deskripsikan/baca teks).
 */
function vision_perception_prompt(): string {
    return "Anda adalah LAPISAN PERSEPSI WanSQ. Tugas: mengamati gambar dengan teliti dan mengekstrak informasi faktual bagi model penalar. "
        . "JANGAN menjawab final, JANGAN berspekulasi tanpa menandainya. Tulis dalam bahasa Indonesia dengan bagian berikut (lewati bagian yang tidak relevan):\n"
        . "1) RINGKASAN: apa isi gambar (jenis: foto/grafik/diagram/tabel/dokumen/screenshot).\n"
        . "2) TEKS TERBACA: salin teks yang tampak PERSIS (verbatim) sesuai urutan baca; tandai [tidak jelas] bila ragu.\n"
        . "3) DATA: untuk grafik/tabel sebutkan judul, sumbu+satuan, legenda, nilai/angka penting, tren; tabel ditulis sebagai tabel Markdown.\n"
        . "4) ELEMEN & TATA LETAK: objek, warna, posisi relatif, simbol, rumus.\n"
        . "5) KETIDAKPASTIAN: hal yang tidak terbaca/ambigu.\n"
        . "Jangan mengidentifikasi orang nyata dari wajah; boleh memakai teks yang tertulis (nama pada label/keterangan). "
        . "Bila pengguna mengajukan pertanyaan, fokuskan ekstraksi pada detail yang relevan dengan pertanyaan itu.";
}
function vision_direct_prompt(): string {
    return "Anda adalah WanSQ. Analisis gambar terlampir secara menyeluruh dan jawab dalam bahasa pengguna: jelaskan isi, baca teks yang tampak, "
        . "identifikasi objek/konsep, dan bila ada data (grafik/tabel) uraikan angka pentingnya. Jangan mengidentifikasi orang nyata dari wajah; "
        . "gunakan teks/keterangan yang terlihat bila ada, dan katakan dengan jujur bila sesuatu tidak dapat dipastikan.";
}
/** Permintaan murni persepsi → vision boleh menjawab langsung (lebih cepat). */
function vision_is_direct(string $text): bool {
    $t = mb_strtolower(trim($text));
    if ($t === '') return true;
    if (mb_strlen($t) > 160) return false;
    return (bool)preg_match('/^(tolong\s+)?(ini (tuh |itu )?(game|apa|siapa|film|aplikasi|tempat|merek|hewan|tanaman)|apa (ini|itu|isi(nya)?)|ini apa|itu apa|siapa|deskripsikan|jelaskan gambar|jelaskan foto|gambarkan|analisis (gambar|foto)|baca(kan)?( teks| tulisan)?|transkrip|ocr|describe|what(\'s| is) (this|in)|read (the )?text|apa yang (ada|terlihat)|siapakah)/u', $t);
}

/** Bangun bagian konten image_url dari baris attachments. Return [parts, missing]. */
/** Path fisik untuk inferensi vision: derivative ternormalisasi bila ada, jatuh ke original bila belum (baris lama). */
function vision_infer_path(array $img): string {
    if (!empty($img['derivative_path'])) {
        $d = stored_to_fs((string)$img['derivative_path']);
        if (is_file($d)) return $d;
    }
    return stored_to_fs((string)$img['stored_path']);
}
function vision_image_parts(array $imgs): array {
    $parts = array(); $missing = 0;
    foreach (array_slice($imgs, 0, MAX_IMAGES) as $img) {
        $fs = vision_infer_path($img);
        try { $parts[] = array('type' => 'image_url', 'image_url' => array('url' => data_url($fs))); }
        catch (Throwable $e) { $missing++; app_log('vision skip: ' . basename($fs)); }
    }
    return array($parts, $missing);
}

/**
 * Persepsi query-aware. Return: ok, text, ms, model, err.
 */
function vision_perceive(array $imgs, string $question, int $maxTokens = 1800): array {
    list($parts, $missing) = vision_image_parts($imgs);
    if (!$parts) return array('ok' => false, 'text' => '', 'ms' => 0, 'model' => null, 'err' => 'Gambar tidak dapat dibaca dari storage');
    $q = trim($question) !== '' ? "Pertanyaan pengguna (untuk memfokuskan ekstraksi): " . mb_substr($question, 0, 800) : 'Tidak ada pertanyaan spesifik; ekstraksi menyeluruh.';
    $content = array_merge(array(array('type' => 'text', 'text' => $q)), $parts);
    $r = llm_call('vision', array(
        'messages' => array(array('role' => 'system', 'content' => vision_perception_prompt()), array('role' => 'user', 'content' => $content)),
        'max_completion_tokens' => $maxTokens, 'temperature' => 0.2), 90);
    return array('ok' => $r['ok'], 'text' => $r['text'], 'ms' => $r['ms'], 'model' => $r['model'], 'err' => $r['err'], 'kind' => $r['kind']);
}

/** OCR satu halaman (gambar JPEG/PNG biner). Return teks atau null. */
function vision_ocr_page(string $imgBinary, string $mime, int $page): array {
    $url = 'data:' . $mime . ';base64,' . base64_encode($imgBinary);
    $sys = "Anda adalah mesin OCR. Transkripsikan SELURUH teks pada gambar halaman ini persis apa adanya, sesuai urutan baca (kolom kiri→kanan, atas→bawah). "
         . "Pertahankan judul, daftar, dan rumus; tabel tulis sebagai tabel Markdown. Untuk gambar/grafik/diagram tanpa teks tulis satu baris [gambar: deskripsi singkat]. "
         . "JANGAN menambah komentar, penjelasan, atau kata pembuka. Bila halaman kosong, jawab persis: [halaman kosong]";
    $r = llm_call('vision', array(
        'messages' => array(array('role' => 'system', 'content' => $sys),
            array('role' => 'user', 'content' => array(array('type' => 'text', 'text' => 'Halaman ' . $page), array('type' => 'image_url', 'image_url' => array('url' => $url))))),
        'max_completion_tokens' => 4096, 'temperature' => 0.0), 90);
    return $r;
}
