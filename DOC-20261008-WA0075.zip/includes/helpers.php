<?php
declare(strict_types=1);
/** WanSQ · Helpers — kompatibel PHP 7.4+ */
require_once __DIR__ . '/compat.php';
require_once __DIR__ . '/config_ext.php';

if (!defined('APP_VERSION')) define('APP_VERSION', '3.2.4');

function e(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function json_out(array $d, int $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_in(): array {
    $j = json_decode((string)file_get_contents('php://input'), true);
    return is_array($j) ? $j : [];
}

function app_log(string $msg): void {
    $dir = STORAGE_DIR . '/logs';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($dir . '/app.log', date('c') . ' ' . $msg . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['csrf'];
}
function csrf_check(): void {
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
    if (!is_string($sent) || $sent === '' || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        json_out(['ok' => false, 'error' => 'CSRF invalid'], 403);
    }
}

function rate_limit_ok(int $uid): bool {
    $now = time(); $pdo = db();
    $st = $pdo->prepare('SELECT window_start, hits FROM rate_limits WHERE user_id = ?');
    $st->execute([$uid]); $row = $st->fetch();
    if (!$row || ($now - (int)$row['window_start']) >= 60) {
        $pdo->prepare('REPLACE INTO rate_limits (user_id, window_start, hits) VALUES (?,?,1)')->execute([$uid, $now]);
        return true;
    }
    if ((int)$row['hits'] >= RATE_LIMIT_PER_MIN) return false;
    $pdo->prepare('UPDATE rate_limits SET hits = hits + 1 WHERE user_id = ?')->execute([$uid]);
    return true;
}

function time_greet(): string {
    $h = (int)date('G');
    return $h < 11 ? 'Selamat pagi' : ($h < 15 ? 'Selamat siang' : ($h < 19 ? 'Selamat sore' : 'Selamat malam'));
}

/* ---------- Kalkulator aman (shunting-yard, tanpa eval, tanpa match) ---------- */
function safe_calc(string $expr): ?float {
    $expr = str_replace([',', '×', '÷', '−', '√'], ['.', '*', '/', '-', 'sqrt'], $expr);
    $funcs = ['sqrt','sin','cos','tan','log','ln','abs','round','floor','ceil'];
    $tok = []; $i = 0; $n = strlen($expr); $prev = null;
    while ($i < $n) {
        $c = $expr[$i];
        if (ctype_space($c)) { $i++; continue; }
        if (ctype_digit($c) || $c === '.') {
            $j = $i; while ($j < $n && (ctype_digit($expr[$j]) || $expr[$j] === '.')) $j++;
            $tok[] = ['num', (float)substr($expr, $i, $j - $i)]; $prev = 'num'; $i = $j; continue;
        }
        if (ctype_alpha($c)) {
            $j = $i; while ($j < $n && ctype_alpha($expr[$j])) $j++;
            $w = strtolower(substr($expr, $i, $j - $i));
            if ($w === 'pi') { $tok[] = ['num', M_PI]; }
            elseif ($w === 'e') { $tok[] = ['num', M_E]; }
            elseif (in_array($w, $funcs, true)) { $tok[] = ['func', $w]; }
            else return null;
            $prev = 'num'; $i = $j; continue;
        }
        if (strpos('+-*/%^()', $c) !== false) {
            if ($c === '-' && ($prev === null || $prev === 'op')) $tok[] = ['op', 'u-'];
            else $tok[] = ['op', $c];
            $prev = 'op'; $i++; continue;
        }
        return null;
    }
    $prec = ['+' => 1, '-' => 1, '*' => 2, '/' => 2, '%' => 2, 'u-' => 3, '^' => 4];
    $out = []; $ops = [];
    foreach ($tok as $t) {
        if ($t[0] === 'num') { $out[] = $t; continue; }
        if ($t[0] === 'func') { $ops[] = $t; continue; }
        if ($t[1] === '(') { $ops[] = $t; continue; }
        if ($t[1] === ')') {
            while ($ops && end($ops)[1] !== '(') $out[] = array_pop($ops);
            if (!$ops) return null;
            array_pop($ops);
            if ($ops && end($ops)[0] === 'func') $out[] = array_pop($ops);
            continue;
        }
        while ($ops && end($ops)[0] === 'op' && end($ops)[1] !== '('
               && $prec[end($ops)[1]] > $prec[$t[1]]) {
            $out[] = array_pop($ops);
        }
        $ops[] = $t;
    }
    while ($ops) { $o = array_pop($ops); if ($o[1] === '(') return null; $out[] = $o; }

    $fmap = ['sqrt'=>'sqrt','sin'=>'sin','cos'=>'cos','tan'=>'tan','log'=>'log10',
             'ln'=>'log','abs'=>'abs','round'=>'round','floor'=>'floor','ceil'=>'ceil'];
    $st = [];
    foreach ($out as $t) {
        if ($t[0] === 'num') { $st[] = $t[1]; continue; }
        if ($t[0] === 'func') {
            if (!$st || !isset($fmap[$t[1]])) return null;
            $fn = $fmap[$t[1]];
            $st[] = (float)$fn((float)array_pop($st));
            continue;
        }
        if ($t[1] === 'u-') { if (!$st) return null; $st[] = -(float)array_pop($st); continue; }
        if (count($st) < 2) return null;
        $b = (float)array_pop($st); $a = (float)array_pop($st);
        switch ($t[1]) {
            case '+': $st[] = $a + $b; break;
            case '-': $st[] = $a - $b; break;
            case '*': $st[] = $a * $b; break;
            case '/': if ($b === 0.0) return null; $st[] = $a / $b; break;
            case '%': if ($b === 0.0) return null; $st[] = fmod($a, $b); break;
            case '^': $st[] = pow($a, $b); break;
            default:  return null;
        }
    }
    if (count($st) !== 1 || is_nan($st[0]) || is_infinite($st[0])) return null;
    return $st[0];
}

function math_candidates(string $text): array {
    $res = [];
    if (preg_match('/^[\s\d\.\+\-\*\/\^\%\(\)a-z,×÷√]+$/i', $text) && preg_match('/\d/', $text)) {
        $v = safe_calc($text); if ($v !== null) $res[] = [trim($text), $v];
    }
    preg_match_all('/[-+]?\(?\d+(?:\.\d+)?\)?(?:\s*[-+*\/^%]\s*\(?\d+(?:\.\d+)?\)?)+/', $text, $m);
    foreach (array_slice($m[0], 0, 3) as $cand) {
        $v = safe_calc($cand); if ($v !== null) $res[] = [$cand, $v];
    }
    return $res;
}

function fmt_num(float $f): string {
    return (abs($f - round($f)) < 1e-9) ? (string)(int)round($f) : rtrim(rtrim(number_format($f, 10, '.', ''), '0'), '.');
}

/** Rate limit generik per bucket (jendela 60 detik). */
function rate_bucket_ok(int $uid, string $bucket, int $limit): bool {
    $now = time(); $pdo = db();
    try {
        $st = $pdo->prepare('SELECT window_start, hits FROM rate_buckets WHERE user_id=? AND bucket=?'); $st->execute([$uid, $bucket]); $row = $st->fetch();
        if (!$row || ($now - (int)$row['window_start']) >= 60) { $pdo->prepare('REPLACE INTO rate_buckets (user_id,bucket,window_start,hits) VALUES (?,?,?,1)')->execute([$uid, $bucket, $now]); return true; }
        if ((int)$row['hits'] >= $limit) return false;
        $pdo->prepare('UPDATE rate_buckets SET hits=hits+1 WHERE user_id=? AND bucket=?')->execute([$uid, $bucket]);
    } catch (Throwable $e) { return true; }
    return true;
}
function kw_stopwords(): array {
    static $sw = null;
    if ($sw === null) $sw = array_flip(['dengan','untuk','yang','dan','atau','pada','dari','kepada','adalah','tentang','bagaimana','mengapa','karena',
        'apa','itu','ini','oleh','saya','kamu','anda','akan','dapat','bisa','sudah','telah','juga','agar','dalam','ada','tidak','bukan','lebih',
        'the','and','for','with','that','this','from','what','how','why','are','was','were','have','has','can','you','your','about','into']);
    return $sw;
}
/** Token pencarian/relevansi: huruf/angka >= 3 karakter, tanpa stopword. */
function keywordize(string $s): array {
    preg_match_all('/[\p{L}\p{N}]{3,}/u', mb_strtolower($s), $m);
    $sw = kw_stopwords(); $out = [];
    foreach ($m[0] as $w) if (!isset($sw[$w])) $out[$w] = true;
    return array_keys($out);
}
function uuid_short(): string { return bin2hex(random_bytes(12)); }
function ms_since(float $t0): int { return (int)round((microtime(true) - $t0) * 1000); }
/** Potong teks per kalimat/karakter tanpa memenggal kata secara kasar. */
function clip(string $s, int $n): string {
    if (mb_strlen($s) <= $n) return $s;
    $c = mb_substr($s, 0, $n);
    $p = max(mb_strrpos($c, "\n") ?: 0, mb_strrpos($c, '. ') ?: 0, mb_strrpos($c, ' ') ?: 0);
    return rtrim($p > $n * 0.6 ? mb_substr($c, 0, $p) : $c) . '…';
}
