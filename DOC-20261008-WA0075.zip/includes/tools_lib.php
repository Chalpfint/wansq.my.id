<?php
declare(strict_types=1);

function detect_search_need(string $t, bool $manual): bool {
    if ($manual) return true;
    return (bool)preg_match('/\b(cari|carikan|search|telusuri|browse|cek di web|gunakan sumber terbaru|sumber terbaru|informasi terbaru|berita terbaru|harga sekarang|harga terbaru|kurs|cuaca|jadwal|riset|referensi|latest|news|current|today|terkini|sekarang|update|release notes|versi terbaru)\b/iu', $t);
}

function web_http_get(string $url, int $timeout = 12, array $headers = []): string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_MAXREDIRS => 3,
        CURLOPT_ENCODING => '', CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; WanSQ/3.2; +https://wansq.my.id)',
        CURLOPT_HTTPHEADER => array_merge(['Accept-Language: id,en;q=0.8'], $headers)]);
    $r = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
    return ($r !== false && $http >= 200 && $http < 300) ? (string)$r : '';
}
function web_clean(string $s, int $n = 400): string {
    $s = html_entity_decode(strip_tags($s), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return mb_substr(trim(preg_replace('/\s+/u', ' ', $s)), 0, $n);
}
/** Parser hasil html.duckduckgo.com/html (dipisah agar dapat diuji tanpa jaringan). */
function web_parse_ddg_html(string $html, int $max = 6): array {
    $out = [];
    if (!preg_match_all('~<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>(.*?)</a>~is', $html, $a, PREG_SET_ORDER)) return $out;
    preg_match_all('~class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</(?:a|td|div)>~is', $html, $sn);
    foreach ($a as $i => $m) {
        $u = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('~[?&]uddg=([^&]+)~', $u, $q)) $u = urldecode($q[1]);
        if (strpos($u, '//') === 0) $u = 'https:' . $u;
        if (!preg_match('~^https?://~i', $u)) continue;
        $out[] = ['title' => web_clean($m[2], 120), 'url' => $u, 'snippet' => web_clean($sn[1][$i] ?? '', 400)];
        if (count($out) >= $max) break;
    }
    return $out;
}
function web_search_wikipedia(string $q): array {
    $out = [];
    foreach (['id', 'en'] as $lang) {
        $r = json_decode(web_http_get('https://' . $lang . '.wikipedia.org/w/api.php?' . http_build_query(['action' => 'query', 'list' => 'search', 'srsearch' => $q, 'srlimit' => 3, 'format' => 'json', 'utf8' => 1]), 10), true);
        foreach (($r['query']['search'] ?? []) as $x) {
            $out[] = ['title' => web_clean((string)$x['title'], 120) . ' — Wikipedia', 'url' => 'https://' . $lang . '.wikipedia.org/wiki/' . rawurlencode(str_replace(' ', '_', (string)$x['title'])), 'snippet' => web_clean((string)($x['snippet'] ?? ''), 400)];
        }
        if (count($out) >= 3) break;
    }
    return array_slice($out, 0, 4);
}
/** Pencarian web berlapis: Tavily → Brave → SearXNG → DuckDuckGo HTML → DuckDuckGo instant → Wikipedia. Tak pernah melempar galat. */
function web_search(string $q): array {
    $q = trim(mb_substr($q, 0, 300)); if ($q === '') return [];
    $q = trim(preg_replace('/^(tolong\s+)?(cari(kan)?|search( for)?|telusuri|browse)\s+(di web\s+|informasi\s+(tentang\s+)?)?/iu', '', $q)) ?: $q;
    try {
        if (TAVILY_API_KEY !== '') {
            $ch = curl_init('https://api.tavily.com/search');
            curl_setopt_array($ch, [CURLOPT_POST => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 20,
                CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . TAVILY_API_KEY],
                CURLOPT_POSTFIELDS => json_encode(['query' => $q, 'max_results' => 5])]);
            $r = json_decode((string)curl_exec($ch), true); curl_close($ch);
            if (!empty($r['results'])) return array_map(fn($x) => ['title' => $x['title'] ?? '', 'url' => $x['url'] ?? '', 'snippet' => mb_substr($x['content'] ?? '', 0, 400)], $r['results']);
        }
        $brave = (string)wansq_cfg('BRAVE_API_KEY', '');
        if ($brave !== '') {
            $r = json_decode(web_http_get('https://api.search.brave.com/res/v1/web/search?' . http_build_query(['q' => $q, 'count' => 5]), 12, ['X-Subscription-Token: ' . $brave, 'Accept: application/json']), true);
            $o = [];
            foreach (($r['web']['results'] ?? []) as $x) $o[] = ['title' => web_clean((string)$x['title'], 120), 'url' => (string)$x['url'], 'snippet' => web_clean((string)($x['description'] ?? ''), 400)];
            if ($o) return array_slice($o, 0, 5);
        }
        $sx = rtrim((string)wansq_cfg('SEARXNG_URL', ''), '/');
        if ($sx !== '') {
            $r = json_decode(web_http_get($sx . '/search?' . http_build_query(['q' => $q, 'format' => 'json']), 12), true);
            $o = [];
            foreach (($r['results'] ?? []) as $x) $o[] = ['title' => web_clean((string)($x['title'] ?? ''), 120), 'url' => (string)($x['url'] ?? ''), 'snippet' => web_clean((string)($x['content'] ?? ''), 400)];
            if ($o) return array_slice($o, 0, 5);
        }
        $o = web_parse_ddg_html(web_http_get('https://html.duckduckgo.com/html/?' . http_build_query(['q' => $q]), 12), 5);
        if ($o) return $o;
        $r = json_decode(web_http_get('https://api.duckduckgo.com/?' . http_build_query(['q' => $q, 'format' => 'json', 'no_html' => 1]), 10), true);
        $o = [];
        if (!empty($r['AbstractText'])) $o[] = ['title' => $r['Heading'] ?? $q, 'url' => $r['AbstractURL'] ?? '', 'snippet' => mb_substr($r['AbstractText'], 0, 400)];
        foreach (array_slice($r['RelatedTopics'] ?? [], 0, 4) as $t) if (isset($t['Text'])) $o[] = ['title' => mb_substr($t['Text'], 0, 80), 'url' => $t['FirstURL'] ?? '', 'snippet' => mb_substr($t['Text'], 0, 400)];
        if ($o) return $o;
        return web_search_wikipedia($q);
    } catch (Throwable $e) { if (function_exists('app_log')) app_log('web_search failed: ' . mb_substr($e->getMessage(), 0, 160)); return []; }
}

function run_code_piston(string $lang, string $code): ?array {
    if (PISTON_API_URL === '') return null;
    $versions = ['python' => '3.11.1', 'javascript' => '18.15.0', 'php' => '8.2.3'];
    $ch = curl_init(rtrim(PISTON_API_URL, '/') . '/execute');
    curl_setopt_array($ch, [CURLOPT_POST => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 25,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['language' => $lang, 'version' => $versions[$lang] ?? '', 'files' => [['content' => $code]]])]);
    $r = json_decode((string)curl_exec($ch), true); curl_close($ch);
    return $r ? ['output' => $r['run']['output'] ?? '', 'stderr' => $r['run']['stderr'] ?? ''] : null;
}