<?php
/**
 * WanSQ v3.2.4 — OpenRouter Decisions API Integration
 * GPT Luna 6 for Intelligent Decision Making & Message Routing
 *
 * Supports:
 * - Message classification (urgency, sentiment, intent)
 * - User routing (which feature/department)
 * - Priority detection
 * - Context understanding
 */

declare(strict_types=1);

class OpenRouterDecisions {
    private $apiKey;
    private $baseUrl = 'https://openrouter.ai/api/v1';
    private $model = 'openai/gpt-6-luna-decisions';
    private $referer;
    private $title;

    public function __construct() {
        $this->apiKey = defined('OPENROUTER_API_KEY') ? OPENROUTER_API_KEY : '';
        $this->baseUrl = defined('OPENROUTER_BASE') ? OPENROUTER_BASE : $this->baseUrl;
        $this->referer = defined('OPENROUTER_REFERER') ? OPENROUTER_REFERER : '';
        $this->title = defined('OPENROUTER_TITLE') ? OPENROUTER_TITLE : 'WanSQ';

        if (!$this->apiKey) {
            throw new Exception('OPENROUTER_API_KEY not configured');
        }
    }

    /**
     * Create a decision request to Luna 6
     *
     * @param string $state The state/message to analyze
     * @param array<string, array> $questions Questions to answer
     * @return array Decision results
     */
    public function create(string $state, array $questions): array {
        $payload = [
            'decisionsRequest' => [
                'model' => $this->model,
                'state' => $state,
                'questions' => $questions
            ]
        ];

        $response = $this->apiCall('/alpha/decisions', $payload);

        if (isset($response['error'])) {
            throw new Exception('OpenRouter Decisions Error: ' . $response['error']['message']);
        }

        return $response['answers'] ?? [];
    }

    /**
     * Classify a message (urgency, sentiment, intent)
     */
    public function classifyMessage(string $message): array {
        return $this->create($message, [
            'urgency' => [
                'type' => 'noul', // probability 0-1
                'instructions' => 'Does this message convey urgency or time sensitivity?',
                'criteria' => [
                    'true' => 'Explicitly time-sensitive (ASAP, urgent, deadline)',
                    'false' => 'No urgency expressed'
                ]
            ],
            'sentiment' => [
                'type' => 'choice',
                'instructions' => 'What is the overall sentiment?',
                'criteria' => [
                    'positive' => 'Satisfied, happy, complimenting',
                    'neutral' => 'Matter-of-fact, informational',
                    'negative' => 'Frustrated, angry, complaining'
                ]
            ],
            'intent' => [
                'type' => 'choice',
                'instructions' => 'What is the primary intent?',
                'criteria' => [
                    'ask' => 'Asking a question, seeking help',
                    'report' => 'Reporting a bug or issue',
                    'request' => 'Requesting a feature or change',
                    'inform' => 'Providing information'
                ]
            ],
            'frustration_level' => [
                'type' => 'score',
                'instructions' => 'How frustrated is the sender?',
                'criteria' => ['Very Calm', 'Calm', 'Neutral', 'Frustrated', 'Very Angry']
            ]
        ]);
    }

    /**
     * Route user query to appropriate department/feature
     */
    public function routeQuery(string $userMessage, string $context = ''): array {
        $state = "User query: {$userMessage}";
        if ($context) {
            $state .= "\n\nContext: {$context}";
        }

        return $this->create($state, [
            'primary_feature' => [
                'type' => 'choice',
                'instructions' => 'Which WanSQ feature should handle this?',
                'criteria' => [
                    'chat' => 'General chat, conversation, discussion',
                    'vision' => 'Image analysis, diagram reading, OCR',
                    'search' => 'Web search, information lookup',
                    'code' => 'Code execution, programming help',
                    'memory' => 'Memory/knowledge management, recall',
                    'project' => 'Project management, organization',
                    'share' => 'Sharing, collaboration',
                    'export' => 'Export, download, format conversion'
                ]
            ],
            'complexity' => [
                'type' => 'score',
                'instructions' => 'How complex is this query?',
                'criteria' => ['Simple', 'Moderate', 'Complex', 'Very Complex']
            ],
            'requires_search' => [
                'type' => 'noul',
                'instructions' => 'Does this need web search for current info?',
                'criteria' => [
                    'true' => 'Needs recent data, current info, real-time',
                    'false' => 'Can be answered from general knowledge'
                ]
            ],
            'response_type' => [
                'type' => 'choice',
                'instructions' => 'What type of response is best?',
                'criteria' => [
                    'text' => 'Text-based explanation',
                    'code' => 'Code snippet or executable',
                    'visual' => 'Diagram, table, or visualization',
                    'mixed' => 'Multiple formats combined'
                ]
            ]
        ]);
    }

    /**
     * Analyze document/file for processing strategy
     */
    public function analyzeDocument(string $filename, string $preview): array {
        $state = "File: {$filename}\n\nPreview (first 500 chars):\n{$preview}";

        return $this->create($state, [
            'content_type' => [
                'type' => 'choice',
                'instructions' => 'What type of content is this?',
                'criteria' => [
                    'text' => 'Plain text, document, article',
                    'code' => 'Source code, script',
                    'data' => 'Data file, CSV, JSON, spreadsheet',
                    'image' => 'Image, diagram, screenshot',
                    'pdf' => 'PDF document',
                    'mixed' => 'Multiple types'
                ]
            ],
            'processing_priority' => [
                'type' => 'score',
                'instructions' => 'What processing priority?',
                'criteria' => ['Low', 'Normal', 'High', 'Critical']
            ],
            'requires_ocr' => [
                'type' => 'noul',
                'instructions' => 'Does this need OCR processing?',
                'criteria' => [
                    'true' => 'Image or scanned document',
                    'false' => 'Already in text format'
                ]
            ],
            'language' => [
                'type' => 'choice',
                'instructions' => 'Detected language?',
                'criteria' => [
                    'english' => 'English',
                    'indonesian' => 'Indonesian',
                    'chinese' => 'Chinese',
                    'mixed' => 'Multiple languages',
                    'other' => 'Other language'
                ]
            ]
        ]);
    }

    /**
     * Detect user intent for feature suggestion
     */
    public function detectIntent(string $userQuery): array {
        return $this->create($userQuery, [
            'primary_intent' => [
                'type' => 'choice',
                'instructions' => 'What does the user primarily want?',
                'criteria' => [
                    'get_info' => 'Get information or answer',
                    'create' => 'Create or generate content',
                    'analyze' => 'Analyze or evaluate something',
                    'help' => 'Get help with a problem',
                    'learn' => 'Learn or understand concept',
                    'explore' => 'Explore or brainstorm ideas'
                ]
            ],
            'is_followup' => [
                'type' => 'noul',
                'instructions' => 'Is this a follow-up to previous conversation?',
                'criteria' => [
                    'true' => 'References previous context, pronouns like "it", "that"',
                    'false' => 'Standalone, self-contained query'
                ]
            ],
            'urgency' => [
                'type' => 'score',
                'instructions' => 'How urgent is this?',
                'criteria' => ['Not Urgent', 'Casual', 'Somewhat Urgent', 'Urgent', 'Critical']
            ]
        ]);
    }

    /**
     * Make HTTP request to OpenRouter API
     */
    private function apiCall(string $endpoint, array $payload): array {
        $url = rtrim($this->baseUrl, '/') . $endpoint;

        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'HTTP-Referer: ' . $this->referer,
            'X-Title: ' . $this->title,
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new Exception("cURL Error: $error");
        }

        $data = json_decode($response, true);

        if ($httpCode !== 200 && $httpCode !== 201) {
            throw new Exception("API Error ($httpCode): " . ($data['error']['message'] ?? 'Unknown error'));
        }

        return $data;
    }

    /**
     * Check if Decisions API is available
     */
    public static function isAvailable(): bool {
        try {
            return defined('OPENROUTER_API_KEY') && !empty(OPENROUTER_API_KEY);
        } catch (Exception $e) {
            return false;
        }
    }
}

// Helper function for easy access
if (!function_exists('decisions')) {
    function decisions(): OpenRouterDecisions {
        static $instance = null;
        if ($instance === null) {
            $instance = new OpenRouterDecisions();
        }
        return $instance;
    }
}
