<?php
declare(strict_types=1);
/**
 * WanSQ · Transport ke provider (OpenAI-compatible: Groq).
 * v3: base URL dapat di-override (dev/test), finish_reason, filter <think>, timeout anti-hang.
 */
if (!defined('GROQ_CONNECT_TIMEOUT')) define('GROQ_CONNECT_TIMEOUT', 10);
if (!defined('GROQ_STREAM_TIMEOUT')) define('GROQ_STREAM_TIMEOUT', 900);      // 15 minutes total
if (!defined('GROQ_LOWSPEED_TIME')) define('GROQ_LOWSPEED_TIME', 180);        // 3 minutes minimum data reception
if (!defined('GROQ_LOWSPEED_LIMIT')) define('GROQ_LOWSPEED_LIMIT', 1024);     // 1KB minimum per interval

if (!function_exists('groq_is_openrouter')) {
function groq_is_openrouter(): bool { return defined('OPENROUTER_API_KEY') && OPENROUTER_API_KEY !== ''; }
}
if (!function_exists('groq_base')) {
function groq_base(): string {
    $o = getenv('WANSQ_LLM_BASE');
    if ($o) return rtrim($o, '/');
    if (groq_is_openrouter()) return rtrim(OPENROUTER_BASE, '/');
    return rtrim(GROQ_BASE, '/');
}
}
if (!function_exists('groq_api_key')) {
function groq_api_key(): string { return groq_is_openrouter() ? (string)OPENROUTER_API_KEY : (string)GROQ_API_KEY; }
}
if (!function_exists('groq_headers')) {
function groq_headers(bool $stream): array {
    $h = array('Authorization: Bearer ' . groq_api_key(), 'Content-Type: application/json');
    if (groq_is_openrouter()) {
        $ref = defined('OPENROUTER_REFERER') ? (string)OPENROUTER_REFERER : '';
        $title = defined('OPENROUTER_TITLE') ? (string)OPENROUTER_TITLE : 'WanSQ';
        if ($ref !== '') $h[] = 'HTTP-Referer: ' . $ref;
        if ($title !== '') $h[] = 'X-Title: ' . $title;
    }
    if ($stream) $h[] = 'Accept: text/event-stream';
    return $h;
}
}

/** Klasifikasi galat provider → kind (dipakai kebijakan retry/fallback). */
if (!function_exists('groq_afford_from_msg')) {
/** Angka max_tokens yang masih terjangkau menurut pesan 402 provider; null bila tidak ada. */
function groq_afford_from_msg(string $msg): ?int {
    if (preg_match('~can only afford\s+(\d+)~i', $msg, $m)) return (int)$m[1];
    return null;
}
}
if (!function_exists('groq_err_kind')) {
function groq_err_kind(int $http, string $msg, string $curlErr = ''): string {
    $m = strtolower($msg);
    if ($http === 401 || $http === 403 || strpos($m, 'invalid api key') !== false) return 'auth';
    // 402 = saldo/kredit provider tidak menutupi max_tokens (OpenRouter). Kind 'budget' agar batas output bisa diturunkan.
    if ($http === 402 || strpos($m, 'requires more credits') !== false || strpos($m, 'can only afford') !== false) return 'budget';
    if ($http === 404 || strpos($m, 'does not exist') !== false || strpos($m, 'decommissioned') !== false
        || strpos($m, 'model_not_found') !== false || strpos($m, 'not found') !== false) return 'notfound';
    // Kuota/rate (TPM/RPM/ITPM/token-per-day) HARUS diperiksa SEBELUM 'toolarge': pesan kuota Groq
    // sering menyebut kata "limit"/"tokens per minute" tanpa kata "too large", tapi bisa muncul
    // bersamaan dengan angka besar yang keliru terklasifikasi sebagai context-length bila urutan dibalik.
    if ($http === 429 || strpos($m, 'rate limit') !== false || strpos($m, 'tokens per minute') !== false
        || strpos($m, 'tokens per day') !== false || strpos($m, 'requests per minute') !== false
        || preg_match('~\b(tpm|rpm|itpm)\b~', $m)) return 'rate';
    // 413 murni "request body terlalu besar" (mis. base64 gambar berukuran raksasa) — beda akar
    // masalah dari 400 "reduce the length of the messages" (context window logis terlampaui).
    if ($http === 413 || strpos($m, 'payload too large') !== false || strpos($m, 'request entity too large') !== false) return 'request_too_large';
    if (strpos($m, 'maximum context length') !== false || strpos($m, 'context length') !== false
        || strpos($m, 'reduce the length') !== false || strpos($m, 'context_length_exceeded') !== false) return 'toolarge';
    if ($http >= 500) return 'server';
    if ($http === 400 || $http === 422) return 'badrequest';
    if ($curlErr !== '') return (stripos($curlErr, 'timed out') !== false || stripos($curlErr, 'timeout') !== false) ? 'timeout' : 'network';
    return 'unknown';
}
}

if (!function_exists('groq_call')) {
/** Panggilan non-stream. Mengembalikan array respons (atau ['error'=>..., '_http'=>...]). */
function groq_call(array $payload, int $timeout = 15): array {
    $ch = curl_init(groq_base() . '/chat/completions');
    curl_setopt_array($ch, array(
        CURLOPT_POST => 1, CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => GROQ_CONNECT_TIMEOUT,
        CURLOPT_HTTPHEADER => groq_headers(false),
        CURLOPT_POSTFIELDS => json_encode($payload + array('stream' => false), JSON_UNESCAPED_UNICODE),
    ));
    $raw = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);
    $res = json_decode((string)$raw, true);
    if (!is_array($res)) $res = array('error' => array('message' => $cerr !== '' ? $cerr : 'Respons provider kosong/tidak valid'));
    $res['_http'] = $http; $res['_curl'] = $cerr;
    return $res;
}
}

if (!function_exists('groq_get')) {
function groq_get(string $path, int $timeout = 8): array {
    $ch = curl_init(groq_base() . $path);
    curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => GROQ_CONNECT_TIMEOUT, CURLOPT_HTTPHEADER => groq_headers(false)));
    $raw = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
    $j = json_decode((string)$raw, true);
    return is_array($j) ? $j + array('_http' => $http) : array('_http' => $http);
}
}

/** Path fisik lampiran. 'uploads/…' (legacy/avatar) atau 'att/…' (privat, di storage). */
if (!function_exists('stored_to_fs')) {
function stored_to_fs(string $stored): string {
    $stored = str_replace('\\', '/', $stored);
    $stored = str_replace('..', '', $stored);
    if (strpos($stored, 'att/') === 0 || strpos($stored, 'docs/') === 0) return STORAGE_DIR . '/' . $stored;
    if (strpos($stored, 'uploads/') === 0) $stored = substr($stored, strlen('uploads/'));
    return UPLOAD_DIR . '/' . $stored;
}
}

if (!function_exists('data_url')) {
function data_url(string $path): string {
    if (!is_file($path)) throw new RuntimeException('File gambar tidak ditemukan di storage: ' . basename($path));
    $data = file_get_contents($path);
    if ($data === false) throw new RuntimeException('File gambar tidak dapat dibaca: ' . basename($path));
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($path) ?: 'image/jpeg';
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}
}

/** Menyaring blok <think>…</think> (model reasoning tertentu) dari aliran teks, aman terhadap tag terpotong. */
if (!class_exists('WanThinkFilter')) {
class WanThinkFilter {
    private $in = false; private $buf = '';
    private function tail(string $s, string $tag): int {
        $max = min(strlen($s), strlen($tag) - 1);
        for ($k = $max; $k > 0; $k--) if (substr($s, -$k) === substr($tag, 0, $k)) return $k;
        return 0;
    }
    public function feed(string $d): string {
        $this->buf .= $d; $out = '';
        while (true) {
            if (!$this->in) {
                $p = strpos($this->buf, '<think>');
                if ($p === false) {
                    $k = $this->tail($this->buf, '<think>');
                    $out .= substr($this->buf, 0, strlen($this->buf) - $k);
                    $this->buf = $k ? substr($this->buf, -$k) : '';
                    break;
                }
                $out .= substr($this->buf, 0, $p); $this->buf = substr($this->buf, $p + 7); $this->in = true;
            } else {
                $p = strpos($this->buf, '</think>');
                if ($p === false) { $k = $this->tail($this->buf, '</think>'); $this->buf = $k ? substr($this->buf, -$k) : ''; break; }
                $this->buf = ltrim(substr($this->buf, $p + 8), "\n"); $this->in = false;
            }
        }
        return $out;
    }
    public function flush(): string { $r = $this->in ? '' : $this->buf; $this->buf = ''; return $r; }
}
}

if (!function_exists('groq_stream')) {
/**
 * Stream SSE. Hasil ke $res: err, kind, http, usage, finish, first_token_ms, connect_ms, chars.
 * $onDelta dipanggil untuk tiap potongan teks yang terlihat pengguna.
 */
function groq_stream(array $payload, callable $onDelta, array &$res): void {
    $res = array('err' => null, 'kind' => null, 'http' => null, 'usage' => null, 'finish' => null,
                 'first_token_ms' => null, 'connect_ms' => null, 'chars' => 0);
    $buf = ''; $raw = ''; $t0 = microtime(true); $flt = new WanThinkFilter(); $lastBeat = $t0;
    $emit = function (string $txt) use (&$res, $onDelta, $t0) {
        if ($txt === '') return;
        if ($res['first_token_ms'] === null) $res['first_token_ms'] = ms_since($t0);
        $res['chars'] += strlen($txt);
        $onDelta($txt);
    };
    $ch = curl_init(groq_base() . '/chat/completions');
    curl_setopt_array($ch, array(
        CURLOPT_POST => 1, CURLOPT_TIMEOUT => GROQ_STREAM_TIMEOUT,   // 15 menit untuk entire stream
        CURLOPT_CONNECTTIMEOUT => GROQ_CONNECT_TIMEOUT,              // 10 detik untuk initial connection
        CURLOPT_TCP_NODELAY => true,                                 // nagirim setiap chunk segera, tidak buffer
        CURLOPT_LOW_SPEED_LIMIT => GROQ_LOWSPEED_LIMIT,              // 1KB/window adalah minimum
        CURLOPT_LOW_SPEED_TIME => GROQ_LOWSPEED_TIME,                // 180 detik window — jika < 1KB dalam 3 menit, timeout
        CURLOPT_HTTPHEADER => groq_headers(true),
        CURLOPT_POSTFIELDS => json_encode($payload + array('stream' => true, 'stream_options' => array('include_usage' => true)), JSON_UNESCAPED_UNICODE),
        CURLOPT_NOPROGRESS => false,
        CURLOPT_XFERINFOFUNCTION => function ($ch, int $dlNow, int $dlTotal, int $ulNow, int $ulTotal) use (&$lastBeat, $emit) {
            $now = microtime(true);
            // SSE comments keep reverse proxies/browser fetches alive while the provider
            // is thinking, without changing the application event stream. Interval disesuaikan
            // dengan GROQ_LOWSPEED_TIME untuk mencegah false timeout dari proxy.
            if (($now - $lastBeat) >= 12.0) {  // 12 detik < 180s window, aman dari low-speed timeout
                echo ": keep-alive\n\n";
                if (ob_get_level() > 0) @ob_flush();
                @flush();
                $lastBeat = $now;
            }
            return connection_aborted() ? 1 : 0;
        },
        CURLOPT_WRITEFUNCTION => function ($ch, string $data) use (&$buf, &$raw, &$res, $emit, $flt) {
            if (strlen($raw) < 65536) $raw .= $data;
            $buf .= $data;
            while (($pos = strpos($buf, "\n")) !== false) {
                $line = trim(substr($buf, 0, $pos)); $buf = substr($buf, $pos + 1);
                if (strpos($line, 'data:') !== 0) continue;
                $s = trim(substr($line, 5));
                if ($s === '[DONE]') continue;
                $j = json_decode($s, true);
                if (!is_array($j)) continue;
                if (isset($j['error'])) { $res['err'] = is_array($j['error']) ? ($j['error']['message'] ?? 'Error provider') : (string)$j['error']; continue; }
                if (isset($j['usage']) && is_array($j['usage'])) $res['usage'] = $j['usage'];
                elseif (isset($j['x_groq']['usage'])) $res['usage'] = $j['x_groq']['usage'];
                $c0 = $j['choices'][0] ?? array();
                if (!empty($c0['finish_reason'])) $res['finish'] = (string)$c0['finish_reason'];
                $d = $c0['delta']['content'] ?? null;
                if (is_string($d) && $d !== '') $emit($flt->feed($d));
            }
            return connection_aborted() ? -1 : strlen($data);
        },
    ));
    curl_exec($ch);
    $res['http'] = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $res['connect_ms'] = (int)(curl_getinfo($ch, CURLINFO_CONNECT_TIME) * 1000);
    $cerr = curl_error($ch); curl_close($ch);
    $tail = $flt->flush(); if ($tail !== '') $emit($tail);
    if ($res['err'] === null && $res['first_token_ms'] === null) {
        $j = json_decode($raw, true);
        if (is_array($j) && isset($j['error']))  $res['err'] = is_array($j['error']) ? ($j['error']['message'] ?? 'Error provider') : (string)$j['error'];
        elseif ($cerr !== '')                    $res['err'] = $cerr;
        elseif ($res['http'] >= 400)             $res['err'] = 'Provider HTTP ' . $res['http'];
        else                                     $res['err'] = ($res['finish'] === 'length') ? 'Batas token tercapai sebelum jawaban muncul' : 'Model tidak mengembalikan output';
    } elseif ($res['err'] === null && $cerr !== '' && !connection_aborted()) {
        $res['err'] = $cerr;    // koneksi putus di tengah jalan
    }
    if ($res['err'] !== null) $res['kind'] = groq_err_kind((int)$res['http'], (string)$res['err'], $cerr);
    $res['afford'] = $res['err'] !== null ? groq_afford_from_msg((string)$res['err']) : null;
}
}
