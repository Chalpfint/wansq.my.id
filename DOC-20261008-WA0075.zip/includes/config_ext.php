<?php
declare(strict_types=1);
/**
 * WanSQ v3 · Konfigurasi tambahan (dimuat otomatis oleh helpers.php).
 * Semua nilai di sini punya default aman; override lewat includes/config.local.php
 * (opsional, buat sendiri — lihat config.local.example.php) atau lewat config.php.
 */

$__d = [
    'WANSQ_VERSION'      => '3.2.4',
    // Asset cache-buster: increment when frontend JS/CSS changes without changing the DB/app contract.
    'WANSQ_ASSET_VERSION' => '2026.10.03-324b',
    // --- Dokumen / RAG / OCR ---
    'DOC_MAX_BYTES'      => 20 * 1024 * 1024,
    'ORIGINAL_UPLOAD_LIMIT' => 20 * 1024 * 1024,
    'INFERENCE_IMAGE_LIMIT' => 10 * 1024 * 1024,
    'PROVIDER_IMAGE_LIMIT' => 20 * 1024 * 1024,   // batas ukuran PDF/DOCX (PHP upload_max_filesize server ikut membatasi)
    'DOC_MAX_PAGES'      => 400,                // batas halaman diindeks
    'DOC_CONTEXT_CHARS'  => 30000,              // maksimum karakter potongan dokumen yang dikirim ke model per pesan
    'OCR_MAX_PAGES'      => 40,                 // batas halaman yang di-OCR per dokumen
    'OCR_RATE_PER_MIN'   => 40,
    'MAX_ATTACH'         => 5,                  // lampiran per pesan
    'MAX_IMAGES'         => 3,                  // batas gambar per request vision (batas provider)
    // --- Konteks ---
    'CTX_BUDGET_CHARS'   => 300000,             // anggaran total konteks (karakter)
    'ROLLING_SUMMARY'    => true,               // ringkasan berjalan untuk pesan lama
    'SUMMARY_TRIGGER'    => 24,                 // mulai meringkas bila pesan aktif >= nilai ini
    'SUMMARY_KEEP_RECENT'=> 12,                 // pesan terbaru yang tidak diringkas
    'CTX_RECENT_MIN'     => 6,                  // minimal pesan terbaru yang selalu dibawa
    // --- Image generation / editing (kosong = nonaktif; UI otomatis menyembunyikan) ---
    'IMAGE_PROVIDER'     => '',                 // '' (auto: 'openrouter' bila OPENROUTER_API_KEY ada) | 'openrouter' | 'gemini' | 'openai' | 'pollinations' | 'off'
    'IMAGE_API_KEY'      => '',
    'IMAGE_MODEL'        => '',                 // openrouter: google/gemini-2.5-flash-image · gemini: gemini-2.5-flash-image · openai: gpt-image-1 / dall-e-3
    'IMAGE_BASE'         => '',                 // openai-compatible: mis. https://api.openai.com/v1
    // --- Trash ---
    'TRASH_DAYS'         => 30,
    // --- Fitur ---
    'FOLLOWUPS_ENABLED'  => true,
    'SHARE_ENABLED'      => true,
    // Automatically apply only additive v3.1 multimodal schema changes.
    'AUTO_SCHEMA_MIGRATE'=> false,
    'RESUMABLE_UPLOAD_ENABLED' => false,
    'UPLOAD_CHUNK_BYTES' => 2 * 1024 * 1024,
    'UPLOAD_SESSION_TTL' => 6 * 3600,
    'RESUMABLE_MIN_BYTES' => 8 * 1024 * 1024,
    'JOB_RETENTION_DAYS' => 14,
    'ARTIFACT_MAX_BYTES' => 2 * 1024 * 1024,
    'ARTIFACT_VERSION_LIMIT' => 50,
    'PROVENANCE_ENABLED' => true,
    // --- v3.2.4 hemat kredit ---
    'PRESSURE_INPUT_TOKENS' => 6000,   // batas input (token) saat kredit provider menipis
    'WANSQ_LUNA_ROUTER'  => false,     // panggilan Luna (decisions) per request: nonaktif, pakai heuristik lokal
];
foreach ($__d as $__k => $__v) if (!defined($__k)) define($__k, $__v);
unset($__d, $__k, $__v);
