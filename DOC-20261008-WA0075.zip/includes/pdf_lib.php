<?php
declare(strict_types=1);
/** Ekstraksi teks best-effort tanpa dependensi eksternal. */

function pdf_extract_text(string $path, int $maxChars = 20000): string {
    $data = @file_get_contents($path);
    if ($data === false) return '';
    $out = '';
    if (preg_match_all('/stream\r?\n(.*?)endstream/s', $data, $m)) {
        foreach ($m[1] as $s) {
            $dec = @gzinflate($s);
            if ($dec === false) $dec = @gzuncompress($s);
            if ($dec === false) continue;
            if (preg_match_all('/\((?:\\\\.|[^\\\\()])*\)\s*Tj|\[(?:\\\\.|[^\\\\\[\]])*\]\s*TJ/s', $dec, $tm)) {
                foreach ($tm[0] as $op) {
                    if (preg_match_all('/\((?:\\\\.|[^\\\\()])*\)/s', $op, $sm)) {
                        foreach ($sm[0] as $seg) {
                            $t = substr($seg, 1, -1);
                            $t = str_replace(['\\(', '\\)', '\\\\', '\\n', '\\r', '\\t'], ['(', ')', '\\', "\n", "\r", "\t"], $t);
                            $out .= $t;
                        }
                        $out .= ' ';
                    }
                }
                $out .= "\n";
            }
            if (strlen($out) > $maxChars) break;
        }
    }
    $out = preg_replace('/[ \t]+\n/', "\n", $out);
    $out = preg_replace('/\n{3,}/', "\n\n", $out);
    return mb_substr(trim($out), 0, $maxChars);
}

function docx_extract_text(string $path, int $maxChars = 20000): string {
    if (!class_exists('ZipArchive')) return '';
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) return '';
    $xml = $zip->getFromName('word/document.xml');
    $zip->close();
    if ($xml === false) return '';
    $xml = preg_replace('/<\/w:p>/', "\n", $xml);
    $txt = strip_tags($xml);
    $txt = html_entity_decode($txt, ENT_QUOTES | ENT_XML1, 'UTF-8');
    return mb_substr(trim(preg_replace('/\n{3,}/', "\n\n", $txt)), 0, $maxChars);
}