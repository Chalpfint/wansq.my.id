/*
  WanSQ.AI 3.2.4 (SQL 4.1.4) — clean MariaDB schema
  Target: MariaDB 10.4+
  Purpose: fresh installation / reference schema.
  Existing production databases should use wansq_upgrade_v4.1.4.sql instead.
  No production records or credentials are included.
*/
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `google_sub` varchar(64) NULL,
  `email` varchar(190) NOT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `full_name` varchar(120) NOT NULL DEFAULT '',
  `username` varchar(40) NULL,
  `password_hash` varchar(255) NULL,
  `avatar_google` varchar(500) NOT NULL DEFAULT '',
  `avatar_local` varchar(255) NOT NULL DEFAULT '',
  `theme` enum('light','dark','system') NOT NULL DEFAULT 'system',
  `ui_lang` varchar(5) NOT NULL DEFAULT 'id',
  `reply_lang` varchar(8) NOT NULL DEFAULT 'auto',
  `custom_instructions` text NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_google_sub` (`google_sub`),
  UNIQUE KEY `uq_users_username` (`username`),
  KEY `idx_users_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `icon` varchar(16) NOT NULL DEFAULT '📁',
  `instructions` text NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`), KEY `idx_proj_user` (`user_id`), FULLTEXT KEY `ft_proj_name` (`name`),
  CONSTRAINT `fk_proj_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `project_memories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `content` text NOT NULL,
  `keywords` varchar(500) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `idx_pm_proj` (`project_id`), KEY `idx_pm_user` (`user_id`),
  CONSTRAINT `fk_pm_proj` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `conversations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `title` varchar(120) NOT NULL DEFAULT 'Percakapan Baru',
  `model` varchar(120) NULL,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `pinned` tinyint(1) NOT NULL DEFAULT 0,
  `engine` varchar(40) NULL,
  `project_id` int unsigned NULL,
  `deleted_at` datetime NULL,
  `topic` varchar(120) NULL,
  `intent` varchar(40) NULL,
  `tools_used` varchar(120) NULL,
  `summary` mediumtext NULL,
  `summary_upto_id` bigint unsigned NOT NULL DEFAULT 0,
  `summary_updated_at` datetime NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_conv_user` (`user_id`,`updated_at`),
  KEY `idx_conv_pin` (`user_id`,`pinned`,`updated_at`),
  KEY `idx_conv_project` (`user_id`,`project_id`,`deleted_at`),
  FULLTEXT KEY `ft_conv_title` (`title`),
  CONSTRAINT `fk_conv_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_conv_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` int unsigned NOT NULL,
  `role` enum('user','assistant','system') NOT NULL,
  `content` mediumtext NOT NULL,
  `meta` longtext NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `pinned` tinyint(1) NOT NULL DEFAULT 0,
  `pinned_at` datetime NULL,
  `pin_label` varchar(120) NULL,
  `cid` varchar(40) NULL,
  `superseded_at` datetime NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_msg_conv` (`conversation_id`,`id`),
  KEY `idx_msg_active` (`conversation_id`,`active`,`id`),
  KEY `idx_msg_pin` (`conversation_id`,`pinned`),
  UNIQUE KEY `uq_msg_cid` (`conversation_id`,`cid`),
  FULLTEXT KEY `ft_msg_content` (`content`),
  CONSTRAINT `fk_msg_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `message_id` bigint unsigned NULL,
  `conversation_id` int unsigned NULL,
  `project_id` int unsigned NULL,
  `kind` enum('image','doc') NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `stored_path` varchar(255) NOT NULL,
  `mime` varchar(100) NOT NULL,
  `original_mime` varchar(120) NULL,
  `size` int unsigned NOT NULL DEFAULT 0,
  `original_size` bigint unsigned NULL,
  `processed_size` bigint unsigned NULL,
  `original_width` int unsigned NULL,
  `original_height` int unsigned NULL,
  `processed_width` int unsigned NULL,
  `processed_height` int unsigned NULL,
  `width` int unsigned NULL,
  `height` int unsigned NULL,
  `extracted_text` mediumtext NULL,
  `status` enum('processing','ready','needs_ocr','failed') NOT NULL DEFAULT 'ready',
  `pages` smallint unsigned NOT NULL DEFAULT 0,
  `ocr_pages` smallint unsigned NOT NULL DEFAULT 0,
  `vision_summary` mediumtext NULL,
  `generated` tinyint(1) NOT NULL DEFAULT 0,
  `removed` tinyint(1) NOT NULL DEFAULT 0,
  `sha256` char(64) NULL,
  `processing_stage` varchar(24) NOT NULL DEFAULT 'ready',
  `processing_error` varchar(500) NULL,
  `generated_from_id` int unsigned NULL,
  `derivative_path` varchar(255) NULL,
  `derivative_reason` varchar(40) NULL,
  `provider_file_id` varchar(120) NULL,
  `vision_status` varchar(20) NOT NULL DEFAULT 'not_run',
  `ocr_status` varchar(20) NOT NULL DEFAULT 'not_run',
  `extracted_chars` int unsigned NOT NULL DEFAULT 0,
  `last_processed_at` datetime NULL,
  `preview_path` varchar(255) NULL,
  `preview_mime` varchar(100) NULL,
  `preview_size` bigint unsigned NULL,
  `preview_width` int unsigned NULL,
  `preview_height` int unsigned NULL,
  `preview_mode` varchar(20) NOT NULL DEFAULT 'none',
  `preview_generated_at` datetime NULL,
  `preview_error` varchar(500) NULL,
  `ai_status` varchar(20) NOT NULL DEFAULT 'pending',
  `ai_ready_at` datetime NULL,
  `processing_started_at` datetime NULL,
  `processing_finished_at` datetime NULL,
  `processing_attempts` smallint unsigned NOT NULL DEFAULT 0,
  `processor` varchar(30) NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_att_msg` (`message_id`),
  KEY `idx_att_user` (`user_id`),
  KEY `idx_att_conv` (`conversation_id`,`removed`),
  KEY `idx_att_proj` (`project_id`,`removed`),
  KEY `idx_att_hash` (`user_id`,`sha256`),
  KEY `idx_att_stage` (`user_id`,`processing_stage`,`removed`),
  KEY `idx_att_processing` (`user_id`,`status`,`processing_stage`,`removed`),
  KEY `idx_att_lifecycle` (`user_id`,`processing_stage`,`ai_status`,`removed`,`id`),
  KEY `idx_att_preview` (`user_id`,`preview_mode`,`removed`,`id`),
  CONSTRAINT `fk_att_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_att_msg` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_att_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_att_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_att_generated_from` FOREIGN KEY (`generated_from_id`) REFERENCES `attachments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `doc_chunks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `page_start` smallint unsigned NOT NULL DEFAULT 1,
  `page_end` smallint unsigned NOT NULL DEFAULT 1,
  `idx` int unsigned NOT NULL DEFAULT 0,
  `source` enum('text','ocr') NOT NULL DEFAULT 'text',
  `content` text NOT NULL,
  PRIMARY KEY (`id`), KEY `idx_chunk_att` (`attachment_id`,`page_start`,`idx`), KEY `idx_chunk_user` (`user_id`),
  FULLTEXT KEY `ft_chunk` (`content`),
  CONSTRAINT `fk_chunk_att` FOREIGN KEY (`attachment_id`) REFERENCES `attachments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_chunk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `message_id` bigint unsigned NULL,
  `rating` tinyint NOT NULL,
  `comment` varchar(500) NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `idx_fb_user` (`user_id`), KEY `idx_fb_msg` (`message_id`),
  CONSTRAINT `fk_fb_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fb_msg` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `memories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `content` text NOT NULL,
  `keywords` varchar(500) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `idx_mem_user` (`user_id`),
  CONSTRAINT `fk_mem_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `rate_limits` (
  `user_id` int unsigned NOT NULL,
  `window_start` int unsigned NOT NULL,
  `hits` smallint unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_rate_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `rate_buckets` (
  `user_id` int unsigned NOT NULL,
  `bucket` varchar(16) NOT NULL,
  `window_start` int unsigned NOT NULL,
  `hits` smallint unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`bucket`),
  CONSTRAINT `fk_rate_bucket_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `shares` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `token` char(40) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `max_message_id` bigint unsigned NOT NULL DEFAULT 0,
  `views` int unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `revoked_at` datetime NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_share_conv` (`conversation_id`), UNIQUE KEY `uq_share_token` (`token`),
  CONSTRAINT `fk_share_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_share_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `schema_meta` (
  `k` varchar(64) NOT NULL,
  `v` varchar(255) NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `schema_meta` (`k`,`v`) VALUES ('schema','4.1.4') ON DUPLICATE KEY UPDATE `v`='4.1.4';
INSERT INTO `schema_meta` (`k`,`v`) VALUES ('attachment_model','4.1.4') ON DUPLICATE KEY UPDATE `v`='4.1.4';


CREATE TABLE IF NOT EXISTS `conversation_branches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `parent_message_id` bigint unsigned NULL,
  `label` varchar(160) NOT NULL DEFAULT 'Branch',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_branch_conv` (`conversation_id`,`created_at`),
  KEY `idx_branch_user` (`user_id`),
  CONSTRAINT `fk_branch_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_branch_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_branch_parent` FOREIGN KEY (`parent_message_id`) REFERENCES `messages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `artifacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `project_id` int unsigned NULL,
  `conversation_id` int unsigned NULL,
  `type` varchar(32) NOT NULL,
  `title` varchar(160) NOT NULL,
  `content` longtext NOT NULL,
  `version` int unsigned NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_art_user` (`user_id`,`updated_at`),
  KEY `idx_art_project` (`project_id`,`updated_at`),
  KEY `idx_art_conv` (`conversation_id`,`updated_at`),
  FULLTEXT KEY `ft_art_title` (`title`),
  CONSTRAINT `fk_art_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_art_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_art_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `artifact_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `artifact_id` bigint unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `version_no` int unsigned NOT NULL,
  `title` varchar(160) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_art_ver` (`artifact_id`,`version_no`),
  KEY `idx_art_ver_user` (`user_id`,`artifact_id`,`version_no`),
  CONSTRAINT `fk_art_ver_art` FOREIGN KEY (`artifact_id`) REFERENCES `artifacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_art_ver_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `project_id` int unsigned NULL,
  `conversation_id` int unsigned NULL,
  `kind` varchar(40) NOT NULL,
  `status` enum('queued','running','completed','failed','cancelled') NOT NULL DEFAULT 'queued',
  `progress` tinyint unsigned NOT NULL DEFAULT 0,
  `title` varchar(160) NOT NULL,
  `payload` longtext NULL,
  `error` varchar(500) NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `started_at` datetime NULL,
  `finished_at` datetime NULL,
  `heartbeat_at` datetime NULL,
  `result_ref` varchar(120) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_job_user` (`user_id`,`updated_at`),
  KEY `idx_job_active` (`user_id`,`status`,`updated_at`),
  KEY `idx_job_project` (`project_id`,`updated_at`),
  CONSTRAINT `fk_job_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_job_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_job_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `memory_meta` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `memory_type` enum('global','project') NOT NULL,
  `memory_id` int unsigned NOT NULL,
  `source` varchar(32) NOT NULL DEFAULT 'user',
  `confidence` decimal(5,4) NULL,
  `relevance` decimal(5,4) NULL,
  `provenance` varchar(500) NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_memory_meta` (`memory_type`,`memory_id`),
  KEY `idx_memory_meta_user` (`user_id`,`memory_type`,`updated_at`),
  CONSTRAINT `fk_memory_meta_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provenance` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `conversation_id` int unsigned NULL,
  `message_id` bigint unsigned NULL,
  `source_type` varchar(24) NOT NULL,
  `source_id` varchar(120) NOT NULL,
  `title` varchar(255) NOT NULL,
  `locator` varchar(160) NULL,
  `uri` varchar(1000) NULL,
  `meta` longtext NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_prov_msg` (`user_id`,`message_id`,`id`),
  KEY `idx_prov_conv` (`user_id`,`conversation_id`,`id`),
  CONSTRAINT `fk_prov_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prov_conv` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_prov_msg` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `schema_meta` (`k`,`v`) VALUES ('schema','4.1.4') ON DUPLICATE KEY UPDATE `v`='4.1.4';
INSERT INTO `schema_meta` (`k`,`v`) VALUES ('attachment_model','4.1.4') ON DUPLICATE KEY UPDATE `v`='4.1.4';
INSERT INTO `schema_meta` (`k`,`v`) VALUES ('workspace_model','3.2.4') ON DUPLICATE KEY UPDATE `v`='3.2.4';

SET FOREIGN_KEY_CHECKS=1;
