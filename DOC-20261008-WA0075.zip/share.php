<?php
declare(strict_types=1);
/**
 * WanSQ · Halaman publik read-only untuk percakapan yang dibagikan.
 * Tanpa login. Hanya menampilkan snapshot percakapan yang dibagikan — tidak ada profil,
 * email, memory, instruksi sistem, path storage, atau data privat lain yang terekspos.
 */
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/helpers.php';
require __DIR__ . '/includes/i18n.php';
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

$token = (string)($_GET['t'] ?? '');
$LANG = in_array((string)($_GET['lang'] ?? ''), array('id', 'en'), true) ? (string)$_GET['lang'] : 'id';
$GLOBALS['WAN_LANG'] = $LANG;
$pdo = db();
$st = $pdo->prepare('SELECT s.*, c.title FROM shares s JOIN conversations c ON c.id = s.conversation_id WHERE s.token = ? AND s.enabled = 1 AND c.deleted_at IS NULL');
$st->execute([$token]);
$share = $st->fetch();

function render_gone(string $why): void {
    ?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WanSQ · Share</title><link rel="stylesheet" href="<?= e(base_url('/assets/css/style.css')) ?>"><script src="<?= e(base_url('/assets/js/themeboot.js')) ?>"></script></head>
    <body class="app-body"><div class="share-gone"><h2>🔗 <?= e($why) ?></h2><p>Tautan ini tidak (lagi) aktif. Hubungi pemilik percakapan untuk tautan baru.</p></div></body></html><?php
    exit;
}
if (!$share) render_gone('Tautan tidak ditemukan');

/* Gambar dalam percakapan yang dibagikan: hanya bila lampiran itu benar milik pesan dalam snapshot ini. */
if (isset($_GET['img'])) {
    $aid = (int)$_GET['img'];
    $st2 = $pdo->prepare("SELECT a.* FROM attachments a JOIN messages m ON m.id=a.message_id
        WHERE a.id=? AND a.kind='image' AND a.removed=0 AND m.conversation_id=? AND m.id<=? AND m.active=1");
    $st2->execute([$aid, $share['conversation_id'], $share['max_message_id']]);
    $a = $st2->fetch();
    if (!$a) { http_response_code(404); exit; }
    $fs = stored_to_fs_public((string)$a['stored_path']);
    if (!is_file($fs)) { http_response_code(404); exit; }
    header('Content-Type: ' . ((new finfo(FILEINFO_MIME_TYPE))->file($fs) ?: 'image/jpeg'));
    header('Cache-Control: public, max-age=86400');
    header('Content-Length: ' . filesize($fs));
    readfile($fs); exit;
}
function stored_to_fs_public(string $stored): string {
    $stored = str_replace(array('\\', '..'), array('/', ''), $stored);
    if (strpos($stored, 'att/') === 0 || strpos($stored, 'docs/') === 0) return STORAGE_DIR . '/' . $stored;
    if (strpos($stored, 'uploads/') === 0) $stored = substr($stored, strlen('uploads/'));
    return UPLOAD_DIR . '/' . $stored;
}

$pdo->prepare('UPDATE shares SET views = views + 1 WHERE id=?')->execute([$share['id']]);

$st = $pdo->prepare('SELECT id,role,content,meta,created_at FROM messages WHERE conversation_id=? AND active=1 AND id<=? ORDER BY id ASC');
$st->execute([$share['conversation_id'], $share['max_message_id']]);
$msgs = $st->fetchAll();
$ids = array_map(fn($m) => (int)$m['id'], $msgs);
$atts = array();
if ($ids) {
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT id,message_id,kind,original_name,mime FROM attachments WHERE message_id IN ($ph) AND removed=0 AND generated=0");
    $st->execute($ids);
    foreach ($st->fetchAll() as $a) $atts[(int)$a['message_id']][] = $a;
}
$dt = $msgs ? date('j M Y', strtotime((string)end($msgs)['created_at'])) : '';
?><!DOCTYPE html>
<html lang="<?= e($LANG) ?>" data-theme-pref="system">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($share['title']) ?> · WanSQ</title>
<link rel="icon" type="image/png" href="<?= e(base_url('/assets/img/favicon.png')) ?>">
<link rel="stylesheet" href="<?= e(base_url('/assets/css/style.css')) ?>?v=<?= e(WANSQ_VERSION) ?>">
<script src="<?= e(base_url('/assets/js/themeboot.js')) ?>"></script>
</head>
<body class="app-body">
<div class="share-page">
  <div class="share-hd">
    <img class="logo-light" src="<?= e(base_url('/assets/img/wan-blue.png')) ?>" data-fb="<?= e(base_url('/assets/img/wan-blue.svg')) ?>" alt="">
    <img class="logo-dark" src="<?= e(base_url('/assets/img/wan-dark.png')) ?>" data-fb="<?= e(base_url('/assets/img/wan-dark.svg')) ?>" alt="">
    <span class="sh-name">WanSQ</span>
    <span class="sh-badge"><?= trh('share.title') ?> · <?= trh('common.close') === 'Tutup' ? 'read-only' : 'read-only' ?></span>
  </div>
  <h1 class="share-title"><?= e($share['title']) ?></h1>
  <p class="share-date"><?= e($dt) ?></p>
  <div id="messages">
    <?php foreach ($msgs as $m): $ma = $atts[(int)$m['id']] ?? array(); $meta = json_decode((string)$m['meta'], true) ?: array(); ?>
    <div class="msg <?= $m['role'] === 'user' ? 'user' : 'assistant' ?>">
      <span class="av<?= $m['role'] === 'user' ? ' user' : '' ?>"><?php if ($m['role'] === 'user'): ?><span style="width:100%;height:100%;background:var(--card2);border-radius:50%;display:block"></span><?php else: ?><img class="logo-light" src="<?= e(base_url('/assets/img/wan-blue.svg')) ?>" alt=""><img class="logo-dark" src="<?= e(base_url('/assets/img/wan-dark.svg')) ?>" alt=""><?php endif; ?></span>
      <div class="body">
        <div class="who"><?= $m['role'] === 'user' ? trh('pin.you') : 'WanSQ' ?></div>
        <?php if ($ma): ?><div class="att-row"><?php foreach ($ma as $a): if ($a['kind'] === 'image'): ?>
          <img src="<?= e(base_url('/share.php?t=' . urlencode($token) . '&img=' . (int)$a['id'])) ?>" alt="<?= e($a['original_name']) ?>" loading="lazy" data-fbhide="1">
        <?php else: ?><span class="att-doc">📄 <?= e($a['original_name']) ?></span><?php endif; endforeach; ?></div><?php endif; ?>
        <div class="bubble" style="<?= $m['role'] === 'assistant' ? 'display:contents' : '' ?>"><div class="md" data-raw="<?= e($m['content']) ?>"><?= $m['role'] === 'assistant' ? '' : nl2br(e($m['content'])) ?></div></div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (!$msgs): ?><p class="pane-hint"><?= trh('sb.empty') ?></p><?php endif; ?>
  </div>
  <div class="share-cta"><a href="<?= e(base_url('/index.php')) ?>">✦ <?= trh('menu.settings') === 'Settings' ? 'Try WanSQ' : 'Coba WanSQ' ?></a></div>
</div>
<script src="<?= e(base_url('/assets/js/mathcfg.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/vendor/mathjax/tex-mml-chtml.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>" async></script>
<script src="<?= e(base_url('/assets/js/md.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
<script src="<?= e(base_url('/assets/js/share.js')) ?>?v=<?= e(WANSQ_ASSET_VERSION) ?>"></script>
</body>
</html>
